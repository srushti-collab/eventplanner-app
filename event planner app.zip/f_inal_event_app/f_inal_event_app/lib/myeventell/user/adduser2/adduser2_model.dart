import '/auth/firebase_auth/auth_util.dart';
import '/backend/api_requests/api_calls.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import 'adduser2_widget.dart' show Adduser2Widget;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Adduser2Model extends FlutterFlowModel<Adduser2Widget> {
  ///  State fields for stateful widgets in this component.

  final formKey = GlobalKey<FormState>();
  bool isDataUploading = false;
  FFUploadedFile uploadedLocalFile =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl = '';

  // State field(s) for Full widget.
  FocusNode? fullFocusNode;
  TextEditingController? fullTextController;
  String? Function(BuildContext, String?)? fullTextControllerValidator;
  // State field(s) for Company widget.
  FocusNode? companyFocusNode;
  TextEditingController? companyTextController;
  String? Function(BuildContext, String?)? companyTextControllerValidator;
  // State field(s) for Emsil widget.
  FocusNode? emsilFocusNode;
  TextEditingController? emsilTextController;
  String? Function(BuildContext, String?)? emsilTextControllerValidator;
  // State field(s) for Phone widget.
  FocusNode? phoneFocusNode;
  TextEditingController? phoneTextController;
  String? Function(BuildContext, String?)? phoneTextControllerValidator;
  // State field(s) for ChoiceChips widget.
  FormFieldController<List<String>>? choiceChipsValueController;
  String? get choiceChipsValue =>
      choiceChipsValueController?.value?.firstOrNull;
  set choiceChipsValue(String? val) =>
      choiceChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode;
  TextEditingController? textController4;
  String? Function(BuildContext, String?)? textController4Validator;
  // State field(s) for Pass widget.
  FocusNode? passFocusNode;
  TextEditingController? passTextController;
  late bool passVisibility;
  String? Function(BuildContext, String?)? passTextControllerValidator;
  // State field(s) for ConfPass widget.
  FocusNode? confPassFocusNode;
  TextEditingController? confPassTextController;
  late bool confPassVisibility;
  String? Function(BuildContext, String?)? confPassTextControllerValidator;

  @override
  void initState(BuildContext context) {
    passVisibility = false;
    confPassVisibility = false;
  }

  @override
  void dispose() {
    fullFocusNode?.dispose();
    fullTextController?.dispose();

    companyFocusNode?.dispose();
    companyTextController?.dispose();

    emsilFocusNode?.dispose();
    emsilTextController?.dispose();

    phoneFocusNode?.dispose();
    phoneTextController?.dispose();

    textFieldFocusNode?.dispose();
    textController4?.dispose();

    passFocusNode?.dispose();
    passTextController?.dispose();

    confPassFocusNode?.dispose();
    confPassTextController?.dispose();
  }
}
