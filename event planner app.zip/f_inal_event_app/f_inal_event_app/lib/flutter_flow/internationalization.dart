import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

const _kLocaleStorageKey = '__locale_key__';

class FFLocalizations {
  FFLocalizations(this.locale);

  final Locale locale;

  static FFLocalizations of(BuildContext context) =>
      Localizations.of<FFLocalizations>(context, FFLocalizations)!;

  static List<String> languages() => ['en', 'fr'];

  static late SharedPreferences _prefs;
  static Future initialize() async =>
      _prefs = await SharedPreferences.getInstance();
  static Future storeLocale(String locale) =>
      _prefs.setString(_kLocaleStorageKey, locale);
  static Locale? getStoredLocale() {
    final locale = _prefs.getString(_kLocaleStorageKey);
    return locale != null && locale.isNotEmpty ? createLocale(locale) : null;
  }

  String get languageCode => locale.toString();
  String? get languageShortCode =>
      _languagesWithShortCode.contains(locale.toString())
          ? '${locale.toString()}_short'
          : null;
  int get languageIndex => languages().contains(languageCode)
      ? languages().indexOf(languageCode)
      : 0;

  String getText(String key) =>
      (kTranslationsMap[key] ?? {})[locale.toString()] ?? '';

  String getVariableText({
    String? enText = '',
    String? frText = '',
  }) =>
      [enText, frText][languageIndex] ?? '';

  static const Set<String> _languagesWithShortCode = {
    'ar',
    'az',
    'ca',
    'cs',
    'da',
    'de',
    'dv',
    'en',
    'es',
    'et',
    'fi',
    'fr',
    'gr',
    'he',
    'hi',
    'hu',
    'it',
    'km',
    'ku',
    'mn',
    'ms',
    'no',
    'pt',
    'ro',
    'ru',
    'rw',
    'sv',
    'th',
    'uk',
    'vi',
  };
}

/// Used if the locale is not supported by GlobalMaterialLocalizations.
class FallbackMaterialLocalizationDelegate
    extends LocalizationsDelegate<MaterialLocalizations> {
  const FallbackMaterialLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<MaterialLocalizations> load(Locale locale) async =>
      SynchronousFuture<MaterialLocalizations>(
        const DefaultMaterialLocalizations(),
      );

  @override
  bool shouldReload(FallbackMaterialLocalizationDelegate old) => false;
}

/// Used if the locale is not supported by GlobalCupertinoLocalizations.
class FallbackCupertinoLocalizationDelegate
    extends LocalizationsDelegate<CupertinoLocalizations> {
  const FallbackCupertinoLocalizationDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<CupertinoLocalizations> load(Locale locale) =>
      SynchronousFuture<CupertinoLocalizations>(
        const DefaultCupertinoLocalizations(),
      );

  @override
  bool shouldReload(FallbackCupertinoLocalizationDelegate old) => false;
}

class FFLocalizationsDelegate extends LocalizationsDelegate<FFLocalizations> {
  const FFLocalizationsDelegate();

  @override
  bool isSupported(Locale locale) => _isSupportedLocale(locale);

  @override
  Future<FFLocalizations> load(Locale locale) =>
      SynchronousFuture<FFLocalizations>(FFLocalizations(locale));

  @override
  bool shouldReload(FFLocalizationsDelegate old) => false;
}

Locale createLocale(String language) => language.contains('_')
    ? Locale.fromSubtags(
        languageCode: language.split('_').first,
        scriptCode: language.split('_').last,
      )
    : Locale(language);

bool _isSupportedLocale(Locale locale) {
  final language = locale.toString();
  return FFLocalizations.languages().contains(
    language.endsWith('_')
        ? language.substring(0, language.length - 1)
        : language,
  );
}

final kTranslationsMap = <Map<String, Map<String, String>>>[
  // Welcome
  {
    'loddy5k6': {
      'en': 'ALLORA',
      'fr': '',
    },
    'favg7wx3': {
      'en': 'YOUR EVENT YOUR WAY',
      'fr': '',
    },
    '4xq601ot': {
      'en': 'User Login  ⟶',
      'fr': 'Connexion ⟶',
    },
    '3310l4jb': {
      'en': 'Organisation Login  ⟶',
      'fr': 'Connexion ⟶',
    },
    'ill4ujjz': {
      'en': 'Admin Login  ⟶',
      'fr': 'Connexion ⟶',
    },
    '73pwi2kn': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // day1Schedule
  {
    '0kzvpc6o': {
      'en': 'Day 1',
      'fr': 'Jour 1',
    },
    'm6y58tto': {
      'en': '- Day 1 -',
      'fr': '- Jour 1 -',
    },
    'a6tutws8': {
      'en': '- Day 1 -',
      'fr': '- Jour 1 -',
    },
    '4jmbvv29': {
      'en': ' - ',
      'fr': '',
    },
    'ngkbd2ll': {
      'en': ' - ',
      'fr': '',
    },
    '2c6dvlf6': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // sponsors
  {
    '7nvw7uwg': {
      'en': ' View ',
      'fr': 'Voir',
    },
    'g9w1h8d0': {
      'en': ' View ',
      'fr': '',
    },
    '7nongouo': {
      'en': 'Sponsors',
      'fr': 'Commanditaires',
    },
  },
  // loginDashboard
  {
    'r2p4cgm9': {
      'en': '-Login-',
      'fr': '-COE 2025-',
    },
    '9lda2ktd': {
      'en': 'Fill out the information below in order to access your account.',
      'fr':
          'Remplissez les informations ci-dessous afin d\'accéder à votre compte.',
    },
    'x1qljxkz': {
      'en': 'Email',
      'fr': 'E-mail',
    },
    '7r4dft6m': {
      'en': 'Password',
      'fr': 'Mot de passe',
    },
    'h98a686n': {
      'en': 'Sign In',
      'fr': 'Se connecter',
    },
    '9jgl83ww': {
      'en': 'Reset Password',
      'fr': '',
    },
    'qsslflna': {
      'en': 'Please fill out this field',
      'fr': 'Veuillez remplir ce champ',
    },
    'pafvgq4o': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
    },
    'kwdrqsq8': {
      'en': 'Please enter your password',
      'fr': 'Veuillez entrer votre mot de passe',
    },
    'xt23v4el': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
    },
    'doodf9yd': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // delegates
  {
    'ai2bvrkw': {
      'en': 'Event Organisors',
      'fr': 'Délégués',
    },
    'm5ylq3ms': {
      'en': '',
      'fr': '',
    },
    'jq65o2ul': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
    'rg6qfh6v': {
      'en': 'Add Members',
      'fr': 'Ajouter des membres',
    },
    'k79iu6b3': {
      'en': 'View Profile',
      'fr': 'Informations',
    },
    '7ayj7isn': {
      'en': 'View Profile',
      'fr': 'Informations',
    },
    'iqftra0l': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // CHAT
  {
    'sxl44xyl': {
      'en': 'Type a message...',
      'fr': 'Tapez un message...',
    },
  },
  // Chathome
  {
    'z7nkmfsq': {
      'en': 'Chats',
      'fr': 'Chats',
    },
    'ntri3jrr': {
      'en': 'New Chat',
      'fr': 'Nouveau chat',
    },
  },
  // Sponsprof
  {
    'xxqv099k': {
      'en': 'Contact us',
      'fr': 'Entrer en contact',
    },
    'thosipue': {
      'en': 'About Us',
      'fr': 'À propos',
    },
    'rus9ai0s': {
      'en': 'People',
      'fr': 'À propos',
    },
    'jqn4ox0q': {
      'en': 'Images',
      'fr': 'À propos',
    },
    '9uz02osr': {
      'en': 'Videos',
      'fr': '',
    },
    'hlkfjmrt': {
      'en': 'Click here for videos',
      'fr': '',
    },
    'vxxp6gm9': {
      'en': 'Downloadables',
      'fr': 'À propos',
    },
    'yigacdrz': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // programopt
  {
    'g2xoosgw': {
      'en': 'Day 1',
      'fr': 'Jour 1',
    },
    '3nim1ls8': {
      'en': 'Day 2',
      'fr': 'Jour 2',
    },
    'ux25bzja': {
      'en': 'Day 3',
      'fr': 'Jour 3',
    },
    'z6bznnkg': {
      'en': 'Day 1',
      'fr': '',
    },
    '80s3bgvu': {
      'en': 'Day 2',
      'fr': '',
    },
    'b5rxv88z': {
      'en': 'Day 3',
      'fr': '',
    },
    '5b1h98jj': {
      'en': 'Agendas',
      'fr': 'Programmes',
    },
  },
  // postPage
  {
    'cvcv6g7h': {
      'en': 'Posts',
      'fr': 'Articles',
    },
    '6mgopx7u': {
      'en': '1m ago',
      'fr': 'Il y a 1 minute',
    },
    'k3x4frkr': {
      'en': ' Comment',
      'fr': 'Commentaire',
    },
    'nmgw17r4': {
      'en': ' Comment',
      'fr': 'Commentaire',
    },
    '09naneps': {
      'en': '1m ago',
      'fr': 'Il y a 1 minute',
    },
    'qwj9mv82': {
      'en': ' Comment',
      'fr': 'Commentaire',
    },
    'mfin6ba9': {
      'en': ' Add Comment',
      'fr': 'Commentaire',
    },
    'tw8rzc92': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // eventFeed
  {
    'n0ry1n9j': {
      'en': 'Feed',
      'fr': 'Alimentation',
    },
    'g945oeec': {
      'en': 'My posts',
      'fr': '',
    },
    'bu0o3dg8': {
      'en': ' • ',
      'fr': '•',
    },
    '1y4s6ur9': {
      'en': ' • ',
      'fr': '•',
    },
    'nowgtl95': {
      'en': 'John Doe',
      'fr': 'Jean Dupont',
    },
    'wpkkz56h': {
      'en': '@johndoe • 10 mins ago',
      'fr': '@johndoe • il y a 10 minutes',
    },
    'byld1476': {
      'en':
          'Just finished a great workout at the gym! Feeling energized and ready to tackle the day. #FitnessMotivation',
      'fr':
          'Je viens de terminer une séance d\'entraînement à la salle de sport ! Je me sens pleine d\'énergie et prête à affronter la journée. #FitnessMotivation',
    },
    'xd0hgsy3': {
      'en': '125',
      'fr': '125',
    },
    's67aruc1': {
      'en': '23',
      'fr': '23',
    },
    'wsv36362': {
      'en': 'Jane Smith',
      'fr': 'Jane Smith',
    },
    '9hwx2zly': {
      'en': '@janesmith • 2 hours ago',
      'fr': '@janesmith • il y a 2 heures',
    },
    'jy9bg26x': {
      'en':
          'Just tried this amazing new recipe for vegan lasagna. It\'s so delicious, you won\'t even miss the meat! #VeganCooking',
      'fr':
          'Je viens d\'essayer cette nouvelle recette incroyable de lasagnes végétaliennes. C\'est tellement délicieux que vous ne remarquerez même pas l\'absence de viande ! #CuisineVégétarienne',
    },
    'fkhe6oyh': {
      'en': '89',
      'fr': '89',
    },
    'm6b8vafa': {
      'en': '15',
      'fr': '15',
    },
    'f33csn78': {
      'en': 'Trending Topics',
      'fr': 'Sujets d\'actualité',
    },
    't8py239m': {
      'en': '#TechNews',
      'fr': '#ActualitésTechniques',
    },
    'fnukyr3v': {
      'en': '5.2K posts',
      'fr': '5,2 000 messages',
    },
    'ss8iw2zc': {
      'en': '#Travel',
      'fr': '#Voyage',
    },
    '40ydkxvb': {
      'en': '3.8K posts',
      'fr': '3,8 000 publications',
    },
    'o4zyohj6': {
      'en': '#FoodieLife',
      'fr': '#VieGourmande',
    },
    'jz8djghg': {
      'en': '2.5K posts',
      'fr': '2,5 000 messages',
    },
    '4bssl28a': {
      'en': 'Suggested Users',
      'fr': 'Utilisateurs suggérés',
    },
    '11ba13p6': {
      'en': 'Alex Johnson',
      'fr': 'Alex Johnson',
    },
    'mc2md1h6': {
      'en': '@alexj',
      'fr': '@alexj',
    },
    'zsba48hb': {
      'en': 'Follow',
      'fr': 'Suivre',
    },
    '2l2jzel4': {
      'en': 'New Post',
      'fr': 'Nouvelle publication',
    },
    'wjfexcuj': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // day2Schedule
  {
    'hr6afskq': {
      'en': 'Day 2',
      'fr': 'Jour 2',
    },
    '4d5viok2': {
      'en': '- Day 2 -',
      'fr': '- Jour 2 -',
    },
    'vreu9tyv': {
      'en': '- Day 2-',
      'fr': '- Jour 1 -',
    },
    'cvd1kp79': {
      'en': ' - ',
      'fr': '-',
    },
    'uiej9n1o': {
      'en': ' - ',
      'fr': '',
    },
    'adbqwuzs': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // day3Schedule
  {
    'bycqijb4': {
      'en': 'Day 3',
      'fr': 'Jour 3',
    },
    'od21cdbl': {
      'en': '- Day 3 -',
      'fr': '- Jour 3 -',
    },
    'vamra3ew': {
      'en': '- Day 3-',
      'fr': '- Jour 1 -',
    },
    'xkkpaihk': {
      'en': ' - ',
      'fr': '',
    },
    'jfvj58nk': {
      'en': ' - ',
      'fr': '',
    },
    '0xojvs9n': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // pfedit
  {
    'vd0gzeuu': {
      'en': 'Personal Information',
      'fr': 'Renseignements personnels',
    },
    '70w6pse9': {
      'en': 'Full Name',
      'fr': 'Nom et prénom',
    },
    'zs3pfvgf': {
      'en': 'Phone Number',
      'fr': 'Nom et prénom',
    },
    'm2ij92eg': {
      'en': 'Additional Details',
      'fr': 'Détails supplémentaires',
    },
    'r60djssp': {
      'en': 'Company',
      'fr': 'Entreprise',
    },
    'fp4honyi': {
      'en': 'Job Title',
      'fr': 'Titre d\'emploi',
    },
    'xz6t1a8l': {
      'en': 'Update Profile',
      'fr': 'Mettre à jour le profil',
    },
    '4dqrynmc': {
      'en': 'Edit profile',
      'fr': 'Modifier le profil',
    },
  },
  // Bookmark
  {
    'b8txyasr': {
      'en': 'Your Bookmarked Users',
      'fr': 'Vos utilisateurs favoris',
    },
    '9w1qko34': {
      'en': 'Here are the users you\'ve bookmarked for quick access.',
      'fr':
          'Voici les utilisateurs que vous avez ajoutés à vos favoris pour un accès rapide.',
    },
    'jldew8z9': {
      'en': 'Michael Chen',
      'fr': 'Michael Chen',
    },
    'tfo770ht': {
      'en': '@michaelchen',
      'fr': '@michaelchen',
    },
    'zt2tm73b': {
      'en': 'Emily Rodriguez',
      'fr': 'Émilie Rodriguez',
    },
    'w48kz8rf': {
      'en': '@emilyrodriguez',
      'fr': '@emilyrodriguez',
    },
    'hpi7j84q': {
      'en': 'Alex Thompson',
      'fr': 'Alex Thompson',
    },
    'fqrpzj9h': {
      'en': '@alexthompson',
      'fr': '@alexthompson',
    },
    'i2icapql': {
      'en': 'Olivia Patel',
      'fr': 'Olivia Patel',
    },
    'yybe54bb': {
      'en': '@oliviapatel',
      'fr': '@oliviapatel',
    },
    'b9n56jdr': {
      'en': 'Bookmarks',
      'fr': 'Signets',
    },
  },
  // forgot_psd
  {
    'yw5ixd3f': {
      'en': 'Reset Password',
      'fr': 'Titre de la page',
    },
    'ag20az7c': {
      'en': 'Reset Your Password',
      'fr': '',
    },
    'jm1gjn91': {
      'en': 'Reset Your Password',
      'fr': '',
    },
    'y7pslfne': {
      'en':
          'Enter the email associated with your account and we\'ll send you instructions to reset your password.',
      'fr': '',
    },
    '3nvgt35o': {
      'en':
          'Enter the email associated with your account and we\'ll send you instructions to reset your password.',
      'fr': '',
    },
    '3y23n9i6': {
      'en': 'Email Address',
      'fr': 'Adresse email',
    },
    'e38uhgjf': {
      'en': 'Send Reset Mail',
      'fr': '',
    },
    'c18ocq1f': {
      'en': 'Remember your password?',
      'fr': '',
    },
    'n0o1knhi': {
      'en': 'Log In',
      'fr': '',
    },
  },
  // Prof
  {
    '4kcy1tpu': {
      'en': 'Profile Settings',
      'fr': '',
    },
    'ooni2ijz': {
      'en': 'Edit Profile',
      'fr': '',
    },
    'dkh2kqib': {
      'en': 'My Posts',
      'fr': '',
    },
    'pvfh9han': {
      'en': 'My Bookmarks',
      'fr': '',
    },
    'bwkhi4qu': {
      'en': 'Change Password',
      'fr': '',
    },
    'a7xtq7o0': {
      'en': 'Logout',
      'fr': '',
    },
    'tn75pcgw': {
      'en': 'Your Profile',
      'fr': 'Titre de la page',
    },
  },
  // profinfo
  {
    'ky3v0sip': {
      'en': 'Chat',
      'fr': '',
    },
    '2xdqejo3': {
      'en': 'Book Event',
      'fr': '',
    },
    '9m9piz97': {
      'en': 'Profile info',
      'fr': 'Titre de la page',
    },
  },
  // Myposts
  {
    'y1uhkbdy': {
      'en': 'Your Recent Posts',
      'fr': '',
    },
    'g4lxtalz': {
      'en': 'My Posts',
      'fr': 'Titre de la page',
    },
  },
  // speakerinfo
  {
    '3w22vl7q': {
      'en': 'Bio',
      'fr': '',
    },
    'nyukiqy7': {
      'en': 'Speaker profile info',
      'fr': 'Titre de la page',
    },
  },
  // Speaker1
  {
    'bjvnudus': {
      'en': 'Speakers',
      'fr': 'Délégués',
    },
    'nlfnvlda': {
      'en': '',
      'fr': '',
    },
    'ddwtf07e': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
    'koatcxx1': {
      'en': 'View Profile',
      'fr': 'Informations',
    },
    'mq5tsde1': {
      'en': 'View Profile',
      'fr': 'Informations',
    },
    'xd2x6pi4': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // CHATCopy
  {
    '4ihlvyjm': {
      'en': 'Type a message...',
      'fr': 'Tapez un message...',
    },
  },
  // delegatesCopy
  {
    '59wkvk8e': {
      'en': ' ',
      'fr': 'Délégués',
    },
    'jbj0yzmp': {
      'en': 'SPEAKERS',
      'fr': '',
    },
    '94wq3kkv': {
      'en': '',
      'fr': '',
    },
    '8ajll38y': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
    'yweuqybq': {
      'en': 'View Profile',
      'fr': 'Informations',
    },
    'nehfdbnz': {
      'en': 'View Profile',
      'fr': 'Informations',
    },
    'ewmxjrkq': {
      'en': 'DELEGATES',
      'fr': '',
    },
    'jzmsez1a': {
      'en': '',
      'fr': '',
    },
    '1qjoy6iq': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
    'cmvp9rci': {
      'en': 'View Profile',
      'fr': 'Informations',
    },
    '030bi1f9': {
      'en': 'View Profile',
      'fr': 'Informations',
    },
    '7plmrkkc': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // DashboardCopy
  {
    'ygrshohc': {
      'en': 'Home',
      'fr': 'Maison',
    },
    '4ulli8m7': {
      'en': 'Chats',
      'fr': 'Chats',
    },
    'xr4riobx': {
      'en': 'Event Feed',
      'fr': 'Flux d\'événements',
    },
    '2d6j2k3o': {
      'en': 'Events',
      'fr': 'Délégués',
    },
    'rqtl66z8': {
      'en': 'Sponsors',
      'fr': 'Commanditaires',
    },
    't0dwtl7u': {
      'en': 'My Events',
      'fr': 'Commanditaires',
    },
    'br28dbcm': {
      'en': 'Log Out',
      'fr': 'Se déconnecter',
    },
    'qac85s6f': {
      'en': 'Contact Support',
      'fr': 'Profil',
    },
    'avdrxswi': {
      'en': 'World Cashew Conference 2025',
      'fr': 'Conférence mondiale sur la noix de cajou 2025',
    },
    'vw8e2y7j': {
      'en': '21 - 23 February 2023',
      'fr': '21 - 23 février 2023',
    },
    'txwf1vjz': {
      'en': 'Hilton Al Habtoor City, Dubai',
      'fr': 'Hilton Al Habtoor City, Dubaï',
    },
    'pj2073al': {
      'en': 'ALLORA ',
      'fr': 'Conférence mondiale sur la noix de cajou 2025',
    },
    'nydpukyz': {
      'en': 'YOUR EVENT YOUR WAY',
      'fr': '21 - 23 février 2023',
    },
    'o121qip8': {
      'en': 'NOW BOOK YOUR EVENTS CHEAPEST EVER',
      'fr': 'Hilton Al Habtoor City, Dubaï',
    },
    'mmh7czhl': {
      'en': 'Sponsors',
      'fr': 'Programmes',
    },
    'azf9gl5a': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    'd6q9in44': {
      'en': 'Sponsers',
      'fr': 'Programmes',
    },
    '6ry5nu8l': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    'w6zuvpzb': {
      'en': 'ALLORA',
      'fr': 'COE 2025',
    },
    'whpnhfsz': {
      'en': 'YOUR EVENT ',
      'fr': 'ANACARDIER',
    },
    '31tb3hjd': {
      'en': 'YOUR WAY',
      'fr': 'CONFÉRENCE',
    },
    'm0gnvxx9': {
      'en': '',
      'fr': 'COE 2025',
    },
    '3irz5of1': {
      'en': 'CASHEW ',
      'fr': 'ANACARDIER',
    },
    'cieuaoq5': {
      'en': 'CONFERANCE',
      'fr': 'CONFÉRENCE',
    },
    'ny7uke8u': {
      'en': '21 - 23 February 2023',
      'fr': '21 - 23 février 2023',
    },
    'itap9s5j': {
      'en': 'Programs',
      'fr': 'Programmes',
    },
    'va96xfmp': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    'a4e7ycrq': {
      'en': 'Speakers',
      'fr': 'Intervenants',
    },
    '6seh51dv': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    'ghy6s3jr': {
      'en': 'Speakers',
      'fr': 'Intervenants',
    },
    'pljoclek': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    'by5j06rn': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // SponsprofCopy
  {
    'xyh4lc5r': {
      'en': 'About',
      'fr': 'À propos',
    },
    'j9xl1lgw': {
      'en': 'Get in Touch',
      'fr': 'Entrer en contact',
    },
    '67bzoznv': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // ScavengerHunt
  {
    '1lwkwcj3': {
      'en': 'Scavenger Hunt',
      'fr': '',
    },
    '2lnj1a3i': {
      'en': 'Find all 10 QR codes around the venue!',
      'fr': '',
    },
    '2okak0uj': {
      'en': 'Game Ends at',
      'fr': '',
    },
    'n3o4nm0d': {
      'en': 'Your Progress: ',
      'fr': '',
    },
    'uatewxdb': {
      'en': 'Scan QR Code',
      'fr': '',
    },
    'an4vdv4e': {
      'en': 'Cancel',
      'fr': '',
    },
    '9metzd3a': {
      'en': 'Leaderboard',
      'fr': '',
    },
    'wu55iw6q': {
      'en': '1',
      'fr': '',
    },
    'dnuhz2sr': {
      'en': '2',
      'fr': '',
    },
    'wscdqzea': {
      'en': '3',
      'fr': '',
    },
    'qoh5degk': {
      'en': '4',
      'fr': '',
    },
  },
  // MyCalender
  {
    'ks8rq5g8': {
      'en': 'My Calendar',
      'fr': '',
    },
    '569d1d1d': {
      'en': 'Requests',
      'fr': '',
    },
    '5bc8zrdz': {
      'en': 'Accept',
      'fr': '',
    },
    'v61uyyfq': {
      'en': 'Decline',
      'fr': '',
    },
    'rdnu6qve': {
      'en': 'Schedules',
      'fr': '',
    },
    'q7df8vsv': {
      'en': 'ACCEPTED',
      'fr': '',
    },
    '072993mf': {
      'en': 'PENDING',
      'fr': '',
    },
    'wkzwum8p': {
      'en': 'REJECTED',
      'fr': '',
    },
  },
  // profinfoCopy
  {
    'wrgiaza4': {
      'en': 'Chat',
      'fr': '',
    },
    '6uxhzzlm': {
      'en': 'Schedule Meeting',
      'fr': '',
    },
    'qibfvgj3': {
      'en': 'Chat',
      'fr': '',
    },
    '9gbvkt7n': {
      'en': 'Schedule Meeting',
      'fr': '',
    },
    'c3e7hlvo': {
      'en': 'Bio',
      'fr': '',
    },
    'qyuog3wk': {
      'en': 'Bio',
      'fr': '',
    },
    'we065rzu': {
      'en': 'Profile info',
      'fr': 'Titre de la page',
    },
  },
  // day2ScheduleCopy
  {
    '4a2aorfw': {
      'en': 'Day 1',
      'fr': 'Jour 1',
    },
    'l49quhi9': {
      'en': '- Day 2 -',
      'fr': '- Jour 1 -',
    },
    '2plcyi1q': {
      'en': '- Day 1 -',
      'fr': '- Jour 1 -',
    },
    '3agzucbb': {
      'en': ' - ',
      'fr': '',
    },
    '0kvxv0n4': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // day2ScheduleCopyCopy
  {
    'boj6nyst': {
      'en': 'Day 1',
      'fr': 'Jour 1',
    },
    'qpcikadt': {
      'en': '- Day 1-',
      'fr': '- Jour 1 -',
    },
    'bljx3huz': {
      'en': '- Day 1 -',
      'fr': '- Jour 1 -',
    },
    '7sr8lbhs': {
      'en': ' - ',
      'fr': '',
    },
    '5r1reogv': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // LeaderBoard
  {
    'rlts9aql': {
      'en': 'Leaderboard',
      'fr': '',
    },
    'ip5ajt51': {
      'en': 'Most Active user',
      'fr': '',
    },
    'f1klic5v': {
      'en': 'All Users',
      'fr': '',
    },
    '9jow0r33': {
      'en': '4',
      'fr': '',
    },
    'oyzjflvd': {
      'en': '5',
      'fr': '',
    },
    'bkxqgzw2': {
      'en': 'Alex Johnson',
      'fr': '',
    },
    '7poekk50': {
      'en': '2,340 points',
      'fr': '',
    },
    'icmkps38': {
      'en': '+80',
      'fr': '',
    },
    'wd71a0ts': {
      'en': '6',
      'fr': '',
    },
    '5j4u3mfi': {
      'en': 'Lisa Park',
      'fr': '',
    },
    'pz9n6xxi': {
      'en': '2,180 points',
      'fr': '',
    },
    'aa1kljw9': {
      'en': '+65',
      'fr': '',
    },
  },
  // invitation
  {
    'ibtfl8go': {
      'en': 'Accept',
      'fr': '',
    },
    '51mn9i80': {
      'en': 'Decline',
      'fr': '',
    },
    '3xirfvu2': {
      'en': 'Meeting Requests',
      'fr': '',
    },
    'ldou27xd': {
      'en': 'Home',
      'fr': '',
    },
  },
  // CREATEPASSWORD
  {
    'yshkkzxn': {
      'en': 'Create Password',
      'fr': '',
    },
    '03r3kfwi': {
      'en': 'Choose a secure password',
      'fr': '',
    },
    'zjllnk40': {
      'en':
          'Your password must be at least 8 characters long and include a combination of numbers, letters, and special characters.',
      'fr': '',
    },
    'v046mq6v': {
      'en': 'Password',
      'fr': '',
    },
    'bkt3go7q': {
      'en': 'Confirm Password',
      'fr': '',
    },
    'psi4xeez': {
      'en': 'Password strength: Medium',
      'fr': '',
    },
    'xzdr8p7a': {
      'en': 'Create Password',
      'fr': '',
    },
    'sw6rgj8r': {
      'en': 'At least 8 characters',
      'fr': '',
    },
    'kxcnzayg': {
      'en': 'Contains numbers',
      'fr': '',
    },
    'qvx7nr25': {
      'en': 'Contains special characters',
      'fr': '',
    },
    'x6avuj1q': {
      'en': 'Contains uppercase letters',
      'fr': '',
    },
  },
  // day1ScheSpeak
  {
    's35jsywh': {
      'en': 'Page Title',
      'fr': '',
    },
  },
  // sessionspeakinfo
  {
    '3njxmd9t': {
      'en': 'Senior Software Engineer',
      'fr': '',
    },
    'vh8vsup9': {
      'en': '',
      'fr': '',
    },
    '4gxofkpv': {
      'en': 'Chat',
      'fr': '',
    },
    'cu4vl83o': {
      'en': 'Schedule Meeting',
      'fr': '',
    },
    'wzquqcgq': {
      'en': 'Chat',
      'fr': '',
    },
    'rveesofc': {
      'en': 'Schedule Meeting',
      'fr': '',
    },
    '7marq0hb': {
      'en': 'Bio',
      'fr': '',
    },
    'ucq9e799': {
      'en':
          'Passionate software engineer with over 8 years of experience in developing scalable web applications. Specializes in full-stack development using modern technologies. Committed to writing clean, efficient code and mentoring junior developers.',
      'fr': '',
    },
    'x3gg3tlm': {
      'en': 'Bio',
      'fr': '',
    },
    '2tyw4q8o': {
      'en':
          'Passionate software engineer with over 8 years of experience in developing scalable web applications. Specializes in full-stack development using modern technologies. Committed to writing clean, efficient code and mentoring junior developers.',
      'fr': '',
    },
    '0ppthyy8': {
      'en': 'Profile info',
      'fr': 'Titre de la page',
    },
  },
  // sponsorsCopy
  {
    '5lf1g3vz': {
      'en': ' View ',
      'fr': 'Voir',
    },
    'hcp72pyx': {
      'en': ' View ',
      'fr': '',
    },
    'qrks4am3': {
      'en': 'Exhibitors',
      'fr': 'Commanditaires',
    },
  },
  // ChathomeCopy
  {
    'xzidipz9': {
      'en': 'Chats',
      'fr': 'Chats',
    },
    'h8zgs9rf': {
      'en': 'New Chat',
      'fr': 'Nouveau chat',
    },
  },
  // profinfoCopyCopy
  {
    'm75cy8k4': {
      'en': 'Chat',
      'fr': '',
    },
    'jubg0377': {
      'en': 'Schedule Meeting',
      'fr': '',
    },
    'gr0osss3': {
      'en': 'Bio',
      'fr': '',
    },
    'h6cil7c5': {
      'en': 'Bio',
      'fr': '',
    },
    'thvul0lr': {
      'en': 'Profile info',
      'fr': 'Titre de la page',
    },
  },
  // MyCalanderdupli
  {
    '2fbvcvgh': {
      'en': 'My Calendar',
      'fr': '',
    },
    '2xcmgga6': {
      'en': 'Support',
      'fr': '',
    },
    'q1cksu93': {
      'en': 'Upcoming Meetings',
      'fr': '',
    },
  },
  // MyCalenderCopy
  {
    '98p4w85b': {
      'en': 'My Calendar',
      'fr': '',
    },
    'yhjx4kzh': {
      'en': 'Upcoming Meetings',
      'fr': '',
    },
    'e9bvrneu': {
      'en': 'ACCEPTED',
      'fr': '',
    },
    'wk8tyyh1': {
      'en': 'PENDING',
      'fr': '',
    },
    'v6sd8u5b': {
      'en': 'REJECTED',
      'fr': '',
    },
  },
  // invitationCopy
  {
    '7cjhffib': {
      'en': 'Accept',
      'fr': '',
    },
    'hn1x4qfh': {
      'en': 'Decline',
      'fr': '',
    },
    'snddktcc': {
      'en': 'Meeting Requests',
      'fr': '',
    },
    'ec2ogth9': {
      'en': 'Home',
      'fr': '',
    },
  },
  // CHATCopy2
  {
    'bio0qdjd': {
      'en': 'Type a message...',
      'fr': 'Tapez un message...',
    },
  },
  // ScavengerHuntCopy
  {
    'hifs8vab': {
      'en': 'Scavenger Hunt',
      'fr': '',
    },
    'it223f3t': {
      'en': 'Find all 10 QR codes around the venue!',
      'fr': '',
    },
    'p26577dq': {
      'en': 'Time Remaining',
      'fr': '',
    },
    '8cuefp3s': {
      'en': 'Your Progress: ',
      'fr': '',
    },
    '2udpxqnp': {
      'en': 'Scan QR Code',
      'fr': '',
    },
    'bmkc6pxw': {
      'en': 'Cancel',
      'fr': '',
    },
    'csnk8v5w': {
      'en': 'Leaderboard',
      'fr': '',
    },
    'b9ep830g': {
      'en': '1',
      'fr': '',
    },
    'kxeqq551': {
      'en': '2',
      'fr': '',
    },
    'j9kqd6eh': {
      'en': '3',
      'fr': '',
    },
    '3wwru6gi': {
      'en': '4',
      'fr': '',
    },
  },
  // admin
  {
    '6rak9agy': {
      'en': 'Admin Panel',
      'fr': '',
    },
    'ccdlm5k0': {
      'en': 'Admin',
      'fr': '',
    },
    '2r5e06g5': {
      'en': 'Dashboard',
      'fr': '',
    },
    'd5dpd7h0': {
      'en': 'Users',
      'fr': '',
    },
    'xhog6l7l': {
      'en': 'Sponsors',
      'fr': '',
    },
    'qce8q4mm': {
      'en': 'Logout',
      'fr': '',
    },
    'ymxqto1a': {
      'en': 'Admin Dashboard',
      'fr': '',
    },
    'bom7tk94': {
      'en': 'Welcome back',
      'fr': '',
    },
    'fu8br1r2': {
      'en': 'Total Users',
      'fr': '',
    },
    '38xq34hd': {
      'en': 'Manage User',
      'fr': '',
    },
    'oq7vka6b': {
      'en': 'Manage Sponsors',
      'fr': '',
    },
    '5i03yqfv': {
      'en': 'Home',
      'fr': '',
    },
  },
  // UserManage
  {
    'r3o3o3zu': {
      'en': 'Search users by name or email',
      'fr': '',
    },
    '8i7v1lux': {
      'en': 'Option 1',
      'fr': '',
    },
    '7nobs87b': {
      'en': 'Add User',
      'fr': '',
    },
    'rfe5yc5h': {
      'en': 'Users',
      'fr': '',
    },
    '4wxpriw4': {
      'en': 'Home',
      'fr': '',
    },
  },
  // sponser
  {
    'n3azun0q': {
      'en': 'Search users by name or email',
      'fr': '',
    },
    'qbb7zo63': {
      'en': 'Add Sponser',
      'fr': '',
    },
    'zwx2iwxn': {
      'en': 'Jane Smith',
      'fr': '',
    },
    'zddwbrq7': {
      'en': 'jane.smith@example.com',
      'fr': '',
    },
    'zztgmoqg': {
      'en': 'Pending',
      'fr': '',
    },
    'vbk6xw7h': {
      'en': 'Role: Editor',
      'fr': '',
    },
    'mqzttilm': {
      'en': 'Edit User',
      'fr': '',
    },
    'oz36pg8o': {
      'en': 'Mike Johnson',
      'fr': '',
    },
    'k3ufbsi4': {
      'en': 'mike.johnson@example.com',
      'fr': '',
    },
    '8otpq9cf': {
      'en': 'Active',
      'fr': '',
    },
    'f996999e': {
      'en': 'Role: Viewer',
      'fr': '',
    },
    'tvii0v4c': {
      'en': 'Edit User',
      'fr': '',
    },
    'hbaokaj0': {
      'en': 'Sponsers',
      'fr': '',
    },
    '6kgrn3c5': {
      'en': 'Home',
      'fr': '',
    },
  },
  // DashboardCopyCopy3
  {
    '2vv1r3ty': {
      'en': 'Home',
      'fr': 'Maison',
    },
    'k0vtpp0o': {
      'en': 'Chats',
      'fr': 'Chats',
    },
    'rere6e4u': {
      'en': 'Event Feed',
      'fr': 'Flux d\'événements',
    },
    'x7swat9g': {
      'en': 'Sponsors',
      'fr': 'Commanditaires',
    },
    '3os3ov46': {
      'en': 'Booking Requests',
      'fr': 'Commanditaires',
    },
    'mffu1c0l': {
      'en': 'Log Out',
      'fr': 'Se déconnecter',
    },
    'q2nj6uxp': {
      'en': 'Contact Support',
      'fr': 'Profil',
    },
    'qmiif4x3': {
      'en': 'World Cashew Conference 2025',
      'fr': 'Conférence mondiale sur la noix de cajou 2025',
    },
    '8r1ddq7h': {
      'en': '21 - 23 February 2023',
      'fr': '21 - 23 février 2023',
    },
    'ww0uy9lf': {
      'en': 'Hilton Al Habtoor City, Dubai',
      'fr': 'Hilton Al Habtoor City, Dubaï',
    },
    'enzd73zv': {
      'en': 'ALLORA ',
      'fr': 'Conférence mondiale sur la noix de cajou 2025',
    },
    'pr2xmiuo': {
      'en': 'YOUR EVENT YOUR WAY',
      'fr': '21 - 23 février 2023',
    },
    'qtfrsvr9': {
      'en': 'NOW BOOK YOUR EVENTS CHEAPEST EVER',
      'fr': 'Hilton Al Habtoor City, Dubaï',
    },
    'qjnohqqr': {
      'en': 'Sponsors',
      'fr': 'Programmes',
    },
    'te81wbtn': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    '7sa712rk': {
      'en': 'Sponsers',
      'fr': 'Programmes',
    },
    'vajwapwg': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    'yl3fgla8': {
      'en': 'ALLORA',
      'fr': 'COE 2025',
    },
    'h8svjslh': {
      'en': 'YOUR EVENT ',
      'fr': 'ANACARDIER',
    },
    'gdafqpl7': {
      'en': 'YOUR WAY',
      'fr': 'CONFÉRENCE',
    },
    'fprk8ij7': {
      'en': '',
      'fr': 'COE 2025',
    },
    'n93t2dou': {
      'en': 'CASHEW ',
      'fr': 'ANACARDIER',
    },
    '06d8vfxd': {
      'en': 'CONFERANCE',
      'fr': 'CONFÉRENCE',
    },
    'optilnuk': {
      'en': '21 - 23 February 2023',
      'fr': '21 - 23 février 2023',
    },
    '271wk918': {
      'en': 'Programs',
      'fr': 'Programmes',
    },
    'rde8n7pa': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    'epo2h7rt': {
      'en': 'Speakers',
      'fr': 'Intervenants',
    },
    'ta93i8j9': {
      'en': 'View more',
      'fr': 'Voir plus',
    },
    'hn815cud': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // loginDashboardCopy
  {
    'do2u1e2s': {
      'en': '-Login-',
      'fr': '-COE 2025-',
    },
    'h7v7mwck': {
      'en': 'Fill out the information below in order to access your account.',
      'fr':
          'Remplissez les informations ci-dessous afin d\'accéder à votre compte.',
    },
    '0gtag7rq': {
      'en': 'Email',
      'fr': 'E-mail',
    },
    '8md5vbha': {
      'en': 'Password',
      'fr': 'Mot de passe',
    },
    '08sq76st': {
      'en': 'Sign In',
      'fr': 'Se connecter',
    },
    'incf2soh': {
      'en': 'Reset Password',
      'fr': '',
    },
    '39st8ju6': {
      'en': 'Please fill out this field',
      'fr': 'Veuillez remplir ce champ',
    },
    'uc44f8d1': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
    },
    'q0d8ldwr': {
      'en': 'Please enter your password',
      'fr': 'Veuillez entrer votre mot de passe',
    },
    'pj2v3278': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
    },
    'hrg907ry': {
      'en': 'Home',
      'fr': 'Maison',
    },
  },
  // addPost
  {
    '35iblze9': {
      'en': 'Enter Something Here ...',
      'fr': 'Entrez quelque chose ici ...',
    },
    '9s7gstd4': {
      'en': 'Create a Post',
      'fr': 'Créer une publication',
    },
  },
  // commentOnapost
  {
    '641f8t1b': {
      'en': 'Enter Something Here ...',
      'fr': 'Entrez quelque chose ici ...',
    },
    'rjqyr0pu': {
      'en': 'Add Comment',
      'fr': 'Ajouter un commentaire',
    },
  },
  // CreateNewChat
  {
    'yiihl6ht': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    'hddqwygc': {
      'en': '',
      'fr': '',
    },
    'mqya6paa': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // adduser2
  {
    'rgymc2o4': {
      'en': '-Add User-',
      'fr': '-Ajouter un utilisateur-',
    },
    'k49hawo2': {
      'en': 'Full Name',
      'fr': 'Nom et prénom',
    },
    'cnqtv9bl': {
      'en': 'Event Name',
      'fr': 'Entreprise',
    },
    'ki1fggj3': {
      'en': 'Email',
      'fr': '',
    },
    'z8qxd9pk': {
      'en': 'Phone',
      'fr': 'Téléphone',
    },
    'mjy5nar5': {
      'en': 'Role',
      'fr': 'Rôle',
    },
    'bccmgmg1': {
      'en': 'Organisation',
      'fr': 'Intervenants',
    },
    'x6p0cjdw': {
      'en': 'Admin',
      'fr': 'Administrateur',
    },
    'lit1uqqi': {
      'en': 'Customer',
      'fr': 'Déléguer',
    },
    'dljj3i0a': {
      'en': 'User name required',
      'fr': 'Veuillez remplir ce champ',
    },
    'mxbf0659': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
    },
    '2tmeqwtp': {
      'en': 'Field is required',
      'fr': '',
    },
    'oyxwzwf7': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
    },
    '99spv6v3': {
      'en': 'Please fill out this field',
      'fr': 'Veuillez remplir ce champ',
    },
    '4rudc029': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
    },
    'h0pel2i4': {
      'en': 'Phone Number required',
      'fr': '',
    },
    'qcgt18lt': {
      'en': 'Please choose an option from the dropdown',
      'fr': '',
    },
    'e3805laj': {
      'en': 'Price',
      'fr': 'Numéro GST (pour les délégués indiens)',
    },
    't81csfy4': {
      'en': 'Pass',
      'fr': 'Passer',
    },
    '7old2xdy': {
      'en': 'WCC@2025',
      'fr': 'COE@2025',
    },
    'mdff8cgr': {
      'en': 'ConfPass',
      'fr': 'Passe de Conf',
    },
    'zjepctvj': {
      'en': 'WCC@2025',
      'fr': 'COE@2025',
    },
    '3jar01ue': {
      'en': 'Add User',
      'fr': 'Ajouter un utilisateur',
    },
  },
  // addsponser
  {
    '2jann548': {
      'en': 'Add New Sponsor',
      'fr': 'Ajouter un nouveau sponsor',
    },
    'isoi5xwi': {
      'en': 'Sponser Name',
      'fr': 'Nom du sponsor',
    },
    'xuyvu7mp': {
      'en': 'Email',
      'fr': 'Jour n°',
    },
    '4mfeour5': {
      'en': 'Phone',
      'fr': 'Téléphone',
    },
    'db836a5x': {
      'en': 'Address',
      'fr': 'Adresse',
    },
    'b9hd7i1l': {
      'en': 'Website',
      'fr': 'Site web',
    },
    '5fc4roux': {
      'en': 'Social Media Links',
      'fr': 'Liens vers les réseaux sociaux',
    },
    'aud4zi5w': {
      'en': 'Facebook',
      'fr': 'Facebook',
    },
    'j6n1cw1m': {
      'en': 'Twitter',
      'fr': 'Gazouillement',
    },
    'l12lm0kz': {
      'en': 'Instagram',
      'fr': 'Instagram',
    },
    'pnabh064': {
      'en': 'LinkedIn',
      'fr': 'LinkedIn',
    },
    'skn2wkbb': {
      'en': 'About Sponsor',
      'fr': 'À propos du sponsor',
    },
    'faaobrbj': {
      'en': 'Submit',
      'fr': 'Soumettre',
    },
  },
  // SessionDay2
  {
    'cudrni43': {
      'en': 'Day Details',
      'fr': 'Détails de la journée',
    },
    'afyjebgh': {
      'en': 'Start time',
      'fr': 'Heure de début',
    },
    'bklb011d': {
      'en': 'End time',
      'fr': 'Fin des temps',
    },
    'qhstpuxv': {
      'en': 'Session No',
      'fr': 'Session n°',
    },
    't043e05m': {
      'en': 'Title',
      'fr': 'Titre',
    },
    '4j9y4apf': {
      'en': 'Cancel',
      'fr': 'Annuler',
    },
    'dd92leb3': {
      'en': 'Submit',
      'fr': 'Soumettre',
    },
  },
  // SessionDay3
  {
    '50yn9rwt': {
      'en': 'Day Details',
      'fr': 'Détails de la journée',
    },
    'gfir8ssx': {
      'en': 'Start time',
      'fr': 'Heure de début',
    },
    '451wgk6f': {
      'en': 'End time',
      'fr': 'Fin des temps',
    },
    'at2v8fe9': {
      'en': 'Session No',
      'fr': 'Session n°',
    },
    'oj2qw2uj': {
      'en': 'Title',
      'fr': 'Titre',
    },
    'datmx8ya': {
      'en': 'Cancel',
      'fr': 'Annuler',
    },
    'a33wtdhm': {
      'en': 'Submit',
      'fr': 'Soumettre',
    },
  },
  // ChangePass
  {
    'mfbbgw9b': {
      'en': 'Change Password',
      'fr': 'Changer le mot de passe',
    },
    'j15mvzlb': {
      'en': 'Current Password',
      'fr': 'Mot de passe actuel',
    },
    'lzo68vwj': {
      'en': 'New Password',
      'fr': 'Nouveau mot de passe',
    },
    '8n5ronkd': {
      'en': 'Confirm New Password',
      'fr': 'Confirmer le nouveau mot de passe',
    },
    'kv35lcrg': {
      'en': 'Update Password',
      'fr': 'Mettre à jour le mot de passe',
    },
  },
  // newcopy
  {
    '0xsq90f3': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    'wyh7x7ya': {
      'en': '',
      'fr': '',
    },
    'ivyuoq0v': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // dupli
  {
    'agtxmvfk': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    '87go9etv': {
      'en': '',
      'fr': '',
    },
    '01so4w7d': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // new_chat
  {
    'k0ar7rj8': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    'htef7hf6': {
      'en': '',
      'fr': '',
    },
    '6bokah5k': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
    'zlyfxqtm': {
      'en': 'List Item Title',
      'fr': '',
    },
    'a5ht3owx': {
      'en': 'Secondary text',
      'fr': '',
    },
    '595jdm4x': {
      'en': 'List Item Title',
      'fr': '',
    },
    'oomzj87h': {
      'en': 'Secondary text',
      'fr': '',
    },
  },
  // CreateNewChatCopy2CopyCopy
  {
    '2ngh72l2': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    'ucigtcif': {
      'en': '',
      'fr': '',
    },
    'g3w9ooi2': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // CreateNewChatCopy2CopyCopyCopy
  {
    'ofexh3za': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    'tc4me5iy': {
      'en': '',
      'fr': '',
    },
    '0fmpjd6m': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // chatcreatenew
  {
    '5zy3ks52': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    'uxfcnvf2': {
      'en': '',
      'fr': '',
    },
    'hs3l047c': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // CreateNewChatCopy2CopyCopyCopy2
  {
    'n6fnopyk': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    't3m4w85b': {
      'en': '',
      'fr': '',
    },
    'vx3r1pvw': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // CreateNewChatCopy2CopyCopyCopy3
  {
    'xkyddj0e': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    '5sdu4yry': {
      'en': '',
      'fr': '',
    },
    'j8mpic6b': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // CreateNewChatCopy2CopyCopyCopy4
  {
    'pskmrbt9': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    '7a9o459e': {
      'en': '',
      'fr': '',
    },
    'j2l18osn': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // support
  {
    'jagpq0y5': {
      'en': 'Support',
      'fr': '',
    },
    'r6xwuisx': {
      'en':
          'For any queries related to delegate registration or exhibition click here',
      'fr': '',
    },
    '9com5j78': {
      'en': 'Contact Support',
      'fr': '',
    },
    'ye952jkk': {
      'en': 'For any queries related to the mobile app, reach out to:',
      'fr': '',
    },
    '1y3gz7zb': {
      'en': 'Contact Support',
      'fr': '',
    },
  },
  // meet
  {
    '279ge3s8': {
      'en': 'Book Event',
      'fr': '',
    },
  },
  // meetCopy
  {
    'mtxy5yuj': {
      'en': 'Senior Product Designer',
      'fr': '',
    },
    'hh0vo5xh': {
      'en': 'TechVision Solutions',
      'fr': '',
    },
    'xvfk7vbx': {
      'en': '',
      'fr': '',
    },
    '3j66xqgk': {
      'en': 'Available Slots',
      'fr': '',
    },
    '67sow8io': {
      'en': 'Schedule Meeting',
      'fr': '',
    },
    't13s7zu4': {
      'en': 'Meeting Request Pending..!',
      'fr': '',
    },
  },
  // Day1sessioncomp
  {
    'b6agzit6': {
      'en': 'Speakers',
      'fr': '',
    },
    'q49yyl9d': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    'dlvoygi9': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    's5tgrayo': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    'g0pndnlq': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    '2pa86y4l': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    'ww3pifl6': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    'ndntds2p': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    'mi7ztmmz': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
    'scmtk6ld': {
      'en': 'Moderators',
      'fr': '',
    },
    '47g2uoiu': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    'lsc2zavp': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    'ty01bl5j': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    'ct5k4sws': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    'sdt0ycst': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    '78xe0avx': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    '7c5t0yfz': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    'uw8d8izy': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
    '1l5w8p63': {
      'en': 'Chair panelist',
      'fr': '',
    },
    '4zttfgj7': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    'bubm55pj': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    'fqz3utj3': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    'm38um2mc': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    'bzefomk7': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    'bauwsgip': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    'w8q43h9g': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    'xn3uwuyo': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
  },
  // CreateNewChatCopy2CopyCopyCopy4Copy
  {
    'o5zonqfa': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    '0bdssnzq': {
      'en': '',
      'fr': '',
    },
    'bfx8ysx9': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // CreateNewChatCopy2CopyCopyCopy5
  {
    '4oxnaine': {
      'en': 'Select a User to Chat',
      'fr': 'Sélectionnez un utilisateur pour discuter',
    },
    'jf0vsu4a': {
      'en': '',
      'fr': '',
    },
    'd5anqrij': {
      'en': 'Search members...',
      'fr': 'Rechercher des membres...',
    },
  },
  // Day2sessioncomp
  {
    'slykmnrq': {
      'en': 'Speakers',
      'fr': '',
    },
    'wce4kycp': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    'ljwrcuub': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    'f5thbkv1': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    '8kauq23t': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    'cq9v71zz': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    'ho99ayvk': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    'hfk1b3i1': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    'rk16cadn': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
    'q1si39r9': {
      'en': 'Moderators',
      'fr': '',
    },
    '1xz2g1pp': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    'j58ljrhp': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    '5tksxtnd': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    '9ul638ua': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    'monps1q8': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    'mskqabtz': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    'u7rx025j': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    'gzggvmwt': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
    'eyvahuzd': {
      'en': 'Chair panelist',
      'fr': '',
    },
    '9rf5ekoc': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    'hlmegzyy': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    'us717k9z': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    'pb2pv310': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    'h7hb1yi9': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    '7b5cnjc7': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    'gzawzfvr': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    '9m0hk416': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
  },
  // Day3sessioncomp
  {
    'pxzf1aiw': {
      'en': 'Speakers',
      'fr': '',
    },
    '9xmzd78q': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    'y5hpobx0': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    'j10f2p44': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    'uswyakqv': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    'szwqhux7': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    'dmf9fxrk': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    'jkwm7riv': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    'lpuy2wpx': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
    'j6ow10vd': {
      'en': 'Moderators',
      'fr': '',
    },
    'cvo8byi8': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    '4cng5pm3': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    '34zoztdz': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    '8hb2inpc': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    '5qj7inxl': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    'd4cs1c1c': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    '0qp0tkmo': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    'ay79szg1': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
    '2p4yygml': {
      'en': 'Chair panelist',
      'fr': '',
    },
    '6lz51mxh': {
      'en': 'Prof. Michael Chen',
      'fr': '',
    },
    'd8ud6ywg': {
      'en': 'Quantum Computing Expert, Stanford',
      'fr': '',
    },
    '3r7z0ljq': {
      'en': 'Dr. Emily Rodriguez',
      'fr': '',
    },
    '6n65butf': {
      'en': 'Neuroscience Director, Harvard',
      'fr': '',
    },
    'yptqdxnw': {
      'en': 'Dr. Raj Patel',
      'fr': '',
    },
    'jcqe4l0m': {
      'en': 'Climate Science Lead, Oxford',
      'fr': '',
    },
    'lncxi4yn': {
      'en': 'Dr. Lisa Zhang',
      'fr': '',
    },
    'j8lbmqk6': {
      'en': 'Robotics Engineer, Tesla',
      'fr': '',
    },
  },
  // Youtube
  {
    'd85wty4n': {
      'en': 'Videos',
      'fr': '',
    },
  },
  // confirmeet
  {
    'tw4vn09s': {
      'en': 'confirm the schedule timings',
      'fr': '',
    },
    '73dmshso': {
      'en': 'Confirm',
      'fr': '',
    },
  },
  // meetCopy2
  {
    '14nui0j9': {
      'en': 'TechVision Solutions',
      'fr': '',
    },
    't72ad290': {
      'en': 'Book Event',
      'fr': '',
    },
  },
  // gamecompletedsch
  {
    't2zrjb9b': {
      'en': '🎉',
      'fr': '',
    },
    'oyla1jxm': {
      'en': 'Game Completed!',
      'fr': '',
    },
    '5c7wkil3': {
      'en': 'Back',
      'fr': '',
    },
  },
  // UpdateUser
  {
    'ywufora8': {
      'en': 'Personal Information',
      'fr': '',
    },
    'dj63l6vn': {
      'en': 'Full Name',
      'fr': '',
    },
    'ce7n1frg': {
      'en': 'Comapny',
      'fr': '',
    },
    '39dcgch9': {
      'en': 'Email Address',
      'fr': '',
    },
    'nmlzvzuw': {
      'en': 'Phone Number',
      'fr': '',
    },
    'qrkrwcgt': {
      'en': 'Country',
      'fr': '',
    },
    'gdtcy303': {
      'en': 'India',
      'fr': '',
    },
    '79unofbq': {
      'en': 'Russia',
      'fr': '',
    },
    'oykfv7bq': {
      'en': 'Singapore',
      'fr': '',
    },
    'oz2bmxn0': {
      'en': 'Australia',
      'fr': '',
    },
    'l7cr4atz': {
      'en': 'Africa',
      'fr': '',
    },
    'o6gsofs2': {
      'en': 'Address',
      'fr': '',
    },
    'i74jx70c': {
      'en': 'India',
      'fr': '',
    },
    '99j39amv': {
      'en': 'Russia',
      'fr': '',
    },
    '0o4sfw1r': {
      'en': 'Singapore',
      'fr': '',
    },
    'llw62ksh': {
      'en': 'Australia',
      'fr': '',
    },
    'iiqcbeys': {
      'en': 'Africa',
      'fr': '',
    },
    'mu5jb79k': {
      'en': 'GST for ndian Delegates',
      'fr': '',
    },
    'gnclpr46': {
      'en': 'India',
      'fr': '',
    },
    'eetefzf1': {
      'en': 'Russia',
      'fr': '',
    },
    'xc1oudpb': {
      'en': 'Singapore',
      'fr': '',
    },
    '0vu66639': {
      'en': 'Australia',
      'fr': '',
    },
    'p4lev9mr': {
      'en': 'Africa',
      'fr': '',
    },
    'u33pt8r3': {
      'en': 'Role',
      'fr': '',
    },
    'djiw2lhm': {
      'en': 'Speakers',
      'fr': '',
    },
    'to3k3c6m': {
      'en': 'Admin',
      'fr': '',
    },
    'y86enf7b': {
      'en': 'Delegate',
      'fr': '',
    },
    'x0t55kzg': {
      'en': 'Cancel',
      'fr': '',
    },
    'izo751lx': {
      'en': 'Save Changes',
      'fr': '',
    },
  },
  // Miscellaneous
  {
    'r7370968': {
      'en':
          'We need access to your camera to scan QR codes or barcodes. Please allow access to continue.',
      'fr': '',
    },
    'i34qevl9': {
      'en':
          'We need access to your photo library to upload and select images. Please allow access to continue.',
      'fr': '',
    },
    'kbmo05wr': {
      'en':
          'We need your permission to send notifications so you can stay updated with important alerts and updates. Please allow access.',
      'fr': '',
    },
    '6cys5s3i': {
      'en':
          'We need access to your microphone to enable audio features and enhance your experience. Please allow access.',
      'fr': '',
    },
    's1gymhgj': {
      'en': '',
      'fr': '',
    },
    '3qt3ikr4': {
      'en': '',
      'fr': '',
    },
    'vdz14dc7': {
      'en': '',
      'fr': '',
    },
    '58k1wkpe': {
      'en': '',
      'fr': '',
    },
    'psktlmku': {
      'en': '',
      'fr': '',
    },
    '2kak55y9': {
      'en': '',
      'fr': '',
    },
    'wzyba44m': {
      'en': '',
      'fr': '',
    },
    'bt70ir65': {
      'en': '',
      'fr': '',
    },
    'aw1wob41': {
      'en': '',
      'fr': '',
    },
    '0u6c219x': {
      'en': '',
      'fr': '',
    },
    '4flwwy2q': {
      'en': '',
      'fr': '',
    },
    'ev25a9d7': {
      'en': '',
      'fr': '',
    },
    'evczkkl4': {
      'en': '',
      'fr': '',
    },
    'tx40iutu': {
      'en': '',
      'fr': '',
    },
    't1fkehp2': {
      'en': '',
      'fr': '',
    },
    'yy90mk64': {
      'en': '',
      'fr': '',
    },
    'kut9mmes': {
      'en': '',
      'fr': '',
    },
    'bnpl53v4': {
      'en': '',
      'fr': '',
    },
    'iaqzd5l9': {
      'en': '',
      'fr': '',
    },
    '242st1g4': {
      'en': '',
      'fr': '',
    },
    'zf68ecr3': {
      'en': '',
      'fr': '',
    },
    'ab2l50px': {
      'en': '',
      'fr': '',
    },
    'gs9hn5wz': {
      'en': '',
      'fr': '',
    },
    'hyeehuyz': {
      'en': '',
      'fr': '',
    },
    '2wsb702f': {
      'en': '',
      'fr': '',
    },
  },
].reduce((a, b) => a..addAll(b));
