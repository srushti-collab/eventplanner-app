import 'dart:async';

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';

import '/auth/base_auth_user_provider.dart';

import '/index.dart';
import '/main.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/lat_lng.dart';
import '/flutter_flow/place.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'serialization_util.dart';

export 'package:go_router/go_router.dart';
export 'serialization_util.dart';

const kTransitionInfoKey = '__transition_info__';

GlobalKey<NavigatorState> appNavigatorKey = GlobalKey<NavigatorState>();

class AppStateNotifier extends ChangeNotifier {
  AppStateNotifier._();

  static AppStateNotifier? _instance;
  static AppStateNotifier get instance => _instance ??= AppStateNotifier._();

  BaseAuthUser? initialUser;
  BaseAuthUser? user;
  bool showSplashImage = true;
  String? _redirectLocation;

  /// Determines whether the app will refresh and build again when a sign
  /// in or sign out happens. This is useful when the app is launched or
  /// on an unexpected logout. However, this must be turned off when we
  /// intend to sign in/out and then navigate or perform any actions after.
  /// Otherwise, this will trigger a refresh and interrupt the action(s).
  bool notifyOnAuthChange = true;

  bool get loading => user == null || showSplashImage;
  bool get loggedIn => user?.loggedIn ?? false;
  bool get initiallyLoggedIn => initialUser?.loggedIn ?? false;
  bool get shouldRedirect => loggedIn && _redirectLocation != null;

  String getRedirectLocation() => _redirectLocation!;
  bool hasRedirect() => _redirectLocation != null;
  void setRedirectLocationIfUnset(String loc) => _redirectLocation ??= loc;
  void clearRedirectLocation() => _redirectLocation = null;

  /// Mark as not needing to notify on a sign in / out when we intend
  /// to perform subsequent actions (such as navigation) afterwards.
  void updateNotifyOnAuthChange(bool notify) => notifyOnAuthChange = notify;

  void update(BaseAuthUser newUser) {
    final shouldUpdate =
        user?.uid == null || newUser.uid == null || user?.uid != newUser.uid;
    initialUser ??= newUser;
    user = newUser;
    // Refresh the app on auth change unless explicitly marked otherwise.
    // No need to update unless the user has changed.
    if (notifyOnAuthChange && shouldUpdate) {
      notifyListeners();
    }
    // Once again mark the notifier as needing to update on auth change
    // (in order to catch sign in / out events).
    updateNotifyOnAuthChange(true);
  }

  void stopShowingSplashImage() {
    showSplashImage = false;
    notifyListeners();
  }
}

GoRouter createRouter(AppStateNotifier appStateNotifier) => GoRouter(
      initialLocation: '/',
      debugLogDiagnostics: true,
      refreshListenable: appStateNotifier,
      navigatorKey: appNavigatorKey,
      errorBuilder: (context, state) =>
          appStateNotifier.loggedIn ? DashboardCopyWidget() : WelcomeWidget(),
      routes: [
        FFRoute(
          name: '_initialize',
          path: '/',
          builder: (context, _) => appStateNotifier.loggedIn
              ? DashboardCopyWidget()
              : WelcomeWidget(),
        ),
        FFRoute(
          name: 'Welcome',
          path: '/welcome',
          builder: (context, params) => WelcomeWidget(),
        ),
        FFRoute(
          name: 'day1Schedule',
          path: '/day1Schedule',
          builder: (context, params) => Day1ScheduleWidget(),
        ),
        FFRoute(
          name: 'sponsors',
          path: '/sponsors',
          builder: (context, params) => SponsorsWidget(),
        ),
        FFRoute(
          name: 'loginDashboard',
          path: '/loginDashboard',
          builder: (context, params) => LoginDashboardWidget(),
        ),
        FFRoute(
          name: 'delegates',
          path: '/delegates',
          builder: (context, params) => DelegatesWidget(),
        ),
        FFRoute(
          name: 'CHAT',
          path: '/chat',
          builder: (context, params) => ChatWidget(
            receiveChat: params.getParam(
              'receiveChat',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['chats'],
            ),
            detai: params.getParam(
              'detai',
              ParamType.String,
            ),
            name: params.getParam(
              'name',
              ParamType.String,
            ),
            chatreceiverr: params.getParam(
              'chatreceiverr',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: 'Chathome',
          path: '/chathome',
          builder: (context, params) => ChathomeWidget(
            delespeak: params.getParam(
              'delespeak',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: 'Sponsprof',
          path: '/sponsprof',
          builder: (context, params) => SponsprofWidget(
            sponsorprofile: params.getParam(
              'sponsorprofile',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Sponsors'],
            ),
            sponsname: params.getParam(
              'sponsname',
              ParamType.String,
            ),
            sponsimg: params.getParam<String>(
              'sponsimg',
              ParamType.String,
              isList: true,
            ),
            sponsimgdes: params.getParam<String>(
              'sponsimgdes',
              ParamType.String,
              isList: true,
            ),
          ),
        ),
        FFRoute(
          name: 'programopt',
          path: '/programopt',
          builder: (context, params) => ProgramoptWidget(),
        ),
        FFRoute(
          name: 'postPage',
          path: '/postPage',
          builder: (context, params) => PostPageWidget(
            postID: params.getParam(
              'postID',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['posts'],
            ),
          ),
        ),
        FFRoute(
          name: 'eventFeed',
          path: '/eventFeed',
          builder: (context, params) => EventFeedWidget(
            notification: params.getParam<DocumentReference>(
              'notification',
              ParamType.DocumentReference,
              isList: true,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: 'day2Schedule',
          path: '/day2Schedule',
          builder: (context, params) => Day2ScheduleWidget(),
        ),
        FFRoute(
          name: 'day3Schedule',
          path: '/day3Schedule',
          builder: (context, params) => Day3ScheduleWidget(),
        ),
        FFRoute(
          name: 'pfedit',
          path: '/pfedit',
          builder: (context, params) => PfeditWidget(),
        ),
        FFRoute(
          name: 'Bookmark',
          path: '/bookmark',
          builder: (context, params) => BookmarkWidget(
            bookmark: params.getParam(
              'bookmark',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: 'forgot_psd',
          path: '/forgotPsd',
          builder: (context, params) => ForgotPsdWidget(),
        ),
        FFRoute(
          name: 'Prof',
          path: '/prof',
          builder: (context, params) => ProfWidget(
            prof: params.getParam(
              'prof',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: 'profinfo',
          path: '/profinfo',
          asyncParams: {
            'delegates': getDoc(['users'], UsersRecord.fromSnapshot),
          },
          builder: (context, params) => ProfinfoWidget(
            delegates: params.getParam(
              'delegates',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: 'Myposts',
          path: '/myposts',
          builder: (context, params) => MypostsWidget(),
        ),
        FFRoute(
          name: 'speakerinfo',
          path: '/speakerinfo',
          asyncParams: {
            'speakers': getDoc(['Speakers'], SpeakersRecord.fromSnapshot),
          },
          builder: (context, params) => SpeakerinfoWidget(
            speakers: params.getParam(
              'speakers',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: 'Speaker1',
          path: '/speaker1',
          builder: (context, params) => Speaker1Widget(),
        ),
        FFRoute(
          name: 'CHATCopy',
          path: '/cHATCopy',
          builder: (context, params) => CHATCopyWidget(
            chatcreate: params.getParam(
              'chatcreate',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
            username: params.getParam(
              'username',
              ParamType.String,
            ),
            photourl: params.getParam(
              'photourl',
              ParamType.String,
            ),
            recievechat: params.getParam(
              'recievechat',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Chat2'],
            ),
          ),
        ),
        FFRoute(
          name: 'delegatesCopy',
          path: '/delegatesCopy',
          builder: (context, params) => DelegatesCopyWidget(),
        ),
        FFRoute(
          name: 'DashboardCopy',
          path: '/dashboardCopy',
          builder: (context, params) => DashboardCopyWidget(),
        ),
        FFRoute(
          name: 'SponsprofCopy',
          path: '/sponsprofCopy',
          builder: (context, params) => SponsprofCopyWidget(
            sponsorprofile: params.getParam(
              'sponsorprofile',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Sponsors'],
            ),
          ),
        ),
        FFRoute(
          name: 'ScavengerHunt',
          path: '/scavengerHunt',
          builder: (context, params) => ScavengerHuntWidget(),
        ),
        FFRoute(
          name: 'MyCalender',
          path: '/myCalender',
          builder: (context, params) => MyCalenderWidget(),
        ),
        FFRoute(
          name: 'profinfoCopy',
          path: '/profinfoCopy',
          asyncParams: {
            'speakers': getDoc(['users'], UsersRecord.fromSnapshot),
          },
          builder: (context, params) => ProfinfoCopyWidget(
            speakers: params.getParam(
              'speakers',
              ParamType.Document,
            ),
            recievechat: params.getParam(
              'recievechat',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['Chat2'],
            ),
          ),
        ),
        FFRoute(
          name: 'day2ScheduleCopy',
          path: '/day2ScheduleCopy',
          builder: (context, params) => Day2ScheduleCopyWidget(),
        ),
        FFRoute(
          name: 'day2ScheduleCopyCopy',
          path: '/day2ScheduleCopyCopy',
          builder: (context, params) => Day2ScheduleCopyCopyWidget(),
        ),
        FFRoute(
          name: 'LeaderBoard',
          path: '/leaderBoard',
          builder: (context, params) => LeaderBoardWidget(),
        ),
        FFRoute(
          name: 'invitation',
          path: '/invitation',
          builder: (context, params) => InvitationWidget(),
        ),
        FFRoute(
          name: 'CREATEPASSWORD',
          path: '/createpassword',
          builder: (context, params) => CreatepasswordWidget(),
        ),
        FFRoute(
          name: 'day1ScheSpeak',
          path: '/day1ScheSpeak',
          builder: (context, params) => Day1ScheSpeakWidget(
            speakSche: params.getParam(
              'speakSche',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['day1schedule'],
            ),
            sessiontitle: params.getParam(
              'sessiontitle',
              ParamType.String,
            ),
            sessionno: params.getParam(
              'sessionno',
              ParamType.String,
            ),
            sessiontime: params.getParam(
              'sessiontime',
              ParamType.DateTime,
            ),
          ),
        ),
        FFRoute(
          name: 'sessionspeakinfo',
          path: '/sessionspeakinfo',
          builder: (context, params) => SessionspeakinfoWidget(
            name: params.getParam<String>(
              'name',
              ParamType.String,
              isList: true,
            ),
            designation: params.getParam<String>(
              'designation',
              ParamType.String,
              isList: true,
            ),
            speakphoto: params.getParam<String>(
              'speakphoto',
              ParamType.String,
              isList: true,
            ),
            namespeak: params.getParam(
              'namespeak',
              ParamType.String,
            ),
            photo: params.getParam(
              'photo',
              ParamType.String,
            ),
          ),
        ),
        FFRoute(
          name: 'sponsorsCopy',
          path: '/Exhibitors',
          builder: (context, params) => SponsorsCopyWidget(),
        ),
        FFRoute(
          name: 'ChathomeCopy',
          path: '/chathomeCopy',
          builder: (context, params) => ChathomeCopyWidget(),
        ),
        FFRoute(
          name: 'profinfoCopyCopy',
          path: '/profinfoCopyCopy',
          asyncParams: {
            'delegates': getDoc(['users'], UsersRecord.fromSnapshot),
          },
          builder: (context, params) => ProfinfoCopyCopyWidget(
            delegates: params.getParam(
              'delegates',
              ParamType.Document,
            ),
          ),
        ),
        FFRoute(
          name: 'MyCalanderdupli',
          path: '/myCalanderdupli',
          builder: (context, params) => MyCalanderdupliWidget(),
        ),
        FFRoute(
          name: 'MyCalenderCopy',
          path: '/myCalenderCopy',
          builder: (context, params) => MyCalenderCopyWidget(),
        ),
        FFRoute(
          name: 'invitationCopy',
          path: '/invitationCopy',
          builder: (context, params) => InvitationCopyWidget(),
        ),
        FFRoute(
          name: 'CHATCopy2',
          path: '/cHATCopy2',
          builder: (context, params) => CHATCopy2Widget(
            receiveChat: params.getParam(
              'receiveChat',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['chats'],
            ),
            detai: params.getParam(
              'detai',
              ParamType.String,
            ),
            name: params.getParam(
              'name',
              ParamType.String,
            ),
            chatreceiverr: params.getParam(
              'chatreceiverr',
              ParamType.DocumentReference,
              isList: false,
              collectionNamePath: ['users'],
            ),
          ),
        ),
        FFRoute(
          name: 'ScavengerHuntCopy',
          path: '/scavengerHuntCopy',
          builder: (context, params) => ScavengerHuntCopyWidget(),
        ),
        FFRoute(
          name: 'admin',
          path: '/admin',
          builder: (context, params) => AdminWidget(),
        ),
        FFRoute(
          name: 'UserManage',
          path: '/userManage',
          builder: (context, params) => UserManageWidget(),
        ),
        FFRoute(
          name: 'sponser',
          path: '/sponser',
          builder: (context, params) => SponserWidget(),
        ),
        FFRoute(
          name: 'DashboardCopyCopy3',
          path: '/dashboardCopyCopy3',
          builder: (context, params) => DashboardCopyCopy3Widget(),
        ),
        FFRoute(
          name: 'loginDashboardCopy',
          path: '/loginDashboardCopy',
          builder: (context, params) => LoginDashboardCopyWidget(),
        )
      ].map((r) => r.toRoute(appStateNotifier)).toList(),
      observers: [routeObserver],
    );

extension NavParamExtensions on Map<String, String?> {
  Map<String, String> get withoutNulls => Map.fromEntries(
        entries
            .where((e) => e.value != null)
            .map((e) => MapEntry(e.key, e.value!)),
      );
}

extension NavigationExtensions on BuildContext {
  void goNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : goNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void pushNamedAuth(
    String name,
    bool mounted, {
    Map<String, String> pathParameters = const <String, String>{},
    Map<String, String> queryParameters = const <String, String>{},
    Object? extra,
    bool ignoreRedirect = false,
  }) =>
      !mounted || GoRouter.of(this).shouldRedirect(ignoreRedirect)
          ? null
          : pushNamed(
              name,
              pathParameters: pathParameters,
              queryParameters: queryParameters,
              extra: extra,
            );

  void safePop() {
    // If there is only one route on the stack, navigate to the initial
    // page instead of popping.
    if (canPop()) {
      pop();
    } else {
      go('/');
    }
  }
}

extension GoRouterExtensions on GoRouter {
  AppStateNotifier get appState => AppStateNotifier.instance;
  void prepareAuthEvent([bool ignoreRedirect = false]) =>
      appState.hasRedirect() && !ignoreRedirect
          ? null
          : appState.updateNotifyOnAuthChange(false);
  bool shouldRedirect(bool ignoreRedirect) =>
      !ignoreRedirect && appState.hasRedirect();
  void clearRedirectLocation() => appState.clearRedirectLocation();
  void setRedirectLocationIfUnset(String location) =>
      appState.updateNotifyOnAuthChange(false);
}

extension _GoRouterStateExtensions on GoRouterState {
  Map<String, dynamic> get extraMap =>
      extra != null ? extra as Map<String, dynamic> : {};
  Map<String, dynamic> get allParams => <String, dynamic>{}
    ..addAll(pathParameters)
    ..addAll(uri.queryParameters)
    ..addAll(extraMap);
  TransitionInfo get transitionInfo => extraMap.containsKey(kTransitionInfoKey)
      ? extraMap[kTransitionInfoKey] as TransitionInfo
      : TransitionInfo.appDefault();
}

class FFParameters {
  FFParameters(this.state, [this.asyncParams = const {}]);

  final GoRouterState state;
  final Map<String, Future<dynamic> Function(String)> asyncParams;

  Map<String, dynamic> futureParamValues = {};

  // Parameters are empty if the params map is empty or if the only parameter
  // present is the special extra parameter reserved for the transition info.
  bool get isEmpty =>
      state.allParams.isEmpty ||
      (state.allParams.length == 1 &&
          state.extraMap.containsKey(kTransitionInfoKey));
  bool isAsyncParam(MapEntry<String, dynamic> param) =>
      asyncParams.containsKey(param.key) && param.value is String;
  bool get hasFutures => state.allParams.entries.any(isAsyncParam);
  Future<bool> completeFutures() => Future.wait(
        state.allParams.entries.where(isAsyncParam).map(
          (param) async {
            final doc = await asyncParams[param.key]!(param.value)
                .onError((_, __) => null);
            if (doc != null) {
              futureParamValues[param.key] = doc;
              return true;
            }
            return false;
          },
        ),
      ).onError((_, __) => [false]).then((v) => v.every((e) => e));

  dynamic getParam<T>(
    String paramName,
    ParamType type, {
    bool isList = false,
    List<String>? collectionNamePath,
    StructBuilder<T>? structBuilder,
  }) {
    if (futureParamValues.containsKey(paramName)) {
      return futureParamValues[paramName];
    }
    if (!state.allParams.containsKey(paramName)) {
      return null;
    }
    final param = state.allParams[paramName];
    // Got parameter from `extras`, so just directly return it.
    if (param is! String) {
      return param;
    }
    // Return serialized value.
    return deserializeParam<T>(
      param,
      type,
      isList,
      collectionNamePath: collectionNamePath,
      structBuilder: structBuilder,
    );
  }
}

class FFRoute {
  const FFRoute({
    required this.name,
    required this.path,
    required this.builder,
    this.requireAuth = false,
    this.asyncParams = const {},
    this.routes = const [],
  });

  final String name;
  final String path;
  final bool requireAuth;
  final Map<String, Future<dynamic> Function(String)> asyncParams;
  final Widget Function(BuildContext, FFParameters) builder;
  final List<GoRoute> routes;

  GoRoute toRoute(AppStateNotifier appStateNotifier) => GoRoute(
        name: name,
        path: path,
        redirect: (context, state) {
          if (appStateNotifier.shouldRedirect) {
            final redirectLocation = appStateNotifier.getRedirectLocation();
            appStateNotifier.clearRedirectLocation();
            return redirectLocation;
          }

          if (requireAuth && !appStateNotifier.loggedIn) {
            appStateNotifier.setRedirectLocationIfUnset(state.uri.toString());
            return '/welcome';
          }
          return null;
        },
        pageBuilder: (context, state) {
          fixStatusBarOniOS16AndBelow(context);
          final ffParams = FFParameters(state, asyncParams);
          final page = ffParams.hasFutures
              ? FutureBuilder(
                  future: ffParams.completeFutures(),
                  builder: (context, _) => builder(context, ffParams),
                )
              : builder(context, ffParams);
          final child = appStateNotifier.loading
              ? Container(
                  color: Colors.transparent,
                  child: Image.asset(
                    'assets/images/NETWROK_2.jpg',
                    fit: BoxFit.contain,
                  ),
                )
              : page;

          final transitionInfo = state.transitionInfo;
          return transitionInfo.hasTransition
              ? CustomTransitionPage(
                  key: state.pageKey,
                  child: child,
                  transitionDuration: transitionInfo.duration,
                  transitionsBuilder:
                      (context, animation, secondaryAnimation, child) =>
                          PageTransition(
                    type: transitionInfo.transitionType,
                    duration: transitionInfo.duration,
                    reverseDuration: transitionInfo.duration,
                    alignment: transitionInfo.alignment,
                    child: child,
                  ).buildTransitions(
                    context,
                    animation,
                    secondaryAnimation,
                    child,
                  ),
                )
              : MaterialPage(key: state.pageKey, child: child);
        },
        routes: routes,
      );
}

class TransitionInfo {
  const TransitionInfo({
    required this.hasTransition,
    this.transitionType = PageTransitionType.fade,
    this.duration = const Duration(milliseconds: 300),
    this.alignment,
  });

  final bool hasTransition;
  final PageTransitionType transitionType;
  final Duration duration;
  final Alignment? alignment;

  static TransitionInfo appDefault() => TransitionInfo(hasTransition: false);
}

class RootPageContext {
  const RootPageContext(this.isRootPage, [this.errorRoute]);
  final bool isRootPage;
  final String? errorRoute;

  static bool isInactiveRootPage(BuildContext context) {
    final rootPageContext = context.read<RootPageContext?>();
    final isRootPage = rootPageContext?.isRootPage ?? false;
    final location = GoRouterState.of(context).uri.toString();
    return isRootPage &&
        location != '/' &&
        location != rootPageContext?.errorRoute;
  }

  static Widget wrap(Widget child, {String? errorRoute}) => Provider.value(
        value: RootPageContext(true, errorRoute),
        child: child,
      );
}

extension GoRouterLocationExtension on GoRouter {
  String getCurrentLocation() {
    final RouteMatch lastMatch = routerDelegate.currentConfiguration.last;
    final RouteMatchList matchList = lastMatch is ImperativeRouteMatch
        ? lastMatch.matches
        : routerDelegate.currentConfiguration;
    return matchList.uri.toString();
  }
}
