import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/auth/firebase_auth/auth_util.dart';

List<DocumentReference> newCustomFunction(
  DocumentReference authUser,
  DocumentReference otherUsers,
) {
  return [authUser, otherUsers];
}

List<String> newCustomFunction2(
  String authUserName,
  String otherUserName,
) {
  return [authUserName, otherUserName];
}

String newCustomFunction3(
  List<String> listOfNames,
  String authUserName,
) {
  return authUserName == listOfNames.first
      ? listOfNames.last
      : listOfNames.first;
}

DocumentReference newCustomFunction4(
  List<DocumentReference> listOfUserReferences,
  DocumentReference authUserRef,
) {
  return authUserRef == listOfUserReferences.first
      ? listOfUserReferences.last
      : listOfUserReferences.first;
}

List<DocumentReference> newCustomFunction5(
  DocumentReference authUser,
  DocumentReference otherUser,
) {
  return [authUser, otherUser];
}

String? naya() {
  List<Map<String, dynamic>> removeDuplicates(
      List<Map<String, dynamic>> inputList, String uniqueKey) {
    final seenKeys = <dynamic>{};
    return inputList.where((item) => seenKeys.add(item[uniqueKey])).toList();
  }
}

String? getTextStyle(bool? isNew) {
  TextStyle getTextStyle(bool isNew) {
    return TextStyle(
      fontWeight: isNew ? FontWeight.bold : FontWeight.normal,
      color: isNew
          ? Color(0xFF000000)
          : Color(0xFF808080), // Change colors as needed
    );
  }
}

List<DateTime>? getAvailableBookings(
  List<DateTime> reservedRequests,
  DateTime starrtDate,
) {
  // check my code and return values
  List<DateTime> availableBookings = [];
  for (int i = 0; i < reservedRequests.length - 1; i++) {
    DateTime start = reservedRequests[i];
    DateTime end = reservedRequests[i + 1];
    if (starrtDate.isBefore(start) || starrtDate.isAfter(end)) {
      availableBookings.add(starrtDate);
    }
  }
  return availableBookings;
}
