import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/components/gamecompletedsch_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'dart:ui';
import 'scavenger_hunt_widget.dart' show ScavengerHuntWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_barcode_scanner/flutter_barcode_scanner.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:webviewx_plus/webviewx_plus.dart';

class ScavengerHuntModel extends FlutterFlowModel<ScavengerHuntWidget> {
  ///  State fields for stateful widgets in this page.

  var gamecode = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
