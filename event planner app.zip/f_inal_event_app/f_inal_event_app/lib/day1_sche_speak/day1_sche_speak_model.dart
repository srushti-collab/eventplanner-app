import '/components/day1sessioncomp_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import 'day1_sche_speak_widget.dart' show Day1ScheSpeakWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class Day1ScheSpeakModel extends FlutterFlowModel<Day1ScheSpeakWidget> {
  ///  State fields for stateful widgets in this page.

  // Model for Day1sessioncomp component.
  late Day1sessioncompModel day1sessioncompModel;

  @override
  void initState(BuildContext context) {
    day1sessioncompModel = createModel(context, () => Day1sessioncompModel());
  }

  @override
  void dispose() {
    day1sessioncompModel.dispose();
  }
}
