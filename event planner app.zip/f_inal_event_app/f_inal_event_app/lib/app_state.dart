import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/api_requests/api_manager.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    prefs = await SharedPreferences.getInstance();
    _safeInit(() {
      _Bookmark = prefs
              .getStringList('ff_Bookmark')
              ?.map((path) => path.ref)
              .toList() ??
          _Bookmark;
    });
    _safeInit(() {
      _chats =
          prefs.getStringList('ff_chats')?.map((path) => path.ref).toList() ??
              _chats;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late SharedPreferences prefs;

  bool _radiobutt = false;
  bool get radiobutt => _radiobutt;
  set radiobutt(bool value) {
    _radiobutt = value;
  }

  bool _searchActive = false;
  bool get searchActive => _searchActive;
  set searchActive(bool value) {
    _searchActive = value;
  }

  bool _searchActive2 = false;
  bool get searchActive2 => _searchActive2;
  set searchActive2(bool value) {
    _searchActive2 = value;
  }

  List<DocumentReference> _Bookmark = [];
  List<DocumentReference> get Bookmark => _Bookmark;
  set Bookmark(List<DocumentReference> value) {
    _Bookmark = value;
    prefs.setStringList('ff_Bookmark', value.map((x) => x.path).toList());
  }

  void addToBookmark(DocumentReference value) {
    Bookmark.add(value);
    prefs.setStringList('ff_Bookmark', _Bookmark.map((x) => x.path).toList());
  }

  void removeFromBookmark(DocumentReference value) {
    Bookmark.remove(value);
    prefs.setStringList('ff_Bookmark', _Bookmark.map((x) => x.path).toList());
  }

  void removeAtIndexFromBookmark(int index) {
    Bookmark.removeAt(index);
    prefs.setStringList('ff_Bookmark', _Bookmark.map((x) => x.path).toList());
  }

  void updateBookmarkAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    Bookmark[index] = updateFn(_Bookmark[index]);
    prefs.setStringList('ff_Bookmark', _Bookmark.map((x) => x.path).toList());
  }

  void insertAtIndexInBookmark(int index, DocumentReference value) {
    Bookmark.insert(index, value);
    prefs.setStringList('ff_Bookmark', _Bookmark.map((x) => x.path).toList());
  }

  String _Colors1 = '#00FF00';
  String get Colors1 => _Colors1;
  set Colors1(String value) {
    _Colors1 = value;
  }

  String _Colors2 = '#FFFF00';
  String get Colors2 => _Colors2;
  set Colors2(String value) {
    _Colors2 = value;
  }

  List<DocumentReference> _chats = [];
  List<DocumentReference> get chats => _chats;
  set chats(List<DocumentReference> value) {
    _chats = value;
    prefs.setStringList('ff_chats', value.map((x) => x.path).toList());
  }

  void addToChats(DocumentReference value) {
    chats.add(value);
    prefs.setStringList('ff_chats', _chats.map((x) => x.path).toList());
  }

  void removeFromChats(DocumentReference value) {
    chats.remove(value);
    prefs.setStringList('ff_chats', _chats.map((x) => x.path).toList());
  }

  void removeAtIndexFromChats(int index) {
    chats.removeAt(index);
    prefs.setStringList('ff_chats', _chats.map((x) => x.path).toList());
  }

  void updateChatsAtIndex(
    int index,
    DocumentReference Function(DocumentReference) updateFn,
  ) {
    chats[index] = updateFn(_chats[index]);
    prefs.setStringList('ff_chats', _chats.map((x) => x.path).toList());
  }

  void insertAtIndexInChats(int index, DocumentReference value) {
    chats.insert(index, value);
    prefs.setStringList('ff_chats', _chats.map((x) => x.path).toList());
  }

  List<String> _selecteditem = [];
  List<String> get selecteditem => _selecteditem;
  set selecteditem(List<String> value) {
    _selecteditem = value;
  }

  void addToSelecteditem(String value) {
    selecteditem.add(value);
  }

  void removeFromSelecteditem(String value) {
    selecteditem.remove(value);
  }

  void removeAtIndexFromSelecteditem(int index) {
    selecteditem.removeAt(index);
  }

  void updateSelecteditemAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    selecteditem[index] = updateFn(_selecteditem[index]);
  }

  void insertAtIndexInSelecteditem(int index, String value) {
    selecteditem.insert(index, value);
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}
