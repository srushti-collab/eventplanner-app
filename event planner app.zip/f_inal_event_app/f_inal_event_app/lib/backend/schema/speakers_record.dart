import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SpeakersRecord extends FirestoreRecord {
  SpeakersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  bool hasBio() => _bio != null;

  // "profileImageUrl" field.
  String? _profileImageUrl;
  String get profileImageUrl => _profileImageUrl ?? '';
  bool hasProfileImageUrl() => _profileImageUrl != null;

  // "sessionIds" field.
  String? _sessionIds;
  String get sessionIds => _sessionIds ?? '';
  bool hasSessionIds() => _sessionIds != null;

  // "profileimage" field.
  String? _profileimage;
  String get profileimage => _profileimage ?? '';
  bool hasProfileimage() => _profileimage != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _bio = snapshotData['bio'] as String?;
    _profileImageUrl = snapshotData['profileImageUrl'] as String?;
    _sessionIds = snapshotData['sessionIds'] as String?;
    _profileimage = snapshotData['profileimage'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Speakers');

  static Stream<SpeakersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SpeakersRecord.fromSnapshot(s));

  static Future<SpeakersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SpeakersRecord.fromSnapshot(s));

  static SpeakersRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SpeakersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SpeakersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SpeakersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SpeakersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SpeakersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSpeakersRecordData({
  String? name,
  String? bio,
  String? profileImageUrl,
  String? sessionIds,
  String? profileimage,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'bio': bio,
      'profileImageUrl': profileImageUrl,
      'sessionIds': sessionIds,
      'profileimage': profileimage,
    }.withoutNulls,
  );

  return firestoreData;
}

class SpeakersRecordDocumentEquality implements Equality<SpeakersRecord> {
  const SpeakersRecordDocumentEquality();

  @override
  bool equals(SpeakersRecord? e1, SpeakersRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.bio == e2?.bio &&
        e1?.profileImageUrl == e2?.profileImageUrl &&
        e1?.sessionIds == e2?.sessionIds &&
        e1?.profileimage == e2?.profileimage;
  }

  @override
  int hash(SpeakersRecord? e) => const ListEquality().hash(
      [e?.name, e?.bio, e?.profileImageUrl, e?.sessionIds, e?.profileimage]);

  @override
  bool isValidKey(Object? o) => o is SpeakersRecord;
}
