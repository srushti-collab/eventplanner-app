import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ScavengerhuntRecord extends FirestoreRecord {
  ScavengerhuntRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "QR_LIST" field.
  List<DocumentReference>? _qrList;
  List<DocumentReference> get qrList => _qrList ?? const [];
  bool hasQrList() => _qrList != null;

  void _initializeFields() {
    _qrList = getDataList(snapshotData['QR_LIST']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('scavengerhunt');

  static Stream<ScavengerhuntRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ScavengerhuntRecord.fromSnapshot(s));

  static Future<ScavengerhuntRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ScavengerhuntRecord.fromSnapshot(s));

  static ScavengerhuntRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ScavengerhuntRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ScavengerhuntRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ScavengerhuntRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ScavengerhuntRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ScavengerhuntRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createScavengerhuntRecordData() {
  final firestoreData = mapToFirestore(
    <String, dynamic>{}.withoutNulls,
  );

  return firestoreData;
}

class ScavengerhuntRecordDocumentEquality
    implements Equality<ScavengerhuntRecord> {
  const ScavengerhuntRecordDocumentEquality();

  @override
  bool equals(ScavengerhuntRecord? e1, ScavengerhuntRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.qrList, e2?.qrList);
  }

  @override
  int hash(ScavengerhuntRecord? e) => const ListEquality().hash([e?.qrList]);

  @override
  bool isValidKey(Object? o) => o is ScavengerhuntRecord;
}
