import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ThemeRecord extends FirestoreRecord {
  ThemeRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "welcome" field.
  String? _welcome;
  String get welcome => _welcome ?? '';
  bool hasWelcome() => _welcome != null;

  // "bannerHeader" field.
  String? _bannerHeader;
  String get bannerHeader => _bannerHeader ?? '';
  bool hasBannerHeader() => _bannerHeader != null;

  // "bannerDate" field.
  String? _bannerDate;
  String get bannerDate => _bannerDate ?? '';
  bool hasBannerDate() => _bannerDate != null;

  // "bannerLocation" field.
  String? _bannerLocation;
  String get bannerLocation => _bannerLocation ?? '';
  bool hasBannerLocation() => _bannerLocation != null;

  // "programLine1" field.
  String? _programLine1;
  String get programLine1 => _programLine1 ?? '';
  bool hasProgramLine1() => _programLine1 != null;

  // "programLine2" field.
  String? _programLine2;
  String get programLine2 => _programLine2 ?? '';
  bool hasProgramLine2() => _programLine2 != null;

  // "image1" field.
  String? _image1;
  String get image1 => _image1 ?? '';
  bool hasImage1() => _image1 != null;

  // "image2" field.
  String? _image2;
  String get image2 => _image2 ?? '';
  bool hasImage2() => _image2 != null;

  // "image3" field.
  String? _image3;
  String get image3 => _image3 ?? '';
  bool hasImage3() => _image3 != null;

  // "image4" field.
  String? _image4;
  String get image4 => _image4 ?? '';
  bool hasImage4() => _image4 != null;

  // "image5" field.
  String? _image5;
  String get image5 => _image5 ?? '';
  bool hasImage5() => _image5 != null;

  // "image6" field.
  String? _image6;
  String get image6 => _image6 ?? '';
  bool hasImage6() => _image6 != null;

  // "image7" field.
  String? _image7;
  String get image7 => _image7 ?? '';
  bool hasImage7() => _image7 != null;

  // "image8" field.
  String? _image8;
  String get image8 => _image8 ?? '';
  bool hasImage8() => _image8 != null;

  // "CenterLogo" field.
  String? _centerLogo;
  String get centerLogo => _centerLogo ?? '';
  bool hasCenterLogo() => _centerLogo != null;

  void _initializeFields() {
    _welcome = snapshotData['welcome'] as String?;
    _bannerHeader = snapshotData['bannerHeader'] as String?;
    _bannerDate = snapshotData['bannerDate'] as String?;
    _bannerLocation = snapshotData['bannerLocation'] as String?;
    _programLine1 = snapshotData['programLine1'] as String?;
    _programLine2 = snapshotData['programLine2'] as String?;
    _image1 = snapshotData['image1'] as String?;
    _image2 = snapshotData['image2'] as String?;
    _image3 = snapshotData['image3'] as String?;
    _image4 = snapshotData['image4'] as String?;
    _image5 = snapshotData['image5'] as String?;
    _image6 = snapshotData['image6'] as String?;
    _image7 = snapshotData['image7'] as String?;
    _image8 = snapshotData['image8'] as String?;
    _centerLogo = snapshotData['CenterLogo'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('theme');

  static Stream<ThemeRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ThemeRecord.fromSnapshot(s));

  static Future<ThemeRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ThemeRecord.fromSnapshot(s));

  static ThemeRecord fromSnapshot(DocumentSnapshot snapshot) => ThemeRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ThemeRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ThemeRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ThemeRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ThemeRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createThemeRecordData({
  String? welcome,
  String? bannerHeader,
  String? bannerDate,
  String? bannerLocation,
  String? programLine1,
  String? programLine2,
  String? image1,
  String? image2,
  String? image3,
  String? image4,
  String? image5,
  String? image6,
  String? image7,
  String? image8,
  String? centerLogo,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'welcome': welcome,
      'bannerHeader': bannerHeader,
      'bannerDate': bannerDate,
      'bannerLocation': bannerLocation,
      'programLine1': programLine1,
      'programLine2': programLine2,
      'image1': image1,
      'image2': image2,
      'image3': image3,
      'image4': image4,
      'image5': image5,
      'image6': image6,
      'image7': image7,
      'image8': image8,
      'CenterLogo': centerLogo,
    }.withoutNulls,
  );

  return firestoreData;
}

class ThemeRecordDocumentEquality implements Equality<ThemeRecord> {
  const ThemeRecordDocumentEquality();

  @override
  bool equals(ThemeRecord? e1, ThemeRecord? e2) {
    return e1?.welcome == e2?.welcome &&
        e1?.bannerHeader == e2?.bannerHeader &&
        e1?.bannerDate == e2?.bannerDate &&
        e1?.bannerLocation == e2?.bannerLocation &&
        e1?.programLine1 == e2?.programLine1 &&
        e1?.programLine2 == e2?.programLine2 &&
        e1?.image1 == e2?.image1 &&
        e1?.image2 == e2?.image2 &&
        e1?.image3 == e2?.image3 &&
        e1?.image4 == e2?.image4 &&
        e1?.image5 == e2?.image5 &&
        e1?.image6 == e2?.image6 &&
        e1?.image7 == e2?.image7 &&
        e1?.image8 == e2?.image8 &&
        e1?.centerLogo == e2?.centerLogo;
  }

  @override
  int hash(ThemeRecord? e) => const ListEquality().hash([
        e?.welcome,
        e?.bannerHeader,
        e?.bannerDate,
        e?.bannerLocation,
        e?.programLine1,
        e?.programLine2,
        e?.image1,
        e?.image2,
        e?.image3,
        e?.image4,
        e?.image5,
        e?.image6,
        e?.image7,
        e?.image8,
        e?.centerLogo
      ]);

  @override
  bool isValidKey(Object? o) => o is ThemeRecord;
}
