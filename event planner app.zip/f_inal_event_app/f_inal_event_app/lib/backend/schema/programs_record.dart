import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProgramsRecord extends FirestoreRecord {
  ProgramsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "imageurl" field.
  String? _imageurl;
  String get imageurl => _imageurl ?? '';
  bool hasImageurl() => _imageurl != null;

  // "date" field.
  String? _date;
  String get date => _date ?? '';
  bool hasDate() => _date != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  // "daytitle" field.
  String? _daytitle;
  String get daytitle => _daytitle ?? '';
  bool hasDaytitle() => _daytitle != null;

  // "theme" field.
  String? _theme;
  String get theme => _theme ?? '';
  bool hasTheme() => _theme != null;

  // "programImage" field.
  String? _programImage;
  String get programImage => _programImage ?? '';
  bool hasProgramImage() => _programImage != null;

  // "day" field.
  String? _day;
  String get day => _day ?? '';
  bool hasDay() => _day != null;

  // "time" field.
  String? _time;
  String get time => _time ?? '';
  bool hasTime() => _time != null;

  void _initializeFields() {
    _imageurl = snapshotData['imageurl'] as String?;
    _date = snapshotData['date'] as String?;
    _location = snapshotData['location'] as String?;
    _daytitle = snapshotData['daytitle'] as String?;
    _theme = snapshotData['theme'] as String?;
    _programImage = snapshotData['programImage'] as String?;
    _day = snapshotData['day'] as String?;
    _time = snapshotData['time'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('programs');

  static Stream<ProgramsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ProgramsRecord.fromSnapshot(s));

  static Future<ProgramsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ProgramsRecord.fromSnapshot(s));

  static ProgramsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      ProgramsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ProgramsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ProgramsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ProgramsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ProgramsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createProgramsRecordData({
  String? imageurl,
  String? date,
  String? location,
  String? daytitle,
  String? theme,
  String? programImage,
  String? day,
  String? time,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'imageurl': imageurl,
      'date': date,
      'location': location,
      'daytitle': daytitle,
      'theme': theme,
      'programImage': programImage,
      'day': day,
      'time': time,
    }.withoutNulls,
  );

  return firestoreData;
}

class ProgramsRecordDocumentEquality implements Equality<ProgramsRecord> {
  const ProgramsRecordDocumentEquality();

  @override
  bool equals(ProgramsRecord? e1, ProgramsRecord? e2) {
    return e1?.imageurl == e2?.imageurl &&
        e1?.date == e2?.date &&
        e1?.location == e2?.location &&
        e1?.daytitle == e2?.daytitle &&
        e1?.theme == e2?.theme &&
        e1?.programImage == e2?.programImage &&
        e1?.day == e2?.day &&
        e1?.time == e2?.time;
  }

  @override
  int hash(ProgramsRecord? e) => const ListEquality().hash([
        e?.imageurl,
        e?.date,
        e?.location,
        e?.daytitle,
        e?.theme,
        e?.programImage,
        e?.day,
        e?.time
      ]);

  @override
  bool isValidKey(Object? o) => o is ProgramsRecord;
}
