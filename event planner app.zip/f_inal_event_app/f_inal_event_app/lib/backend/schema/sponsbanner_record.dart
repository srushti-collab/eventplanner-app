import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SponsbannerRecord extends FirestoreRecord {
  SponsbannerRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "Banner" field.
  String? _banner;
  String get banner => _banner ?? '';
  bool hasBanner() => _banner != null;

  // "BannerNum" field.
  String? _bannerNum;
  String get bannerNum => _bannerNum ?? '';
  bool hasBannerNum() => _bannerNum != null;

  void _initializeFields() {
    _banner = snapshotData['Banner'] as String?;
    _bannerNum = snapshotData['BannerNum'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('sponsbanner');

  static Stream<SponsbannerRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SponsbannerRecord.fromSnapshot(s));

  static Future<SponsbannerRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SponsbannerRecord.fromSnapshot(s));

  static SponsbannerRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SponsbannerRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SponsbannerRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SponsbannerRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SponsbannerRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SponsbannerRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSponsbannerRecordData({
  String? banner,
  String? bannerNum,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'Banner': banner,
      'BannerNum': bannerNum,
    }.withoutNulls,
  );

  return firestoreData;
}

class SponsbannerRecordDocumentEquality implements Equality<SponsbannerRecord> {
  const SponsbannerRecordDocumentEquality();

  @override
  bool equals(SponsbannerRecord? e1, SponsbannerRecord? e2) {
    return e1?.banner == e2?.banner && e1?.bannerNum == e2?.bannerNum;
  }

  @override
  int hash(SponsbannerRecord? e) =>
      const ListEquality().hash([e?.banner, e?.bannerNum]);

  @override
  bool isValidKey(Object? o) => o is SponsbannerRecord;
}
