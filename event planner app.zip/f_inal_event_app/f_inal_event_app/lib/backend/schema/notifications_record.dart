import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class NotificationsRecord extends FirestoreRecord {
  NotificationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "uderId" field.
  DocumentReference? _uderId;
  DocumentReference? get uderId => _uderId;
  bool hasUderId() => _uderId != null;

  // "postId" field.
  DocumentReference? _postId;
  DocumentReference? get postId => _postId;
  bool hasPostId() => _postId != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "userlists" field.
  List<DocumentReference>? _userlists;
  List<DocumentReference> get userlists => _userlists ?? const [];
  bool hasUserlists() => _userlists != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _uderId = snapshotData['uderId'] as DocumentReference?;
    _postId = snapshotData['postId'] as DocumentReference?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _userlists = getDataList(snapshotData['userlists']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('notifications')
          : FirebaseFirestore.instance.collectionGroup('notifications');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('notifications').doc(id);

  static Stream<NotificationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => NotificationsRecord.fromSnapshot(s));

  static Future<NotificationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => NotificationsRecord.fromSnapshot(s));

  static NotificationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      NotificationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static NotificationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      NotificationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'NotificationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is NotificationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createNotificationsRecordData({
  DocumentReference? uderId,
  DocumentReference? postId,
  DateTime? timestamp,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'uderId': uderId,
      'postId': postId,
      'timestamp': timestamp,
    }.withoutNulls,
  );

  return firestoreData;
}

class NotificationsRecordDocumentEquality
    implements Equality<NotificationsRecord> {
  const NotificationsRecordDocumentEquality();

  @override
  bool equals(NotificationsRecord? e1, NotificationsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.uderId == e2?.uderId &&
        e1?.postId == e2?.postId &&
        e1?.timestamp == e2?.timestamp &&
        listEquality.equals(e1?.userlists, e2?.userlists);
  }

  @override
  int hash(NotificationsRecord? e) => const ListEquality()
      .hash([e?.uderId, e?.postId, e?.timestamp, e?.userlists]);

  @override
  bool isValidKey(Object? o) => o is NotificationsRecord;
}
