import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class EngagedwithRecord extends FirestoreRecord {
  EngagedwithRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "id" field.
  DocumentReference? _id;
  DocumentReference? get id => _id;
  bool hasId() => _id != null;

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  bool hasPhoto() => _photo != null;

  // "chatID" field.
  DocumentReference? _chatID;
  DocumentReference? get chatID => _chatID;
  bool hasChatID() => _chatID != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _id = snapshotData['id'] as DocumentReference?;
    _photo = snapshotData['photo'] as String?;
    _chatID = snapshotData['chatID'] as DocumentReference?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('engagedwith')
          : FirebaseFirestore.instance.collectionGroup('engagedwith');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('engagedwith').doc(id);

  static Stream<EngagedwithRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => EngagedwithRecord.fromSnapshot(s));

  static Future<EngagedwithRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => EngagedwithRecord.fromSnapshot(s));

  static EngagedwithRecord fromSnapshot(DocumentSnapshot snapshot) =>
      EngagedwithRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static EngagedwithRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      EngagedwithRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'EngagedwithRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is EngagedwithRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createEngagedwithRecordData({
  String? name,
  DocumentReference? id,
  String? photo,
  DocumentReference? chatID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'id': id,
      'photo': photo,
      'chatID': chatID,
    }.withoutNulls,
  );

  return firestoreData;
}

class EngagedwithRecordDocumentEquality implements Equality<EngagedwithRecord> {
  const EngagedwithRecordDocumentEquality();

  @override
  bool equals(EngagedwithRecord? e1, EngagedwithRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.id == e2?.id &&
        e1?.photo == e2?.photo &&
        e1?.chatID == e2?.chatID;
  }

  @override
  int hash(EngagedwithRecord? e) =>
      const ListEquality().hash([e?.name, e?.id, e?.photo, e?.chatID]);

  @override
  bool isValidKey(Object? o) => o is EngagedwithRecord;
}
