import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class AttendanceRecord extends FirestoreRecord {
  AttendanceRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "uid" field.
  DocumentReference? _uid;
  DocumentReference? get uid => _uid;
  bool hasUid() => _uid != null;

  // "day1" field.
  bool? _day1;
  bool get day1 => _day1 ?? false;
  bool hasDay1() => _day1 != null;

  // "day2" field.
  bool? _day2;
  bool get day2 => _day2 ?? false;
  bool hasDay2() => _day2 != null;

  // "day3" field.
  bool? _day3;
  bool get day3 => _day3 ?? false;
  bool hasDay3() => _day3 != null;

  void _initializeFields() {
    _uid = snapshotData['uid'] as DocumentReference?;
    _day1 = snapshotData['day1'] as bool?;
    _day2 = snapshotData['day2'] as bool?;
    _day3 = snapshotData['day3'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('attendance');

  static Stream<AttendanceRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => AttendanceRecord.fromSnapshot(s));

  static Future<AttendanceRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => AttendanceRecord.fromSnapshot(s));

  static AttendanceRecord fromSnapshot(DocumentSnapshot snapshot) =>
      AttendanceRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static AttendanceRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      AttendanceRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'AttendanceRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is AttendanceRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createAttendanceRecordData({
  DocumentReference? uid,
  bool? day1,
  bool? day2,
  bool? day3,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'uid': uid,
      'day1': day1,
      'day2': day2,
      'day3': day3,
    }.withoutNulls,
  );

  return firestoreData;
}

class AttendanceRecordDocumentEquality implements Equality<AttendanceRecord> {
  const AttendanceRecordDocumentEquality();

  @override
  bool equals(AttendanceRecord? e1, AttendanceRecord? e2) {
    return e1?.uid == e2?.uid &&
        e1?.day1 == e2?.day1 &&
        e1?.day2 == e2?.day2 &&
        e1?.day3 == e2?.day3;
  }

  @override
  int hash(AttendanceRecord? e) =>
      const ListEquality().hash([e?.uid, e?.day1, e?.day2, e?.day3]);

  @override
  bool isValidKey(Object? o) => o is AttendanceRecord;
}
