import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PostsRecord extends FirestoreRecord {
  PostsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "postImage" field.
  String? _postImage;
  String get postImage => _postImage ?? '';
  bool hasPostImage() => _postImage != null;

  // "postVideo" field.
  String? _postVideo;
  String get postVideo => _postVideo ?? '';
  bool hasPostVideo() => _postVideo != null;

  // "postUser" field.
  DocumentReference? _postUser;
  DocumentReference? get postUser => _postUser;
  bool hasPostUser() => _postUser != null;

  // "usersShares" field.
  String? _usersShares;
  String get usersShares => _usersShares ?? '';
  bool hasUsersShares() => _usersShares != null;

  // "postText" field.
  String? _postText;
  String get postText => _postText ?? '';
  bool hasPostText() => _postText != null;

  // "postUsername" field.
  String? _postUsername;
  String get postUsername => _postUsername ?? '';
  bool hasPostUsername() => _postUsername != null;

  // "postUserimage" field.
  String? _postUserimage;
  String get postUserimage => _postUserimage ?? '';
  bool hasPostUserimage() => _postUserimage != null;

  // "userLikes" field.
  List<DocumentReference>? _userLikes;
  List<DocumentReference> get userLikes => _userLikes ?? const [];
  bool hasUserLikes() => _userLikes != null;

  // "userBookmarks" field.
  List<DocumentReference>? _userBookmarks;
  List<DocumentReference> get userBookmarks => _userBookmarks ?? const [];
  bool hasUserBookmarks() => _userBookmarks != null;

  // "createdTime" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "posterName" field.
  String? _posterName;
  String get posterName => _posterName ?? '';
  bool hasPosterName() => _posterName != null;

  // "comments" field.
  int? _comments;
  int get comments => _comments ?? 0;
  bool hasComments() => _comments != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  void _initializeFields() {
    _postImage = snapshotData['postImage'] as String?;
    _postVideo = snapshotData['postVideo'] as String?;
    _postUser = snapshotData['postUser'] as DocumentReference?;
    _usersShares = snapshotData['usersShares'] as String?;
    _postText = snapshotData['postText'] as String?;
    _postUsername = snapshotData['postUsername'] as String?;
    _postUserimage = snapshotData['postUserimage'] as String?;
    _userLikes = getDataList(snapshotData['userLikes']);
    _userBookmarks = getDataList(snapshotData['userBookmarks']);
    _createdTime = snapshotData['createdTime'] as DateTime?;
    _posterName = snapshotData['posterName'] as String?;
    _comments = castToType<int>(snapshotData['comments']);
    _uid = snapshotData['uid'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('posts');

  static Stream<PostsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PostsRecord.fromSnapshot(s));

  static Future<PostsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => PostsRecord.fromSnapshot(s));

  static PostsRecord fromSnapshot(DocumentSnapshot snapshot) => PostsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PostsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PostsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PostsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PostsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPostsRecordData({
  String? postImage,
  String? postVideo,
  DocumentReference? postUser,
  String? usersShares,
  String? postText,
  String? postUsername,
  String? postUserimage,
  DateTime? createdTime,
  String? posterName,
  int? comments,
  String? uid,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'postImage': postImage,
      'postVideo': postVideo,
      'postUser': postUser,
      'usersShares': usersShares,
      'postText': postText,
      'postUsername': postUsername,
      'postUserimage': postUserimage,
      'createdTime': createdTime,
      'posterName': posterName,
      'comments': comments,
      'uid': uid,
    }.withoutNulls,
  );

  return firestoreData;
}

class PostsRecordDocumentEquality implements Equality<PostsRecord> {
  const PostsRecordDocumentEquality();

  @override
  bool equals(PostsRecord? e1, PostsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.postImage == e2?.postImage &&
        e1?.postVideo == e2?.postVideo &&
        e1?.postUser == e2?.postUser &&
        e1?.usersShares == e2?.usersShares &&
        e1?.postText == e2?.postText &&
        e1?.postUsername == e2?.postUsername &&
        e1?.postUserimage == e2?.postUserimage &&
        listEquality.equals(e1?.userLikes, e2?.userLikes) &&
        listEquality.equals(e1?.userBookmarks, e2?.userBookmarks) &&
        e1?.createdTime == e2?.createdTime &&
        e1?.posterName == e2?.posterName &&
        e1?.comments == e2?.comments &&
        e1?.uid == e2?.uid;
  }

  @override
  int hash(PostsRecord? e) => const ListEquality().hash([
        e?.postImage,
        e?.postVideo,
        e?.postUser,
        e?.usersShares,
        e?.postText,
        e?.postUsername,
        e?.postUserimage,
        e?.userLikes,
        e?.userBookmarks,
        e?.createdTime,
        e?.posterName,
        e?.comments,
        e?.uid
      ]);

  @override
  bool isValidKey(Object? o) => o is PostsRecord;
}
