import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Chats3Record extends FirestoreRecord {
  Chats3Record._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "messages" field.
  String? _messages;
  String get messages => _messages ?? '';
  bool hasMessages() => _messages != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "uidofSender" field.
  DocumentReference? _uidofSender;
  DocumentReference? get uidofSender => _uidofSender;
  bool hasUidofSender() => _uidofSender != null;

  // "nameofSender" field.
  String? _nameofSender;
  String get nameofSender => _nameofSender ?? '';
  bool hasNameofSender() => _nameofSender != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _messages = snapshotData['messages'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _uidofSender = snapshotData['uidofSender'] as DocumentReference?;
    _nameofSender = snapshotData['nameofSender'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Chats3')
          : FirebaseFirestore.instance.collectionGroup('Chats3');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Chats3').doc(id);

  static Stream<Chats3Record> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Chats3Record.fromSnapshot(s));

  static Future<Chats3Record> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Chats3Record.fromSnapshot(s));

  static Chats3Record fromSnapshot(DocumentSnapshot snapshot) => Chats3Record._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Chats3Record getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Chats3Record._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Chats3Record(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Chats3Record &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChats3RecordData({
  String? messages,
  DateTime? timestamp,
  DocumentReference? uidofSender,
  String? nameofSender,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'messages': messages,
      'timestamp': timestamp,
      'uidofSender': uidofSender,
      'nameofSender': nameofSender,
    }.withoutNulls,
  );

  return firestoreData;
}

class Chats3RecordDocumentEquality implements Equality<Chats3Record> {
  const Chats3RecordDocumentEquality();

  @override
  bool equals(Chats3Record? e1, Chats3Record? e2) {
    return e1?.messages == e2?.messages &&
        e1?.timestamp == e2?.timestamp &&
        e1?.uidofSender == e2?.uidofSender &&
        e1?.nameofSender == e2?.nameofSender;
  }

  @override
  int hash(Chats3Record? e) => const ListEquality()
      .hash([e?.messages, e?.timestamp, e?.uidofSender, e?.nameofSender]);

  @override
  bool isValidKey(Object? o) => o is Chats3Record;
}
