import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class BookingRecord extends FirestoreRecord {
  BookingRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "time" field.
  DateTime? _time;
  DateTime? get time => _time;
  bool hasTime() => _time != null;

  // "sender" field.
  DocumentReference? _sender;
  DocumentReference? get sender => _sender;
  bool hasSender() => _sender != null;

  // "accepted" field.
  bool? _accepted;
  bool get accepted => _accepted ?? false;
  bool hasAccepted() => _accepted != null;

  // "rejected" field.
  bool? _rejected;
  bool get rejected => _rejected ?? false;
  bool hasRejected() => _rejected != null;

  // "state" field.
  String? _state;
  String get state => _state ?? '';
  bool hasState() => _state != null;

  // "starttime" field.
  DateTime? _starttime;
  DateTime? get starttime => _starttime;
  bool hasStarttime() => _starttime != null;

  // "senderimg" field.
  String? _senderimg;
  String get senderimg => _senderimg ?? '';
  bool hasSenderimg() => _senderimg != null;

  // "sendername" field.
  String? _sendername;
  String get sendername => _sendername ?? '';
  bool hasSendername() => _sendername != null;

  // "senderID" field.
  String? _senderID;
  String get senderID => _senderID ?? '';
  bool hasSenderID() => _senderID != null;

  // "receiverID" field.
  String? _receiverID;
  String get receiverID => _receiverID ?? '';
  bool hasReceiverID() => _receiverID != null;

  // "useids" field.
  List<DocumentReference>? _useids;
  List<DocumentReference> get useids => _useids ?? const [];
  bool hasUseids() => _useids != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _time = snapshotData['time'] as DateTime?;
    _sender = snapshotData['sender'] as DocumentReference?;
    _accepted = snapshotData['accepted'] as bool?;
    _rejected = snapshotData['rejected'] as bool?;
    _state = snapshotData['state'] as String?;
    _starttime = snapshotData['starttime'] as DateTime?;
    _senderimg = snapshotData['senderimg'] as String?;
    _sendername = snapshotData['sendername'] as String?;
    _senderID = snapshotData['senderID'] as String?;
    _receiverID = snapshotData['receiverID'] as String?;
    _useids = getDataList(snapshotData['useids']);
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('Booking')
          : FirebaseFirestore.instance.collectionGroup('Booking');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('Booking').doc(id);

  static Stream<BookingRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => BookingRecord.fromSnapshot(s));

  static Future<BookingRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => BookingRecord.fromSnapshot(s));

  static BookingRecord fromSnapshot(DocumentSnapshot snapshot) =>
      BookingRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static BookingRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      BookingRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'BookingRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is BookingRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createBookingRecordData({
  DateTime? time,
  DocumentReference? sender,
  bool? accepted,
  bool? rejected,
  String? state,
  DateTime? starttime,
  String? senderimg,
  String? sendername,
  String? senderID,
  String? receiverID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'time': time,
      'sender': sender,
      'accepted': accepted,
      'rejected': rejected,
      'state': state,
      'starttime': starttime,
      'senderimg': senderimg,
      'sendername': sendername,
      'senderID': senderID,
      'receiverID': receiverID,
    }.withoutNulls,
  );

  return firestoreData;
}

class BookingRecordDocumentEquality implements Equality<BookingRecord> {
  const BookingRecordDocumentEquality();

  @override
  bool equals(BookingRecord? e1, BookingRecord? e2) {
    const listEquality = ListEquality();
    return e1?.time == e2?.time &&
        e1?.sender == e2?.sender &&
        e1?.accepted == e2?.accepted &&
        e1?.rejected == e2?.rejected &&
        e1?.state == e2?.state &&
        e1?.starttime == e2?.starttime &&
        e1?.senderimg == e2?.senderimg &&
        e1?.sendername == e2?.sendername &&
        e1?.senderID == e2?.senderID &&
        e1?.receiverID == e2?.receiverID &&
        listEquality.equals(e1?.useids, e2?.useids);
  }

  @override
  int hash(BookingRecord? e) => const ListEquality().hash([
        e?.time,
        e?.sender,
        e?.accepted,
        e?.rejected,
        e?.state,
        e?.starttime,
        e?.senderimg,
        e?.sendername,
        e?.senderID,
        e?.receiverID,
        e?.useids
      ]);

  @override
  bool isValidKey(Object? o) => o is BookingRecord;
}
