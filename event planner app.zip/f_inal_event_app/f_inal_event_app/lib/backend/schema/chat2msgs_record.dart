import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Chat2msgsRecord extends FirestoreRecord {
  Chat2msgsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "messages" field.
  String? _messages;
  String get messages => _messages ?? '';
  bool hasMessages() => _messages != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "uidofSender" field.
  DocumentReference? _uidofSender;
  DocumentReference? get uidofSender => _uidofSender;
  bool hasUidofSender() => _uidofSender != null;

  // "nameofSender" field.
  String? _nameofSender;
  String get nameofSender => _nameofSender ?? '';
  bool hasNameofSender() => _nameofSender != null;

  // "isNew" field.
  bool? _isNew;
  bool get isNew => _isNew ?? false;
  bool hasIsNew() => _isNew != null;

  // "uidofreceiver" field.
  DocumentReference? _uidofreceiver;
  DocumentReference? get uidofreceiver => _uidofreceiver;
  bool hasUidofreceiver() => _uidofreceiver != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _messages = snapshotData['messages'] as String?;
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _uidofSender = snapshotData['uidofSender'] as DocumentReference?;
    _nameofSender = snapshotData['nameofSender'] as String?;
    _isNew = snapshotData['isNew'] as bool?;
    _uidofreceiver = snapshotData['uidofreceiver'] as DocumentReference?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('chat2msgs')
          : FirebaseFirestore.instance.collectionGroup('chat2msgs');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('chat2msgs').doc(id);

  static Stream<Chat2msgsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Chat2msgsRecord.fromSnapshot(s));

  static Future<Chat2msgsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Chat2msgsRecord.fromSnapshot(s));

  static Chat2msgsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      Chat2msgsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Chat2msgsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Chat2msgsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Chat2msgsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Chat2msgsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChat2msgsRecordData({
  String? messages,
  DateTime? timestamp,
  DocumentReference? uidofSender,
  String? nameofSender,
  bool? isNew,
  DocumentReference? uidofreceiver,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'messages': messages,
      'timestamp': timestamp,
      'uidofSender': uidofSender,
      'nameofSender': nameofSender,
      'isNew': isNew,
      'uidofreceiver': uidofreceiver,
    }.withoutNulls,
  );

  return firestoreData;
}

class Chat2msgsRecordDocumentEquality implements Equality<Chat2msgsRecord> {
  const Chat2msgsRecordDocumentEquality();

  @override
  bool equals(Chat2msgsRecord? e1, Chat2msgsRecord? e2) {
    return e1?.messages == e2?.messages &&
        e1?.timestamp == e2?.timestamp &&
        e1?.uidofSender == e2?.uidofSender &&
        e1?.nameofSender == e2?.nameofSender &&
        e1?.isNew == e2?.isNew &&
        e1?.uidofreceiver == e2?.uidofreceiver;
  }

  @override
  int hash(Chat2msgsRecord? e) => const ListEquality().hash([
        e?.messages,
        e?.timestamp,
        e?.uidofSender,
        e?.nameofSender,
        e?.isNew,
        e?.uidofreceiver
      ]);

  @override
  bool isValidKey(Object? o) => o is Chat2msgsRecord;
}
