import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class DelegatesRecord extends FirestoreRecord {
  DelegatesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "contactNumber" field.
  String? _contactNumber;
  String get contactNumber => _contactNumber ?? '';
  bool hasContactNumber() => _contactNumber != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "photo" field.
  String? _photo;
  String get photo => _photo ?? '';
  bool hasPhoto() => _photo != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _contactNumber = snapshotData['contactNumber'] as String?;
    _email = snapshotData['email'] as String?;
    _photo = snapshotData['photo'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Delegates');

  static Stream<DelegatesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => DelegatesRecord.fromSnapshot(s));

  static Future<DelegatesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => DelegatesRecord.fromSnapshot(s));

  static DelegatesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      DelegatesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static DelegatesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      DelegatesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'DelegatesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is DelegatesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDelegatesRecordData({
  String? name,
  String? contactNumber,
  String? email,
  String? photo,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'contactNumber': contactNumber,
      'email': email,
      'photo': photo,
    }.withoutNulls,
  );

  return firestoreData;
}

class DelegatesRecordDocumentEquality implements Equality<DelegatesRecord> {
  const DelegatesRecordDocumentEquality();

  @override
  bool equals(DelegatesRecord? e1, DelegatesRecord? e2) {
    return e1?.name == e2?.name &&
        e1?.contactNumber == e2?.contactNumber &&
        e1?.email == e2?.email &&
        e1?.photo == e2?.photo;
  }

  @override
  int hash(DelegatesRecord? e) => const ListEquality()
      .hash([e?.name, e?.contactNumber, e?.email, e?.photo]);

  @override
  bool isValidKey(Object? o) => o is DelegatesRecord;
}
