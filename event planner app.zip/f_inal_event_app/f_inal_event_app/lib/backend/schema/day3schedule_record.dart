import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day3scheduleRecord extends FirestoreRecord {
  Day3scheduleRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "time" field.
  String? _time;
  String get time => _time ?? '';
  bool hasTime() => _time != null;

  // "sessionNo" field.
  String? _sessionNo;
  String get sessionNo => _sessionNo ?? '';
  bool hasSessionNo() => _sessionNo != null;

  // "chair" field.
  String? _chair;
  String get chair => _chair ?? '';
  bool hasChair() => _chair != null;

  // "panelists" field.
  String? _panelists;
  String get panelists => _panelists ?? '';
  bool hasPanelists() => _panelists != null;

  // "sessionTitle" field.
  String? _sessionTitle;
  String get sessionTitle => _sessionTitle ?? '';
  bool hasSessionTitle() => _sessionTitle != null;

  // "imageday1" field.
  String? _imageday1;
  String get imageday1 => _imageday1 ?? '';
  bool hasImageday1() => _imageday1 != null;

  // "StartTime" field.
  DateTime? _startTime;
  DateTime? get startTime => _startTime;
  bool hasStartTime() => _startTime != null;

  // "EndTime" field.
  DateTime? _endTime;
  DateTime? get endTime => _endTime;
  bool hasEndTime() => _endTime != null;

  // "Speaker" field.
  List<Day3speakerStruct>? _speaker;
  List<Day3speakerStruct> get speaker => _speaker ?? const [];
  bool hasSpeaker() => _speaker != null;

  // "Moderator" field.
  List<Day3moderatorStruct>? _moderator;
  List<Day3moderatorStruct> get moderator => _moderator ?? const [];
  bool hasModerator() => _moderator != null;

  // "Chairs" field.
  List<Day3chairStruct>? _chairs;
  List<Day3chairStruct> get chairs => _chairs ?? const [];
  bool hasChairs() => _chairs != null;

  void _initializeFields() {
    _time = snapshotData['time'] as String?;
    _sessionNo = snapshotData['sessionNo'] as String?;
    _chair = snapshotData['chair'] as String?;
    _panelists = snapshotData['panelists'] as String?;
    _sessionTitle = snapshotData['sessionTitle'] as String?;
    _imageday1 = snapshotData['imageday1'] as String?;
    _startTime = snapshotData['StartTime'] as DateTime?;
    _endTime = snapshotData['EndTime'] as DateTime?;
    _speaker = getStructList(
      snapshotData['Speaker'],
      Day3speakerStruct.fromMap,
    );
    _moderator = getStructList(
      snapshotData['Moderator'],
      Day3moderatorStruct.fromMap,
    );
    _chairs = getStructList(
      snapshotData['Chairs'],
      Day3chairStruct.fromMap,
    );
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('day3schedule');

  static Stream<Day3scheduleRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Day3scheduleRecord.fromSnapshot(s));

  static Future<Day3scheduleRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Day3scheduleRecord.fromSnapshot(s));

  static Day3scheduleRecord fromSnapshot(DocumentSnapshot snapshot) =>
      Day3scheduleRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Day3scheduleRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Day3scheduleRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Day3scheduleRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Day3scheduleRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDay3scheduleRecordData({
  String? time,
  String? sessionNo,
  String? chair,
  String? panelists,
  String? sessionTitle,
  String? imageday1,
  DateTime? startTime,
  DateTime? endTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'time': time,
      'sessionNo': sessionNo,
      'chair': chair,
      'panelists': panelists,
      'sessionTitle': sessionTitle,
      'imageday1': imageday1,
      'StartTime': startTime,
      'EndTime': endTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class Day3scheduleRecordDocumentEquality
    implements Equality<Day3scheduleRecord> {
  const Day3scheduleRecordDocumentEquality();

  @override
  bool equals(Day3scheduleRecord? e1, Day3scheduleRecord? e2) {
    const listEquality = ListEquality();
    return e1?.time == e2?.time &&
        e1?.sessionNo == e2?.sessionNo &&
        e1?.chair == e2?.chair &&
        e1?.panelists == e2?.panelists &&
        e1?.sessionTitle == e2?.sessionTitle &&
        e1?.imageday1 == e2?.imageday1 &&
        e1?.startTime == e2?.startTime &&
        e1?.endTime == e2?.endTime &&
        listEquality.equals(e1?.speaker, e2?.speaker) &&
        listEquality.equals(e1?.moderator, e2?.moderator) &&
        listEquality.equals(e1?.chairs, e2?.chairs);
  }

  @override
  int hash(Day3scheduleRecord? e) => const ListEquality().hash([
        e?.time,
        e?.sessionNo,
        e?.chair,
        e?.panelists,
        e?.sessionTitle,
        e?.imageday1,
        e?.startTime,
        e?.endTime,
        e?.speaker,
        e?.moderator,
        e?.chairs
      ]);

  @override
  bool isValidKey(Object? o) => o is Day3scheduleRecord;
}
