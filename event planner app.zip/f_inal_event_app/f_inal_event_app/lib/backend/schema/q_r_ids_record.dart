import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class QRIdsRecord extends FirestoreRecord {
  QRIdsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "qrIDS" field.
  List<String>? _qrIDS;
  List<String> get qrIDS => _qrIDS ?? const [];
  bool hasQrIDS() => _qrIDS != null;

  // "hint" field.
  String? _hint;
  String get hint => _hint ?? '';
  bool hasHint() => _hint != null;

  // "timer" field.
  DateTime? _timer;
  DateTime? get timer => _timer;
  bool hasTimer() => _timer != null;

  void _initializeFields() {
    _qrIDS = getDataList(snapshotData['qrIDS']);
    _hint = snapshotData['hint'] as String?;
    _timer = snapshotData['timer'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('QRIds');

  static Stream<QRIdsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => QRIdsRecord.fromSnapshot(s));

  static Future<QRIdsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => QRIdsRecord.fromSnapshot(s));

  static QRIdsRecord fromSnapshot(DocumentSnapshot snapshot) => QRIdsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static QRIdsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      QRIdsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'QRIdsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is QRIdsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createQRIdsRecordData({
  String? hint,
  DateTime? timer,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'hint': hint,
      'timer': timer,
    }.withoutNulls,
  );

  return firestoreData;
}

class QRIdsRecordDocumentEquality implements Equality<QRIdsRecord> {
  const QRIdsRecordDocumentEquality();

  @override
  bool equals(QRIdsRecord? e1, QRIdsRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.qrIDS, e2?.qrIDS) &&
        e1?.hint == e2?.hint &&
        e1?.timer == e2?.timer;
  }

  @override
  int hash(QRIdsRecord? e) =>
      const ListEquality().hash([e?.qrIDS, e?.hint, e?.timer]);

  @override
  bool isValidKey(Object? o) => o is QRIdsRecord;
}
