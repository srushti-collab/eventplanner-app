import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SponsorsRecord extends FirestoreRecord {
  SponsorsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "logoUrl" field.
  String? _logoUrl;
  String get logoUrl => _logoUrl ?? '';
  bool hasLogoUrl() => _logoUrl != null;

  // "website" field.
  String? _website;
  String get website => _website ?? '';
  bool hasWebsite() => _website != null;

  // "contactEmail" field.
  String? _contactEmail;
  String get contactEmail => _contactEmail ?? '';
  bool hasContactEmail() => _contactEmail != null;

  // "contactNumber" field.
  String? _contactNumber;
  String get contactNumber => _contactNumber ?? '';
  bool hasContactNumber() => _contactNumber != null;

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  bool hasDescription() => _description != null;

  // "sponsorsBanner" field.
  String? _sponsorsBanner;
  String get sponsorsBanner => _sponsorsBanner ?? '';
  bool hasSponsorsBanner() => _sponsorsBanner != null;

  // "address" field.
  String? _address;
  String get address => _address ?? '';
  bool hasAddress() => _address != null;

  // "Instagram" field.
  String? _instagram;
  String get instagram => _instagram ?? '';
  bool hasInstagram() => _instagram != null;

  // "Facebook" field.
  String? _facebook;
  String get facebook => _facebook ?? '';
  bool hasFacebook() => _facebook != null;

  // "Twitter" field.
  String? _twitter;
  String get twitter => _twitter ?? '';
  bool hasTwitter() => _twitter != null;

  // "Linkedin" field.
  String? _linkedin;
  String get linkedin => _linkedin ?? '';
  bool hasLinkedin() => _linkedin != null;

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "profiletaps" field.
  int? _profiletaps;
  int get profiletaps => _profiletaps ?? 0;
  bool hasProfiletaps() => _profiletaps != null;

  // "phototaps" field.
  int? _phototaps;
  int get phototaps => _phototaps ?? 0;
  bool hasPhototaps() => _phototaps != null;

  // "videotaps" field.
  int? _videotaps;
  int get videotaps => _videotaps ?? 0;
  bool hasVideotaps() => _videotaps != null;

  // "downloads" field.
  int? _downloads;
  int get downloads => _downloads ?? 0;
  bool hasDownloads() => _downloads != null;

  // "profileV" field.
  List<ProfileVisitorsStruct>? _profileV;
  List<ProfileVisitorsStruct> get profileV => _profileV ?? const [];
  bool hasProfileV() => _profileV != null;

  // "Images" field.
  List<SponIMGStruct>? _images;
  List<SponIMGStruct> get images => _images ?? const [];
  bool hasImages() => _images != null;

  // "SNo" field.
  int? _sNo;
  int get sNo => _sNo ?? 0;
  bool hasSNo() => _sNo != null;

  // "people" field.
  List<String>? _people;
  List<String> get people => _people ?? const [];
  bool hasPeople() => _people != null;

  // "Videos" field.
  List<SponVideosStruct>? _videos;
  List<SponVideosStruct> get videos => _videos ?? const [];
  bool hasVideos() => _videos != null;

  // "imageV" field.
  List<ImageVisitorsStruct>? _imageV;
  List<ImageVisitorsStruct> get imageV => _imageV ?? const [];
  bool hasImageV() => _imageV != null;

  // "Downloadables" field.
  List<SponDownloadsStruct>? _downloadables;
  List<SponDownloadsStruct> get downloadables => _downloadables ?? const [];
  bool hasDownloadables() => _downloadables != null;

  // "videoV" field.
  List<VideoVisitorsStruct>? _videoV;
  List<VideoVisitorsStruct> get videoV => _videoV ?? const [];
  bool hasVideoV() => _videoV != null;

  // "OrdeNo" field.
  String? _ordeNo;
  String get ordeNo => _ordeNo ?? '';
  bool hasOrdeNo() => _ordeNo != null;

  void _initializeFields() {
    _name = snapshotData['name'] as String?;
    _logoUrl = snapshotData['logoUrl'] as String?;
    _website = snapshotData['website'] as String?;
    _contactEmail = snapshotData['contactEmail'] as String?;
    _contactNumber = snapshotData['contactNumber'] as String?;
    _description = snapshotData['description'] as String?;
    _sponsorsBanner = snapshotData['sponsorsBanner'] as String?;
    _address = snapshotData['address'] as String?;
    _instagram = snapshotData['Instagram'] as String?;
    _facebook = snapshotData['Facebook'] as String?;
    _twitter = snapshotData['Twitter'] as String?;
    _linkedin = snapshotData['Linkedin'] as String?;
    _title = snapshotData['title'] as String?;
    _profiletaps = castToType<int>(snapshotData['profiletaps']);
    _phototaps = castToType<int>(snapshotData['phototaps']);
    _videotaps = castToType<int>(snapshotData['videotaps']);
    _downloads = castToType<int>(snapshotData['downloads']);
    _profileV = getStructList(
      snapshotData['profileV'],
      ProfileVisitorsStruct.fromMap,
    );
    _images = getStructList(
      snapshotData['Images'],
      SponIMGStruct.fromMap,
    );
    _sNo = castToType<int>(snapshotData['SNo']);
    _people = getDataList(snapshotData['people']);
    _videos = getStructList(
      snapshotData['Videos'],
      SponVideosStruct.fromMap,
    );
    _imageV = getStructList(
      snapshotData['imageV'],
      ImageVisitorsStruct.fromMap,
    );
    _downloadables = getStructList(
      snapshotData['Downloadables'],
      SponDownloadsStruct.fromMap,
    );
    _videoV = getStructList(
      snapshotData['videoV'],
      VideoVisitorsStruct.fromMap,
    );
    _ordeNo = snapshotData['OrdeNo'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('Sponsors');

  static Stream<SponsorsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => SponsorsRecord.fromSnapshot(s));

  static Future<SponsorsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => SponsorsRecord.fromSnapshot(s));

  static SponsorsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      SponsorsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static SponsorsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      SponsorsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'SponsorsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is SponsorsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createSponsorsRecordData({
  String? name,
  String? logoUrl,
  String? website,
  String? contactEmail,
  String? contactNumber,
  String? description,
  String? sponsorsBanner,
  String? address,
  String? instagram,
  String? facebook,
  String? twitter,
  String? linkedin,
  String? title,
  int? profiletaps,
  int? phototaps,
  int? videotaps,
  int? downloads,
  int? sNo,
  String? ordeNo,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'name': name,
      'logoUrl': logoUrl,
      'website': website,
      'contactEmail': contactEmail,
      'contactNumber': contactNumber,
      'description': description,
      'sponsorsBanner': sponsorsBanner,
      'address': address,
      'Instagram': instagram,
      'Facebook': facebook,
      'Twitter': twitter,
      'Linkedin': linkedin,
      'title': title,
      'profiletaps': profiletaps,
      'phototaps': phototaps,
      'videotaps': videotaps,
      'downloads': downloads,
      'SNo': sNo,
      'OrdeNo': ordeNo,
    }.withoutNulls,
  );

  return firestoreData;
}

class SponsorsRecordDocumentEquality implements Equality<SponsorsRecord> {
  const SponsorsRecordDocumentEquality();

  @override
  bool equals(SponsorsRecord? e1, SponsorsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.name == e2?.name &&
        e1?.logoUrl == e2?.logoUrl &&
        e1?.website == e2?.website &&
        e1?.contactEmail == e2?.contactEmail &&
        e1?.contactNumber == e2?.contactNumber &&
        e1?.description == e2?.description &&
        e1?.sponsorsBanner == e2?.sponsorsBanner &&
        e1?.address == e2?.address &&
        e1?.instagram == e2?.instagram &&
        e1?.facebook == e2?.facebook &&
        e1?.twitter == e2?.twitter &&
        e1?.linkedin == e2?.linkedin &&
        e1?.title == e2?.title &&
        e1?.profiletaps == e2?.profiletaps &&
        e1?.phototaps == e2?.phototaps &&
        e1?.videotaps == e2?.videotaps &&
        e1?.downloads == e2?.downloads &&
        listEquality.equals(e1?.profileV, e2?.profileV) &&
        listEquality.equals(e1?.images, e2?.images) &&
        e1?.sNo == e2?.sNo &&
        listEquality.equals(e1?.people, e2?.people) &&
        listEquality.equals(e1?.videos, e2?.videos) &&
        listEquality.equals(e1?.imageV, e2?.imageV) &&
        listEquality.equals(e1?.downloadables, e2?.downloadables) &&
        listEquality.equals(e1?.videoV, e2?.videoV) &&
        e1?.ordeNo == e2?.ordeNo;
  }

  @override
  int hash(SponsorsRecord? e) => const ListEquality().hash([
        e?.name,
        e?.logoUrl,
        e?.website,
        e?.contactEmail,
        e?.contactNumber,
        e?.description,
        e?.sponsorsBanner,
        e?.address,
        e?.instagram,
        e?.facebook,
        e?.twitter,
        e?.linkedin,
        e?.title,
        e?.profiletaps,
        e?.phototaps,
        e?.videotaps,
        e?.downloads,
        e?.profileV,
        e?.images,
        e?.sNo,
        e?.people,
        e?.videos,
        e?.imageV,
        e?.downloadables,
        e?.videoV,
        e?.ordeNo
      ]);

  @override
  bool isValidKey(Object? o) => o is SponsorsRecord;
}
