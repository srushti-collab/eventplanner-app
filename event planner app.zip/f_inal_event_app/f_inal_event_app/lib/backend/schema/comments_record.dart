import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class CommentsRecord extends FirestoreRecord {
  CommentsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "commentedUser" field.
  DocumentReference? _commentedUser;
  DocumentReference? get commentedUser => _commentedUser;
  bool hasCommentedUser() => _commentedUser != null;

  // "commentText" field.
  String? _commentText;
  String get commentText => _commentText ?? '';
  bool hasCommentText() => _commentText != null;

  // "commentLikes" field.
  String? _commentLikes;
  String get commentLikes => _commentLikes ?? '';
  bool hasCommentLikes() => _commentLikes != null;

  // "createdTime" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "commentName" field.
  String? _commentName;
  String get commentName => _commentName ?? '';
  bool hasCommentName() => _commentName != null;

  // "commentUserImage" field.
  String? _commentUserImage;
  String get commentUserImage => _commentUserImage ?? '';
  bool hasCommentUserImage() => _commentUserImage != null;

  // "postID" field.
  String? _postID;
  String get postID => _postID ?? '';
  bool hasPostID() => _postID != null;

  DocumentReference get parentReference => reference.parent.parent!;

  void _initializeFields() {
    _commentedUser = snapshotData['commentedUser'] as DocumentReference?;
    _commentText = snapshotData['commentText'] as String?;
    _commentLikes = snapshotData['commentLikes'] as String?;
    _createdTime = snapshotData['createdTime'] as DateTime?;
    _commentName = snapshotData['commentName'] as String?;
    _commentUserImage = snapshotData['commentUserImage'] as String?;
    _postID = snapshotData['postID'] as String?;
  }

  static Query<Map<String, dynamic>> collection([DocumentReference? parent]) =>
      parent != null
          ? parent.collection('comments')
          : FirebaseFirestore.instance.collectionGroup('comments');

  static DocumentReference createDoc(DocumentReference parent, {String? id}) =>
      parent.collection('comments').doc(id);

  static Stream<CommentsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => CommentsRecord.fromSnapshot(s));

  static Future<CommentsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => CommentsRecord.fromSnapshot(s));

  static CommentsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      CommentsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static CommentsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      CommentsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'CommentsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is CommentsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createCommentsRecordData({
  DocumentReference? commentedUser,
  String? commentText,
  String? commentLikes,
  DateTime? createdTime,
  String? commentName,
  String? commentUserImage,
  String? postID,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'commentedUser': commentedUser,
      'commentText': commentText,
      'commentLikes': commentLikes,
      'createdTime': createdTime,
      'commentName': commentName,
      'commentUserImage': commentUserImage,
      'postID': postID,
    }.withoutNulls,
  );

  return firestoreData;
}

class CommentsRecordDocumentEquality implements Equality<CommentsRecord> {
  const CommentsRecordDocumentEquality();

  @override
  bool equals(CommentsRecord? e1, CommentsRecord? e2) {
    return e1?.commentedUser == e2?.commentedUser &&
        e1?.commentText == e2?.commentText &&
        e1?.commentLikes == e2?.commentLikes &&
        e1?.createdTime == e2?.createdTime &&
        e1?.commentName == e2?.commentName &&
        e1?.commentUserImage == e2?.commentUserImage &&
        e1?.postID == e2?.postID;
  }

  @override
  int hash(CommentsRecord? e) => const ListEquality().hash([
        e?.commentedUser,
        e?.commentText,
        e?.commentLikes,
        e?.createdTime,
        e?.commentName,
        e?.commentUserImage,
        e?.postID
      ]);

  @override
  bool isValidKey(Object? o) => o is CommentsRecord;
}
