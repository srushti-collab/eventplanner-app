import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatsRecord extends FirestoreRecord {
  ChatsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "useids" field.
  List<DocumentReference>? _useids;
  List<DocumentReference> get useids => _useids ?? const [];
  bool hasUseids() => _useids != null;

  // "lastMessage" field.
  String? _lastMessage;
  String get lastMessage => _lastMessage ?? '';
  bool hasLastMessage() => _lastMessage != null;

  // "userNames" field.
  List<String>? _userNames;
  List<String> get userNames => _userNames ?? const [];
  bool hasUserNames() => _userNames != null;

  // "timestamp" field.
  DateTime? _timestamp;
  DateTime? get timestamp => _timestamp;
  bool hasTimestamp() => _timestamp != null;

  // "lastMessageSeenby" field.
  List<DocumentReference>? _lastMessageSeenby;
  List<DocumentReference> get lastMessageSeenby =>
      _lastMessageSeenby ?? const [];
  bool hasLastMessageSeenby() => _lastMessageSeenby != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "participantname" field.
  List<String>? _participantname;
  List<String> get participantname => _participantname ?? const [];
  bool hasParticipantname() => _participantname != null;

  // "participantid" field.
  List<DocumentReference>? _participantid;
  List<DocumentReference> get participantid => _participantid ?? const [];
  bool hasParticipantid() => _participantid != null;

  // "ts" field.
  DateTime? _ts;
  DateTime? get ts => _ts;
  bool hasTs() => _ts != null;

  // "participantimage" field.
  List<String>? _participantimage;
  List<String> get participantimage => _participantimage ?? const [];
  bool hasParticipantimage() => _participantimage != null;

  // "isNew" field.
  bool? _isNew;
  bool get isNew => _isNew ?? false;
  bool hasIsNew() => _isNew != null;

  void _initializeFields() {
    _useids = getDataList(snapshotData['useids']);
    _lastMessage = snapshotData['lastMessage'] as String?;
    _userNames = getDataList(snapshotData['userNames']);
    _timestamp = snapshotData['timestamp'] as DateTime?;
    _lastMessageSeenby = getDataList(snapshotData['lastMessageSeenby']);
    _photoUrl = snapshotData['photo_url'] as String?;
    _participantname = getDataList(snapshotData['participantname']);
    _participantid = getDataList(snapshotData['participantid']);
    _ts = snapshotData['ts'] as DateTime?;
    _participantimage = getDataList(snapshotData['participantimage']);
    _isNew = snapshotData['isNew'] as bool?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('chats');

  static Stream<ChatsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatsRecord.fromSnapshot(s));

  static Future<ChatsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChatsRecord.fromSnapshot(s));

  static ChatsRecord fromSnapshot(DocumentSnapshot snapshot) => ChatsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatsRecordData({
  String? lastMessage,
  DateTime? timestamp,
  String? photoUrl,
  DateTime? ts,
  bool? isNew,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'lastMessage': lastMessage,
      'timestamp': timestamp,
      'photo_url': photoUrl,
      'ts': ts,
      'isNew': isNew,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatsRecordDocumentEquality implements Equality<ChatsRecord> {
  const ChatsRecordDocumentEquality();

  @override
  bool equals(ChatsRecord? e1, ChatsRecord? e2) {
    const listEquality = ListEquality();
    return listEquality.equals(e1?.useids, e2?.useids) &&
        e1?.lastMessage == e2?.lastMessage &&
        listEquality.equals(e1?.userNames, e2?.userNames) &&
        e1?.timestamp == e2?.timestamp &&
        listEquality.equals(e1?.lastMessageSeenby, e2?.lastMessageSeenby) &&
        e1?.photoUrl == e2?.photoUrl &&
        listEquality.equals(e1?.participantname, e2?.participantname) &&
        listEquality.equals(e1?.participantid, e2?.participantid) &&
        e1?.ts == e2?.ts &&
        listEquality.equals(e1?.participantimage, e2?.participantimage) &&
        e1?.isNew == e2?.isNew;
  }

  @override
  int hash(ChatsRecord? e) => const ListEquality().hash([
        e?.useids,
        e?.lastMessage,
        e?.userNames,
        e?.timestamp,
        e?.lastMessageSeenby,
        e?.photoUrl,
        e?.participantname,
        e?.participantid,
        e?.ts,
        e?.participantimage,
        e?.isNew
      ]);

  @override
  bool isValidKey(Object? o) => o is ChatsRecord;
}
