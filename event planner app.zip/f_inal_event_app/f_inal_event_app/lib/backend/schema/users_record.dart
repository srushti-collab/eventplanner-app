import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "user_name" field.
  String? _userName;
  String get userName => _userName ?? '';
  bool hasUserName() => _userName != null;

  // "role" field.
  String? _role;
  String get role => _role ?? '';
  bool hasRole() => _role != null;

  // "company" field.
  String? _company;
  String get company => _company ?? '';
  bool hasCompany() => _company != null;

  // "createdAt" field.
  DateTime? _createdAt;
  DateTime? get createdAt => _createdAt;
  bool hasCreatedAt() => _createdAt != null;

  // "updatedAt" field.
  DateTime? _updatedAt;
  DateTime? get updatedAt => _updatedAt;
  bool hasUpdatedAt() => _updatedAt != null;

  // "designation" field.
  String? _designation;
  String get designation => _designation ?? '';
  bool hasDesignation() => _designation != null;

  // "country" field.
  String? _country;
  String get country => _country ?? '';
  bool hasCountry() => _country != null;

  // "paymentStatus" field.
  String? _paymentStatus;
  String get paymentStatus => _paymentStatus ?? '';
  bool hasPaymentStatus() => _paymentStatus != null;

  // "adddress" field.
  String? _adddress;
  String get adddress => _adddress ?? '';
  bool hasAdddress() => _adddress != null;

  // "gtsnum" field.
  String? _gtsnum;
  String get gtsnum => _gtsnum ?? '';
  bool hasGtsnum() => _gtsnum != null;

  // "About" field.
  String? _about;
  String get about => _about ?? '';
  bool hasAbout() => _about != null;

  // "chatid" field.
  DocumentReference? _chatid;
  DocumentReference? get chatid => _chatid;
  bool hasChatid() => _chatid != null;

  // "id" field.
  DocumentReference? _id;
  DocumentReference? get id => _id;
  bool hasId() => _id != null;

  // "engaged_with_Ids" field.
  List<DocumentReference>? _engagedWithIds;
  List<DocumentReference> get engagedWithIds => _engagedWithIds ?? const [];
  bool hasEngagedWithIds() => _engagedWithIds != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "lastmsg" field.
  String? _lastmsg;
  String get lastmsg => _lastmsg ?? '';
  bool hasLastmsg() => _lastmsg != null;

  // "ts" field.
  DateTime? _ts;
  DateTime? get ts => _ts;
  bool hasTs() => _ts != null;

  // "lastmsgseenby" field.
  List<DocumentReference>? _lastmsgseenby;
  List<DocumentReference> get lastmsgseenby => _lastmsgseenby ?? const [];
  bool hasLastmsgseenby() => _lastmsgseenby != null;

  // "scannedQRIds" field.
  List<String>? _scannedQRIds;
  List<String> get scannedQRIds => _scannedQRIds ?? const [];
  bool hasScannedQRIds() => _scannedQRIds != null;

  // "qrPoints" field.
  int? _qrPoints;
  int get qrPoints => _qrPoints ?? 0;
  bool hasQrPoints() => _qrPoints != null;

  // "usagepoints" field.
  int? _usagepoints;
  int get usagepoints => _usagepoints ?? 0;
  bool hasUsagepoints() => _usagepoints != null;

  // "timeavb" field.
  DateTime? _timeavb;
  DateTime? get timeavb => _timeavb;
  bool hasTimeavb() => _timeavb != null;

  // "uidavb" field.
  DocumentReference? _uidavb;
  DocumentReference? get uidavb => _uidavb;
  bool hasUidavb() => _uidavb != null;

  // "friends" field.
  List<DocumentReference>? _friends;
  List<DocumentReference> get friends => _friends ?? const [];
  bool hasFriends() => _friends != null;

  // "pendingfriends" field.
  List<DocumentReference>? _pendingfriends;
  List<DocumentReference> get pendingfriends => _pendingfriends ?? const [];
  bool hasPendingfriends() => _pendingfriends != null;

  // "pofVisit" field.
  List<ProfileVisitorsStruct>? _pofVisit;
  List<ProfileVisitorsStruct> get pofVisit => _pofVisit ?? const [];
  bool hasPofVisit() => _pofVisit != null;

  // "firstlogin" field.
  bool? _firstlogin;
  bool get firstlogin => _firstlogin ?? false;
  bool hasFirstlogin() => _firstlogin != null;

  // "starttime" field.
  DateTime? _starttime;
  DateTime? get starttime => _starttime;
  bool hasStarttime() => _starttime != null;

  // "userrefnoti" field.
  List<DocumentReference>? _userrefnoti;
  List<DocumentReference> get userrefnoti => _userrefnoti ?? const [];
  bool hasUserrefnoti() => _userrefnoti != null;

  // "ScanTime" field.
  DateTime? _scanTime;
  DateTime? get scanTime => _scanTime;
  bool hasScanTime() => _scanTime != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _userName = snapshotData['user_name'] as String?;
    _role = snapshotData['role'] as String?;
    _company = snapshotData['company'] as String?;
    _createdAt = snapshotData['createdAt'] as DateTime?;
    _updatedAt = snapshotData['updatedAt'] as DateTime?;
    _designation = snapshotData['designation'] as String?;
    _country = snapshotData['country'] as String?;
    _paymentStatus = snapshotData['paymentStatus'] as String?;
    _adddress = snapshotData['adddress'] as String?;
    _gtsnum = snapshotData['gtsnum'] as String?;
    _about = snapshotData['About'] as String?;
    _chatid = snapshotData['chatid'] as DocumentReference?;
    _id = snapshotData['id'] as DocumentReference?;
    _engagedWithIds = getDataList(snapshotData['engaged_with_Ids']);
    _status = snapshotData['status'] as String?;
    _lastmsg = snapshotData['lastmsg'] as String?;
    _ts = snapshotData['ts'] as DateTime?;
    _lastmsgseenby = getDataList(snapshotData['lastmsgseenby']);
    _scannedQRIds = getDataList(snapshotData['scannedQRIds']);
    _qrPoints = castToType<int>(snapshotData['qrPoints']);
    _usagepoints = castToType<int>(snapshotData['usagepoints']);
    _timeavb = snapshotData['timeavb'] as DateTime?;
    _uidavb = snapshotData['uidavb'] as DocumentReference?;
    _friends = getDataList(snapshotData['friends']);
    _pendingfriends = getDataList(snapshotData['pendingfriends']);
    _pofVisit = getStructList(
      snapshotData['pofVisit'],
      ProfileVisitorsStruct.fromMap,
    );
    _firstlogin = snapshotData['firstlogin'] as bool?;
    _starttime = snapshotData['starttime'] as DateTime?;
    _userrefnoti = getDataList(snapshotData['userrefnoti']);
    _scanTime = snapshotData['ScanTime'] as DateTime?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? displayName,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  String? userName,
  String? role,
  String? company,
  DateTime? createdAt,
  DateTime? updatedAt,
  String? designation,
  String? country,
  String? paymentStatus,
  String? adddress,
  String? gtsnum,
  String? about,
  DocumentReference? chatid,
  DocumentReference? id,
  String? status,
  String? lastmsg,
  DateTime? ts,
  int? qrPoints,
  int? usagepoints,
  DateTime? timeavb,
  DocumentReference? uidavb,
  bool? firstlogin,
  DateTime? starttime,
  DateTime? scanTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'display_name': displayName,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'user_name': userName,
      'role': role,
      'company': company,
      'createdAt': createdAt,
      'updatedAt': updatedAt,
      'designation': designation,
      'country': country,
      'paymentStatus': paymentStatus,
      'adddress': adddress,
      'gtsnum': gtsnum,
      'About': about,
      'chatid': chatid,
      'id': id,
      'status': status,
      'lastmsg': lastmsg,
      'ts': ts,
      'qrPoints': qrPoints,
      'usagepoints': usagepoints,
      'timeavb': timeavb,
      'uidavb': uidavb,
      'firstlogin': firstlogin,
      'starttime': starttime,
      'ScanTime': scanTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.displayName == e2?.displayName &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.userName == e2?.userName &&
        e1?.role == e2?.role &&
        e1?.company == e2?.company &&
        e1?.createdAt == e2?.createdAt &&
        e1?.updatedAt == e2?.updatedAt &&
        e1?.designation == e2?.designation &&
        e1?.country == e2?.country &&
        e1?.paymentStatus == e2?.paymentStatus &&
        e1?.adddress == e2?.adddress &&
        e1?.gtsnum == e2?.gtsnum &&
        e1?.about == e2?.about &&
        e1?.chatid == e2?.chatid &&
        e1?.id == e2?.id &&
        listEquality.equals(e1?.engagedWithIds, e2?.engagedWithIds) &&
        e1?.status == e2?.status &&
        e1?.lastmsg == e2?.lastmsg &&
        e1?.ts == e2?.ts &&
        listEquality.equals(e1?.lastmsgseenby, e2?.lastmsgseenby) &&
        listEquality.equals(e1?.scannedQRIds, e2?.scannedQRIds) &&
        e1?.qrPoints == e2?.qrPoints &&
        e1?.usagepoints == e2?.usagepoints &&
        e1?.timeavb == e2?.timeavb &&
        e1?.uidavb == e2?.uidavb &&
        listEquality.equals(e1?.friends, e2?.friends) &&
        listEquality.equals(e1?.pendingfriends, e2?.pendingfriends) &&
        listEquality.equals(e1?.pofVisit, e2?.pofVisit) &&
        e1?.firstlogin == e2?.firstlogin &&
        e1?.starttime == e2?.starttime &&
        listEquality.equals(e1?.userrefnoti, e2?.userrefnoti) &&
        e1?.scanTime == e2?.scanTime;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.displayName,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.userName,
        e?.role,
        e?.company,
        e?.createdAt,
        e?.updatedAt,
        e?.designation,
        e?.country,
        e?.paymentStatus,
        e?.adddress,
        e?.gtsnum,
        e?.about,
        e?.chatid,
        e?.id,
        e?.engagedWithIds,
        e?.status,
        e?.lastmsg,
        e?.ts,
        e?.lastmsgseenby,
        e?.scannedQRIds,
        e?.qrPoints,
        e?.usagepoints,
        e?.timeavb,
        e?.uidavb,
        e?.friends,
        e?.pendingfriends,
        e?.pofVisit,
        e?.firstlogin,
        e?.starttime,
        e?.userrefnoti,
        e?.scanTime
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
