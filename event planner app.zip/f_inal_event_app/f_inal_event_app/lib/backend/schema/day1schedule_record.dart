import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day1scheduleRecord extends FirestoreRecord {
  Day1scheduleRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "sessionNo" field.
  String? _sessionNo;
  String get sessionNo => _sessionNo ?? '';
  bool hasSessionNo() => _sessionNo != null;

  // "sessionTitle" field.
  String? _sessionTitle;
  String get sessionTitle => _sessionTitle ?? '';
  bool hasSessionTitle() => _sessionTitle != null;

  // "StartTIme" field.
  DateTime? _startTIme;
  DateTime? get startTIme => _startTIme;
  bool hasStartTIme() => _startTIme != null;

  // "EndTime" field.
  DateTime? _endTime;
  DateTime? get endTime => _endTime;
  bool hasEndTime() => _endTime != null;

  // "Speakers" field.
  List<Day1SpeakersStruct>? _speakers;
  List<Day1SpeakersStruct> get speakers => _speakers ?? const [];
  bool hasSpeakers() => _speakers != null;

  // "Chair" field.
  List<Day1chairStruct>? _chair;
  List<Day1chairStruct> get chair => _chair ?? const [];
  bool hasChair() => _chair != null;

  // "Moderator" field.
  List<Day1moderatorStruct>? _moderator;
  List<Day1moderatorStruct> get moderator => _moderator ?? const [];
  bool hasModerator() => _moderator != null;

  // "Location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  void _initializeFields() {
    _sessionNo = snapshotData['sessionNo'] as String?;
    _sessionTitle = snapshotData['sessionTitle'] as String?;
    _startTIme = snapshotData['StartTIme'] as DateTime?;
    _endTime = snapshotData['EndTime'] as DateTime?;
    _speakers = getStructList(
      snapshotData['Speakers'],
      Day1SpeakersStruct.fromMap,
    );
    _chair = getStructList(
      snapshotData['Chair'],
      Day1chairStruct.fromMap,
    );
    _moderator = getStructList(
      snapshotData['Moderator'],
      Day1moderatorStruct.fromMap,
    );
    _location = snapshotData['Location'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('day1schedule');

  static Stream<Day1scheduleRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Day1scheduleRecord.fromSnapshot(s));

  static Future<Day1scheduleRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Day1scheduleRecord.fromSnapshot(s));

  static Day1scheduleRecord fromSnapshot(DocumentSnapshot snapshot) =>
      Day1scheduleRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Day1scheduleRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Day1scheduleRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Day1scheduleRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Day1scheduleRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDay1scheduleRecordData({
  String? sessionNo,
  String? sessionTitle,
  DateTime? startTIme,
  DateTime? endTime,
  String? location,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'sessionNo': sessionNo,
      'sessionTitle': sessionTitle,
      'StartTIme': startTIme,
      'EndTime': endTime,
      'Location': location,
    }.withoutNulls,
  );

  return firestoreData;
}

class Day1scheduleRecordDocumentEquality
    implements Equality<Day1scheduleRecord> {
  const Day1scheduleRecordDocumentEquality();

  @override
  bool equals(Day1scheduleRecord? e1, Day1scheduleRecord? e2) {
    const listEquality = ListEquality();
    return e1?.sessionNo == e2?.sessionNo &&
        e1?.sessionTitle == e2?.sessionTitle &&
        e1?.startTIme == e2?.startTIme &&
        e1?.endTime == e2?.endTime &&
        listEquality.equals(e1?.speakers, e2?.speakers) &&
        listEquality.equals(e1?.chair, e2?.chair) &&
        listEquality.equals(e1?.moderator, e2?.moderator) &&
        e1?.location == e2?.location;
  }

  @override
  int hash(Day1scheduleRecord? e) => const ListEquality().hash([
        e?.sessionNo,
        e?.sessionTitle,
        e?.startTIme,
        e?.endTime,
        e?.speakers,
        e?.chair,
        e?.moderator,
        e?.location
      ]);

  @override
  bool isValidKey(Object? o) => o is Day1scheduleRecord;
}
