// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day3speakerStruct extends FFFirebaseStruct {
  Day3speakerStruct({
    String? speakername,
    String? speakerdesign,
    String? speakerimg,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _speakername = speakername,
        _speakerdesign = speakerdesign,
        _speakerimg = speakerimg,
        super(firestoreUtilData);

  // "speakername" field.
  String? _speakername;
  String get speakername => _speakername ?? '';
  set speakername(String? val) => _speakername = val;

  bool hasSpeakername() => _speakername != null;

  // "speakerdesign" field.
  String? _speakerdesign;
  String get speakerdesign => _speakerdesign ?? '';
  set speakerdesign(String? val) => _speakerdesign = val;

  bool hasSpeakerdesign() => _speakerdesign != null;

  // "speakerimg" field.
  String? _speakerimg;
  String get speakerimg => _speakerimg ?? '';
  set speakerimg(String? val) => _speakerimg = val;

  bool hasSpeakerimg() => _speakerimg != null;

  static Day3speakerStruct fromMap(Map<String, dynamic> data) =>
      Day3speakerStruct(
        speakername: data['speakername'] as String?,
        speakerdesign: data['speakerdesign'] as String?,
        speakerimg: data['speakerimg'] as String?,
      );

  static Day3speakerStruct? maybeFromMap(dynamic data) => data is Map
      ? Day3speakerStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'speakername': _speakername,
        'speakerdesign': _speakerdesign,
        'speakerimg': _speakerimg,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'speakername': serializeParam(
          _speakername,
          ParamType.String,
        ),
        'speakerdesign': serializeParam(
          _speakerdesign,
          ParamType.String,
        ),
        'speakerimg': serializeParam(
          _speakerimg,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day3speakerStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day3speakerStruct(
        speakername: deserializeParam(
          data['speakername'],
          ParamType.String,
          false,
        ),
        speakerdesign: deserializeParam(
          data['speakerdesign'],
          ParamType.String,
          false,
        ),
        speakerimg: deserializeParam(
          data['speakerimg'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day3speakerStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day3speakerStruct &&
        speakername == other.speakername &&
        speakerdesign == other.speakerdesign &&
        speakerimg == other.speakerimg;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([speakername, speakerdesign, speakerimg]);
}

Day3speakerStruct createDay3speakerStruct({
  String? speakername,
  String? speakerdesign,
  String? speakerimg,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day3speakerStruct(
      speakername: speakername,
      speakerdesign: speakerdesign,
      speakerimg: speakerimg,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day3speakerStruct? updateDay3speakerStruct(
  Day3speakerStruct? day3speaker, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day3speaker
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay3speakerStructData(
  Map<String, dynamic> firestoreData,
  Day3speakerStruct? day3speaker,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day3speaker == null) {
    return;
  }
  if (day3speaker.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day3speaker.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day3speakerData =
      getDay3speakerFirestoreData(day3speaker, forFieldValue);
  final nestedData =
      day3speakerData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day3speaker.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay3speakerFirestoreData(
  Day3speakerStruct? day3speaker, [
  bool forFieldValue = false,
]) {
  if (day3speaker == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day3speaker.toMap());

  // Add any Firestore field values
  day3speaker.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay3speakerListFirestoreData(
  List<Day3speakerStruct>? day3speakers,
) =>
    day3speakers?.map((e) => getDay3speakerFirestoreData(e, true)).toList() ??
    [];
