// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day2chairStruct extends FFFirebaseStruct {
  Day2chairStruct({
    String? chairnameday2,
    String? chairdesignday2,
    String? chairimg,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _chairnameday2 = chairnameday2,
        _chairdesignday2 = chairdesignday2,
        _chairimg = chairimg,
        super(firestoreUtilData);

  // "chairnameday2" field.
  String? _chairnameday2;
  String get chairnameday2 => _chairnameday2 ?? '';
  set chairnameday2(String? val) => _chairnameday2 = val;

  bool hasChairnameday2() => _chairnameday2 != null;

  // "chairdesignday2" field.
  String? _chairdesignday2;
  String get chairdesignday2 => _chairdesignday2 ?? '';
  set chairdesignday2(String? val) => _chairdesignday2 = val;

  bool hasChairdesignday2() => _chairdesignday2 != null;

  // "chairimg" field.
  String? _chairimg;
  String get chairimg => _chairimg ?? '';
  set chairimg(String? val) => _chairimg = val;

  bool hasChairimg() => _chairimg != null;

  static Day2chairStruct fromMap(Map<String, dynamic> data) => Day2chairStruct(
        chairnameday2: data['chairnameday2'] as String?,
        chairdesignday2: data['chairdesignday2'] as String?,
        chairimg: data['chairimg'] as String?,
      );

  static Day2chairStruct? maybeFromMap(dynamic data) => data is Map
      ? Day2chairStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'chairnameday2': _chairnameday2,
        'chairdesignday2': _chairdesignday2,
        'chairimg': _chairimg,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'chairnameday2': serializeParam(
          _chairnameday2,
          ParamType.String,
        ),
        'chairdesignday2': serializeParam(
          _chairdesignday2,
          ParamType.String,
        ),
        'chairimg': serializeParam(
          _chairimg,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day2chairStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day2chairStruct(
        chairnameday2: deserializeParam(
          data['chairnameday2'],
          ParamType.String,
          false,
        ),
        chairdesignday2: deserializeParam(
          data['chairdesignday2'],
          ParamType.String,
          false,
        ),
        chairimg: deserializeParam(
          data['chairimg'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day2chairStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day2chairStruct &&
        chairnameday2 == other.chairnameday2 &&
        chairdesignday2 == other.chairdesignday2 &&
        chairimg == other.chairimg;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([chairnameday2, chairdesignday2, chairimg]);
}

Day2chairStruct createDay2chairStruct({
  String? chairnameday2,
  String? chairdesignday2,
  String? chairimg,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day2chairStruct(
      chairnameday2: chairnameday2,
      chairdesignday2: chairdesignday2,
      chairimg: chairimg,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day2chairStruct? updateDay2chairStruct(
  Day2chairStruct? day2chair, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day2chair
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay2chairStructData(
  Map<String, dynamic> firestoreData,
  Day2chairStruct? day2chair,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day2chair == null) {
    return;
  }
  if (day2chair.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day2chair.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day2chairData = getDay2chairFirestoreData(day2chair, forFieldValue);
  final nestedData = day2chairData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day2chair.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay2chairFirestoreData(
  Day2chairStruct? day2chair, [
  bool forFieldValue = false,
]) {
  if (day2chair == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day2chair.toMap());

  // Add any Firestore field values
  day2chair.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay2chairListFirestoreData(
  List<Day2chairStruct>? day2chairs,
) =>
    day2chairs?.map((e) => getDay2chairFirestoreData(e, true)).toList() ?? [];
