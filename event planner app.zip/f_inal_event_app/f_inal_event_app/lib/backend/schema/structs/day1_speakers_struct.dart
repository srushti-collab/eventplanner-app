// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day1SpeakersStruct extends FFFirebaseStruct {
  Day1SpeakersStruct({
    String? name,
    String? image,
    String? designation,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _name = name,
        _image = image,
        _designation = designation,
        super(firestoreUtilData);

  // "Name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "Image" field.
  String? _image;
  String get image => _image ?? '';
  set image(String? val) => _image = val;

  bool hasImage() => _image != null;

  // "Designation" field.
  String? _designation;
  String get designation => _designation ?? '';
  set designation(String? val) => _designation = val;

  bool hasDesignation() => _designation != null;

  static Day1SpeakersStruct fromMap(Map<String, dynamic> data) =>
      Day1SpeakersStruct(
        name: data['Name'] as String?,
        image: data['Image'] as String?,
        designation: data['Designation'] as String?,
      );

  static Day1SpeakersStruct? maybeFromMap(dynamic data) => data is Map
      ? Day1SpeakersStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'Name': _name,
        'Image': _image,
        'Designation': _designation,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Name': serializeParam(
          _name,
          ParamType.String,
        ),
        'Image': serializeParam(
          _image,
          ParamType.String,
        ),
        'Designation': serializeParam(
          _designation,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day1SpeakersStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day1SpeakersStruct(
        name: deserializeParam(
          data['Name'],
          ParamType.String,
          false,
        ),
        image: deserializeParam(
          data['Image'],
          ParamType.String,
          false,
        ),
        designation: deserializeParam(
          data['Designation'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day1SpeakersStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day1SpeakersStruct &&
        name == other.name &&
        image == other.image &&
        designation == other.designation;
  }

  @override
  int get hashCode => const ListEquality().hash([name, image, designation]);
}

Day1SpeakersStruct createDay1SpeakersStruct({
  String? name,
  String? image,
  String? designation,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day1SpeakersStruct(
      name: name,
      image: image,
      designation: designation,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day1SpeakersStruct? updateDay1SpeakersStruct(
  Day1SpeakersStruct? day1Speakers, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day1Speakers
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay1SpeakersStructData(
  Map<String, dynamic> firestoreData,
  Day1SpeakersStruct? day1Speakers,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day1Speakers == null) {
    return;
  }
  if (day1Speakers.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day1Speakers.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day1SpeakersData =
      getDay1SpeakersFirestoreData(day1Speakers, forFieldValue);
  final nestedData =
      day1SpeakersData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day1Speakers.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay1SpeakersFirestoreData(
  Day1SpeakersStruct? day1Speakers, [
  bool forFieldValue = false,
]) {
  if (day1Speakers == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day1Speakers.toMap());

  // Add any Firestore field values
  day1Speakers.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay1SpeakersListFirestoreData(
  List<Day1SpeakersStruct>? day1Speakerss,
) =>
    day1Speakerss?.map((e) => getDay1SpeakersFirestoreData(e, true)).toList() ??
    [];
