// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SponVideosStruct extends FFFirebaseStruct {
  SponVideosStruct({
    String? yTLink,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _yTLink = yTLink,
        super(firestoreUtilData);

  // "YTLink" field.
  String? _yTLink;
  String get yTLink => _yTLink ?? '';
  set yTLink(String? val) => _yTLink = val;

  bool hasYTLink() => _yTLink != null;

  static SponVideosStruct fromMap(Map<String, dynamic> data) =>
      SponVideosStruct(
        yTLink: data['YTLink'] as String?,
      );

  static SponVideosStruct? maybeFromMap(dynamic data) => data is Map
      ? SponVideosStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'YTLink': _yTLink,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'YTLink': serializeParam(
          _yTLink,
          ParamType.String,
        ),
      }.withoutNulls;

  static SponVideosStruct fromSerializableMap(Map<String, dynamic> data) =>
      SponVideosStruct(
        yTLink: deserializeParam(
          data['YTLink'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SponVideosStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SponVideosStruct && yTLink == other.yTLink;
  }

  @override
  int get hashCode => const ListEquality().hash([yTLink]);
}

SponVideosStruct createSponVideosStruct({
  String? yTLink,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    SponVideosStruct(
      yTLink: yTLink,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

SponVideosStruct? updateSponVideosStruct(
  SponVideosStruct? sponVideos, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    sponVideos
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addSponVideosStructData(
  Map<String, dynamic> firestoreData,
  SponVideosStruct? sponVideos,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (sponVideos == null) {
    return;
  }
  if (sponVideos.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && sponVideos.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final sponVideosData = getSponVideosFirestoreData(sponVideos, forFieldValue);
  final nestedData = sponVideosData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = sponVideos.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getSponVideosFirestoreData(
  SponVideosStruct? sponVideos, [
  bool forFieldValue = false,
]) {
  if (sponVideos == null) {
    return {};
  }
  final firestoreData = mapToFirestore(sponVideos.toMap());

  // Add any Firestore field values
  sponVideos.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getSponVideosListFirestoreData(
  List<SponVideosStruct>? sponVideoss,
) =>
    sponVideoss?.map((e) => getSponVideosFirestoreData(e, true)).toList() ?? [];
