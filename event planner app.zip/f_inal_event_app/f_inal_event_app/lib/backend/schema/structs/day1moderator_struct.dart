// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day1moderatorStruct extends FFFirebaseStruct {
  Day1moderatorStruct({
    String? moderatorname,
    String? moderatordesignation,
    String? moderatorphoto,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _moderatorname = moderatorname,
        _moderatordesignation = moderatordesignation,
        _moderatorphoto = moderatorphoto,
        super(firestoreUtilData);

  // "moderatorname" field.
  String? _moderatorname;
  String get moderatorname => _moderatorname ?? '';
  set moderatorname(String? val) => _moderatorname = val;

  bool hasModeratorname() => _moderatorname != null;

  // "moderatordesignation" field.
  String? _moderatordesignation;
  String get moderatordesignation => _moderatordesignation ?? '';
  set moderatordesignation(String? val) => _moderatordesignation = val;

  bool hasModeratordesignation() => _moderatordesignation != null;

  // "moderatorphoto" field.
  String? _moderatorphoto;
  String get moderatorphoto => _moderatorphoto ?? '';
  set moderatorphoto(String? val) => _moderatorphoto = val;

  bool hasModeratorphoto() => _moderatorphoto != null;

  static Day1moderatorStruct fromMap(Map<String, dynamic> data) =>
      Day1moderatorStruct(
        moderatorname: data['moderatorname'] as String?,
        moderatordesignation: data['moderatordesignation'] as String?,
        moderatorphoto: data['moderatorphoto'] as String?,
      );

  static Day1moderatorStruct? maybeFromMap(dynamic data) => data is Map
      ? Day1moderatorStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'moderatorname': _moderatorname,
        'moderatordesignation': _moderatordesignation,
        'moderatorphoto': _moderatorphoto,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'moderatorname': serializeParam(
          _moderatorname,
          ParamType.String,
        ),
        'moderatordesignation': serializeParam(
          _moderatordesignation,
          ParamType.String,
        ),
        'moderatorphoto': serializeParam(
          _moderatorphoto,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day1moderatorStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day1moderatorStruct(
        moderatorname: deserializeParam(
          data['moderatorname'],
          ParamType.String,
          false,
        ),
        moderatordesignation: deserializeParam(
          data['moderatordesignation'],
          ParamType.String,
          false,
        ),
        moderatorphoto: deserializeParam(
          data['moderatorphoto'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day1moderatorStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day1moderatorStruct &&
        moderatorname == other.moderatorname &&
        moderatordesignation == other.moderatordesignation &&
        moderatorphoto == other.moderatorphoto;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([moderatorname, moderatordesignation, moderatorphoto]);
}

Day1moderatorStruct createDay1moderatorStruct({
  String? moderatorname,
  String? moderatordesignation,
  String? moderatorphoto,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day1moderatorStruct(
      moderatorname: moderatorname,
      moderatordesignation: moderatordesignation,
      moderatorphoto: moderatorphoto,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day1moderatorStruct? updateDay1moderatorStruct(
  Day1moderatorStruct? day1moderator, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day1moderator
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay1moderatorStructData(
  Map<String, dynamic> firestoreData,
  Day1moderatorStruct? day1moderator,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day1moderator == null) {
    return;
  }
  if (day1moderator.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day1moderator.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day1moderatorData =
      getDay1moderatorFirestoreData(day1moderator, forFieldValue);
  final nestedData =
      day1moderatorData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day1moderator.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay1moderatorFirestoreData(
  Day1moderatorStruct? day1moderator, [
  bool forFieldValue = false,
]) {
  if (day1moderator == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day1moderator.toMap());

  // Add any Firestore field values
  day1moderator.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay1moderatorListFirestoreData(
  List<Day1moderatorStruct>? day1moderators,
) =>
    day1moderators
        ?.map((e) => getDay1moderatorFirestoreData(e, true))
        .toList() ??
    [];
