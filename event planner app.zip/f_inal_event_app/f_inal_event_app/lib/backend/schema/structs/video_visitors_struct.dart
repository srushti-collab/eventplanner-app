// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VideoVisitorsStruct extends FFFirebaseStruct {
  VideoVisitorsStruct({
    String? name,
    String? email,
    String? organisation,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _name = name,
        _email = email,
        _organisation = organisation,
        super(firestoreUtilData);

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  set email(String? val) => _email = val;

  bool hasEmail() => _email != null;

  // "organisation" field.
  String? _organisation;
  String get organisation => _organisation ?? '';
  set organisation(String? val) => _organisation = val;

  bool hasOrganisation() => _organisation != null;

  static VideoVisitorsStruct fromMap(Map<String, dynamic> data) =>
      VideoVisitorsStruct(
        name: data['name'] as String?,
        email: data['email'] as String?,
        organisation: data['organisation'] as String?,
      );

  static VideoVisitorsStruct? maybeFromMap(dynamic data) => data is Map
      ? VideoVisitorsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'email': _email,
        'organisation': _organisation,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'email': serializeParam(
          _email,
          ParamType.String,
        ),
        'organisation': serializeParam(
          _organisation,
          ParamType.String,
        ),
      }.withoutNulls;

  static VideoVisitorsStruct fromSerializableMap(Map<String, dynamic> data) =>
      VideoVisitorsStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        email: deserializeParam(
          data['email'],
          ParamType.String,
          false,
        ),
        organisation: deserializeParam(
          data['organisation'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'VideoVisitorsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is VideoVisitorsStruct &&
        name == other.name &&
        email == other.email &&
        organisation == other.organisation;
  }

  @override
  int get hashCode => const ListEquality().hash([name, email, organisation]);
}

VideoVisitorsStruct createVideoVisitorsStruct({
  String? name,
  String? email,
  String? organisation,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    VideoVisitorsStruct(
      name: name,
      email: email,
      organisation: organisation,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

VideoVisitorsStruct? updateVideoVisitorsStruct(
  VideoVisitorsStruct? videoVisitors, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    videoVisitors
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addVideoVisitorsStructData(
  Map<String, dynamic> firestoreData,
  VideoVisitorsStruct? videoVisitors,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (videoVisitors == null) {
    return;
  }
  if (videoVisitors.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && videoVisitors.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final videoVisitorsData =
      getVideoVisitorsFirestoreData(videoVisitors, forFieldValue);
  final nestedData =
      videoVisitorsData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = videoVisitors.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getVideoVisitorsFirestoreData(
  VideoVisitorsStruct? videoVisitors, [
  bool forFieldValue = false,
]) {
  if (videoVisitors == null) {
    return {};
  }
  final firestoreData = mapToFirestore(videoVisitors.toMap());

  // Add any Firestore field values
  videoVisitors.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getVideoVisitorsListFirestoreData(
  List<VideoVisitorsStruct>? videoVisitorss,
) =>
    videoVisitorss
        ?.map((e) => getVideoVisitorsFirestoreData(e, true))
        .toList() ??
    [];
