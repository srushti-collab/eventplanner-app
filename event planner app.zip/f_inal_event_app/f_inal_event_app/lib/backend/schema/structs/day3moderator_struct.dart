// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day3moderatorStruct extends FFFirebaseStruct {
  Day3moderatorStruct({
    String? moderatorname,
    String? moderatordesign,
    String? moderatorimg,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _moderatorname = moderatorname,
        _moderatordesign = moderatordesign,
        _moderatorimg = moderatorimg,
        super(firestoreUtilData);

  // "moderatorname" field.
  String? _moderatorname;
  String get moderatorname => _moderatorname ?? '';
  set moderatorname(String? val) => _moderatorname = val;

  bool hasModeratorname() => _moderatorname != null;

  // "moderatordesign" field.
  String? _moderatordesign;
  String get moderatordesign => _moderatordesign ?? '';
  set moderatordesign(String? val) => _moderatordesign = val;

  bool hasModeratordesign() => _moderatordesign != null;

  // "moderatorimg" field.
  String? _moderatorimg;
  String get moderatorimg => _moderatorimg ?? '';
  set moderatorimg(String? val) => _moderatorimg = val;

  bool hasModeratorimg() => _moderatorimg != null;

  static Day3moderatorStruct fromMap(Map<String, dynamic> data) =>
      Day3moderatorStruct(
        moderatorname: data['moderatorname'] as String?,
        moderatordesign: data['moderatordesign'] as String?,
        moderatorimg: data['moderatorimg'] as String?,
      );

  static Day3moderatorStruct? maybeFromMap(dynamic data) => data is Map
      ? Day3moderatorStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'moderatorname': _moderatorname,
        'moderatordesign': _moderatordesign,
        'moderatorimg': _moderatorimg,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'moderatorname': serializeParam(
          _moderatorname,
          ParamType.String,
        ),
        'moderatordesign': serializeParam(
          _moderatordesign,
          ParamType.String,
        ),
        'moderatorimg': serializeParam(
          _moderatorimg,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day3moderatorStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day3moderatorStruct(
        moderatorname: deserializeParam(
          data['moderatorname'],
          ParamType.String,
          false,
        ),
        moderatordesign: deserializeParam(
          data['moderatordesign'],
          ParamType.String,
          false,
        ),
        moderatorimg: deserializeParam(
          data['moderatorimg'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day3moderatorStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day3moderatorStruct &&
        moderatorname == other.moderatorname &&
        moderatordesign == other.moderatordesign &&
        moderatorimg == other.moderatorimg;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([moderatorname, moderatordesign, moderatorimg]);
}

Day3moderatorStruct createDay3moderatorStruct({
  String? moderatorname,
  String? moderatordesign,
  String? moderatorimg,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day3moderatorStruct(
      moderatorname: moderatorname,
      moderatordesign: moderatordesign,
      moderatorimg: moderatorimg,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day3moderatorStruct? updateDay3moderatorStruct(
  Day3moderatorStruct? day3moderator, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day3moderator
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay3moderatorStructData(
  Map<String, dynamic> firestoreData,
  Day3moderatorStruct? day3moderator,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day3moderator == null) {
    return;
  }
  if (day3moderator.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day3moderator.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day3moderatorData =
      getDay3moderatorFirestoreData(day3moderator, forFieldValue);
  final nestedData =
      day3moderatorData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day3moderator.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay3moderatorFirestoreData(
  Day3moderatorStruct? day3moderator, [
  bool forFieldValue = false,
]) {
  if (day3moderator == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day3moderator.toMap());

  // Add any Firestore field values
  day3moderator.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay3moderatorListFirestoreData(
  List<Day3moderatorStruct>? day3moderators,
) =>
    day3moderators
        ?.map((e) => getDay3moderatorFirestoreData(e, true))
        .toList() ??
    [];
