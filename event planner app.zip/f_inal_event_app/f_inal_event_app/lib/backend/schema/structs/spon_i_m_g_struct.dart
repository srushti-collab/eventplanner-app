// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SponIMGStruct extends FFFirebaseStruct {
  SponIMGStruct({
    String? description,
    String? image,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _description = description,
        _image = image,
        super(firestoreUtilData);

  // "description" field.
  String? _description;
  String get description => _description ?? '';
  set description(String? val) => _description = val;

  bool hasDescription() => _description != null;

  // "image" field.
  String? _image;
  String get image => _image ?? '';
  set image(String? val) => _image = val;

  bool hasImage() => _image != null;

  static SponIMGStruct fromMap(Map<String, dynamic> data) => SponIMGStruct(
        description: data['description'] as String?,
        image: data['image'] as String?,
      );

  static SponIMGStruct? maybeFromMap(dynamic data) =>
      data is Map ? SponIMGStruct.fromMap(data.cast<String, dynamic>()) : null;

  Map<String, dynamic> toMap() => {
        'description': _description,
        'image': _image,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'description': serializeParam(
          _description,
          ParamType.String,
        ),
        'image': serializeParam(
          _image,
          ParamType.String,
        ),
      }.withoutNulls;

  static SponIMGStruct fromSerializableMap(Map<String, dynamic> data) =>
      SponIMGStruct(
        description: deserializeParam(
          data['description'],
          ParamType.String,
          false,
        ),
        image: deserializeParam(
          data['image'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SponIMGStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SponIMGStruct &&
        description == other.description &&
        image == other.image;
  }

  @override
  int get hashCode => const ListEquality().hash([description, image]);
}

SponIMGStruct createSponIMGStruct({
  String? description,
  String? image,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    SponIMGStruct(
      description: description,
      image: image,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

SponIMGStruct? updateSponIMGStruct(
  SponIMGStruct? sponIMG, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    sponIMG
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addSponIMGStructData(
  Map<String, dynamic> firestoreData,
  SponIMGStruct? sponIMG,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (sponIMG == null) {
    return;
  }
  if (sponIMG.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && sponIMG.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final sponIMGData = getSponIMGFirestoreData(sponIMG, forFieldValue);
  final nestedData = sponIMGData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = sponIMG.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getSponIMGFirestoreData(
  SponIMGStruct? sponIMG, [
  bool forFieldValue = false,
]) {
  if (sponIMG == null) {
    return {};
  }
  final firestoreData = mapToFirestore(sponIMG.toMap());

  // Add any Firestore field values
  sponIMG.firestoreUtilData.fieldValues.forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getSponIMGListFirestoreData(
  List<SponIMGStruct>? sponIMGs,
) =>
    sponIMGs?.map((e) => getSponIMGFirestoreData(e, true)).toList() ?? [];
