// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day1chairStruct extends FFFirebaseStruct {
  Day1chairStruct({
    String? chairname,
    String? chairphoto,
    String? chairdesignatio,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _chairname = chairname,
        _chairphoto = chairphoto,
        _chairdesignatio = chairdesignatio,
        super(firestoreUtilData);

  // "Chairname" field.
  String? _chairname;
  String get chairname => _chairname ?? '';
  set chairname(String? val) => _chairname = val;

  bool hasChairname() => _chairname != null;

  // "Chairphoto" field.
  String? _chairphoto;
  String get chairphoto => _chairphoto ?? '';
  set chairphoto(String? val) => _chairphoto = val;

  bool hasChairphoto() => _chairphoto != null;

  // "Chairdesignatio" field.
  String? _chairdesignatio;
  String get chairdesignatio => _chairdesignatio ?? '';
  set chairdesignatio(String? val) => _chairdesignatio = val;

  bool hasChairdesignatio() => _chairdesignatio != null;

  static Day1chairStruct fromMap(Map<String, dynamic> data) => Day1chairStruct(
        chairname: data['Chairname'] as String?,
        chairphoto: data['Chairphoto'] as String?,
        chairdesignatio: data['Chairdesignatio'] as String?,
      );

  static Day1chairStruct? maybeFromMap(dynamic data) => data is Map
      ? Day1chairStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'Chairname': _chairname,
        'Chairphoto': _chairphoto,
        'Chairdesignatio': _chairdesignatio,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'Chairname': serializeParam(
          _chairname,
          ParamType.String,
        ),
        'Chairphoto': serializeParam(
          _chairphoto,
          ParamType.String,
        ),
        'Chairdesignatio': serializeParam(
          _chairdesignatio,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day1chairStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day1chairStruct(
        chairname: deserializeParam(
          data['Chairname'],
          ParamType.String,
          false,
        ),
        chairphoto: deserializeParam(
          data['Chairphoto'],
          ParamType.String,
          false,
        ),
        chairdesignatio: deserializeParam(
          data['Chairdesignatio'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day1chairStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day1chairStruct &&
        chairname == other.chairname &&
        chairphoto == other.chairphoto &&
        chairdesignatio == other.chairdesignatio;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([chairname, chairphoto, chairdesignatio]);
}

Day1chairStruct createDay1chairStruct({
  String? chairname,
  String? chairphoto,
  String? chairdesignatio,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day1chairStruct(
      chairname: chairname,
      chairphoto: chairphoto,
      chairdesignatio: chairdesignatio,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day1chairStruct? updateDay1chairStruct(
  Day1chairStruct? day1chair, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day1chair
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay1chairStructData(
  Map<String, dynamic> firestoreData,
  Day1chairStruct? day1chair,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day1chair == null) {
    return;
  }
  if (day1chair.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day1chair.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day1chairData = getDay1chairFirestoreData(day1chair, forFieldValue);
  final nestedData = day1chairData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day1chair.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay1chairFirestoreData(
  Day1chairStruct? day1chair, [
  bool forFieldValue = false,
]) {
  if (day1chair == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day1chair.toMap());

  // Add any Firestore field values
  day1chair.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay1chairListFirestoreData(
  List<Day1chairStruct>? day1chairs,
) =>
    day1chairs?.map((e) => getDay1chairFirestoreData(e, true)).toList() ?? [];
