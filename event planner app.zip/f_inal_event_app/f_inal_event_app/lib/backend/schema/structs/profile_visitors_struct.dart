// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ProfileVisitorsStruct extends FFFirebaseStruct {
  ProfileVisitorsStruct({
    String? name,
    String? email,
    String? organisation,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _name = name,
        _email = email,
        _organisation = organisation,
        super(firestoreUtilData);

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  set name(String? val) => _name = val;

  bool hasName() => _name != null;

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  set email(String? val) => _email = val;

  bool hasEmail() => _email != null;

  // "organisation" field.
  String? _organisation;
  String get organisation => _organisation ?? '';
  set organisation(String? val) => _organisation = val;

  bool hasOrganisation() => _organisation != null;

  static ProfileVisitorsStruct fromMap(Map<String, dynamic> data) =>
      ProfileVisitorsStruct(
        name: data['name'] as String?,
        email: data['email'] as String?,
        organisation: data['organisation'] as String?,
      );

  static ProfileVisitorsStruct? maybeFromMap(dynamic data) => data is Map
      ? ProfileVisitorsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'name': _name,
        'email': _email,
        'organisation': _organisation,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'name': serializeParam(
          _name,
          ParamType.String,
        ),
        'email': serializeParam(
          _email,
          ParamType.String,
        ),
        'organisation': serializeParam(
          _organisation,
          ParamType.String,
        ),
      }.withoutNulls;

  static ProfileVisitorsStruct fromSerializableMap(Map<String, dynamic> data) =>
      ProfileVisitorsStruct(
        name: deserializeParam(
          data['name'],
          ParamType.String,
          false,
        ),
        email: deserializeParam(
          data['email'],
          ParamType.String,
          false,
        ),
        organisation: deserializeParam(
          data['organisation'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'ProfileVisitorsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is ProfileVisitorsStruct &&
        name == other.name &&
        email == other.email &&
        organisation == other.organisation;
  }

  @override
  int get hashCode => const ListEquality().hash([name, email, organisation]);
}

ProfileVisitorsStruct createProfileVisitorsStruct({
  String? name,
  String? email,
  String? organisation,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    ProfileVisitorsStruct(
      name: name,
      email: email,
      organisation: organisation,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

ProfileVisitorsStruct? updateProfileVisitorsStruct(
  ProfileVisitorsStruct? profileVisitors, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    profileVisitors
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addProfileVisitorsStructData(
  Map<String, dynamic> firestoreData,
  ProfileVisitorsStruct? profileVisitors,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (profileVisitors == null) {
    return;
  }
  if (profileVisitors.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && profileVisitors.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final profileVisitorsData =
      getProfileVisitorsFirestoreData(profileVisitors, forFieldValue);
  final nestedData =
      profileVisitorsData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = profileVisitors.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getProfileVisitorsFirestoreData(
  ProfileVisitorsStruct? profileVisitors, [
  bool forFieldValue = false,
]) {
  if (profileVisitors == null) {
    return {};
  }
  final firestoreData = mapToFirestore(profileVisitors.toMap());

  // Add any Firestore field values
  profileVisitors.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getProfileVisitorsListFirestoreData(
  List<ProfileVisitorsStruct>? profileVisitorss,
) =>
    profileVisitorss
        ?.map((e) => getProfileVisitorsFirestoreData(e, true))
        .toList() ??
    [];
