// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day3chairStruct extends FFFirebaseStruct {
  Day3chairStruct({
    String? chairname,
    String? chairdesign,
    String? chairimg,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _chairname = chairname,
        _chairdesign = chairdesign,
        _chairimg = chairimg,
        super(firestoreUtilData);

  // "chairname" field.
  String? _chairname;
  String get chairname => _chairname ?? '';
  set chairname(String? val) => _chairname = val;

  bool hasChairname() => _chairname != null;

  // "chairdesign" field.
  String? _chairdesign;
  String get chairdesign => _chairdesign ?? '';
  set chairdesign(String? val) => _chairdesign = val;

  bool hasChairdesign() => _chairdesign != null;

  // "chairimg" field.
  String? _chairimg;
  String get chairimg => _chairimg ?? '';
  set chairimg(String? val) => _chairimg = val;

  bool hasChairimg() => _chairimg != null;

  static Day3chairStruct fromMap(Map<String, dynamic> data) => Day3chairStruct(
        chairname: data['chairname'] as String?,
        chairdesign: data['chairdesign'] as String?,
        chairimg: data['chairimg'] as String?,
      );

  static Day3chairStruct? maybeFromMap(dynamic data) => data is Map
      ? Day3chairStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'chairname': _chairname,
        'chairdesign': _chairdesign,
        'chairimg': _chairimg,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'chairname': serializeParam(
          _chairname,
          ParamType.String,
        ),
        'chairdesign': serializeParam(
          _chairdesign,
          ParamType.String,
        ),
        'chairimg': serializeParam(
          _chairimg,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day3chairStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day3chairStruct(
        chairname: deserializeParam(
          data['chairname'],
          ParamType.String,
          false,
        ),
        chairdesign: deserializeParam(
          data['chairdesign'],
          ParamType.String,
          false,
        ),
        chairimg: deserializeParam(
          data['chairimg'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day3chairStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day3chairStruct &&
        chairname == other.chairname &&
        chairdesign == other.chairdesign &&
        chairimg == other.chairimg;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([chairname, chairdesign, chairimg]);
}

Day3chairStruct createDay3chairStruct({
  String? chairname,
  String? chairdesign,
  String? chairimg,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day3chairStruct(
      chairname: chairname,
      chairdesign: chairdesign,
      chairimg: chairimg,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day3chairStruct? updateDay3chairStruct(
  Day3chairStruct? day3chair, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day3chair
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay3chairStructData(
  Map<String, dynamic> firestoreData,
  Day3chairStruct? day3chair,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day3chair == null) {
    return;
  }
  if (day3chair.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day3chair.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day3chairData = getDay3chairFirestoreData(day3chair, forFieldValue);
  final nestedData = day3chairData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day3chair.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay3chairFirestoreData(
  Day3chairStruct? day3chair, [
  bool forFieldValue = false,
]) {
  if (day3chair == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day3chair.toMap());

  // Add any Firestore field values
  day3chair.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay3chairListFirestoreData(
  List<Day3chairStruct>? day3chairs,
) =>
    day3chairs?.map((e) => getDay3chairFirestoreData(e, true)).toList() ?? [];
