// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day2moderatorStruct extends FFFirebaseStruct {
  Day2moderatorStruct({
    String? day2moderatorname,
    String? moderatordesign,
    String? moderatorimg,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _day2moderatorname = day2moderatorname,
        _moderatordesign = moderatordesign,
        _moderatorimg = moderatorimg,
        super(firestoreUtilData);

  // "day2moderatorname" field.
  String? _day2moderatorname;
  String get day2moderatorname => _day2moderatorname ?? '';
  set day2moderatorname(String? val) => _day2moderatorname = val;

  bool hasDay2moderatorname() => _day2moderatorname != null;

  // "moderatordesign" field.
  String? _moderatordesign;
  String get moderatordesign => _moderatordesign ?? '';
  set moderatordesign(String? val) => _moderatordesign = val;

  bool hasModeratordesign() => _moderatordesign != null;

  // "moderatorimg" field.
  String? _moderatorimg;
  String get moderatorimg => _moderatorimg ?? '';
  set moderatorimg(String? val) => _moderatorimg = val;

  bool hasModeratorimg() => _moderatorimg != null;

  static Day2moderatorStruct fromMap(Map<String, dynamic> data) =>
      Day2moderatorStruct(
        day2moderatorname: data['day2moderatorname'] as String?,
        moderatordesign: data['moderatordesign'] as String?,
        moderatorimg: data['moderatorimg'] as String?,
      );

  static Day2moderatorStruct? maybeFromMap(dynamic data) => data is Map
      ? Day2moderatorStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'day2moderatorname': _day2moderatorname,
        'moderatordesign': _moderatordesign,
        'moderatorimg': _moderatorimg,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'day2moderatorname': serializeParam(
          _day2moderatorname,
          ParamType.String,
        ),
        'moderatordesign': serializeParam(
          _moderatordesign,
          ParamType.String,
        ),
        'moderatorimg': serializeParam(
          _moderatorimg,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day2moderatorStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day2moderatorStruct(
        day2moderatorname: deserializeParam(
          data['day2moderatorname'],
          ParamType.String,
          false,
        ),
        moderatordesign: deserializeParam(
          data['moderatordesign'],
          ParamType.String,
          false,
        ),
        moderatorimg: deserializeParam(
          data['moderatorimg'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day2moderatorStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day2moderatorStruct &&
        day2moderatorname == other.day2moderatorname &&
        moderatordesign == other.moderatordesign &&
        moderatorimg == other.moderatorimg;
  }

  @override
  int get hashCode => const ListEquality()
      .hash([day2moderatorname, moderatordesign, moderatorimg]);
}

Day2moderatorStruct createDay2moderatorStruct({
  String? day2moderatorname,
  String? moderatordesign,
  String? moderatorimg,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day2moderatorStruct(
      day2moderatorname: day2moderatorname,
      moderatordesign: moderatordesign,
      moderatorimg: moderatorimg,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day2moderatorStruct? updateDay2moderatorStruct(
  Day2moderatorStruct? day2moderator, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day2moderator
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay2moderatorStructData(
  Map<String, dynamic> firestoreData,
  Day2moderatorStruct? day2moderator,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day2moderator == null) {
    return;
  }
  if (day2moderator.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day2moderator.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day2moderatorData =
      getDay2moderatorFirestoreData(day2moderator, forFieldValue);
  final nestedData =
      day2moderatorData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day2moderator.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay2moderatorFirestoreData(
  Day2moderatorStruct? day2moderator, [
  bool forFieldValue = false,
]) {
  if (day2moderator == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day2moderator.toMap());

  // Add any Firestore field values
  day2moderator.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay2moderatorListFirestoreData(
  List<Day2moderatorStruct>? day2moderators,
) =>
    day2moderators
        ?.map((e) => getDay2moderatorFirestoreData(e, true))
        .toList() ??
    [];
