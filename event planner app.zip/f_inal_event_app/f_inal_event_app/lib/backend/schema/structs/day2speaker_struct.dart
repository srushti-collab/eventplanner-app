// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day2speakerStruct extends FFFirebaseStruct {
  Day2speakerStruct({
    String? speakername,
    String? speakerdesign,
    String? speakerphoto,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _speakername = speakername,
        _speakerdesign = speakerdesign,
        _speakerphoto = speakerphoto,
        super(firestoreUtilData);

  // "speakername" field.
  String? _speakername;
  String get speakername => _speakername ?? '';
  set speakername(String? val) => _speakername = val;

  bool hasSpeakername() => _speakername != null;

  // "speakerdesign" field.
  String? _speakerdesign;
  String get speakerdesign => _speakerdesign ?? '';
  set speakerdesign(String? val) => _speakerdesign = val;

  bool hasSpeakerdesign() => _speakerdesign != null;

  // "speakerphoto" field.
  String? _speakerphoto;
  String get speakerphoto => _speakerphoto ?? '';
  set speakerphoto(String? val) => _speakerphoto = val;

  bool hasSpeakerphoto() => _speakerphoto != null;

  static Day2speakerStruct fromMap(Map<String, dynamic> data) =>
      Day2speakerStruct(
        speakername: data['speakername'] as String?,
        speakerdesign: data['speakerdesign'] as String?,
        speakerphoto: data['speakerphoto'] as String?,
      );

  static Day2speakerStruct? maybeFromMap(dynamic data) => data is Map
      ? Day2speakerStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'speakername': _speakername,
        'speakerdesign': _speakerdesign,
        'speakerphoto': _speakerphoto,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'speakername': serializeParam(
          _speakername,
          ParamType.String,
        ),
        'speakerdesign': serializeParam(
          _speakerdesign,
          ParamType.String,
        ),
        'speakerphoto': serializeParam(
          _speakerphoto,
          ParamType.String,
        ),
      }.withoutNulls;

  static Day2speakerStruct fromSerializableMap(Map<String, dynamic> data) =>
      Day2speakerStruct(
        speakername: deserializeParam(
          data['speakername'],
          ParamType.String,
          false,
        ),
        speakerdesign: deserializeParam(
          data['speakerdesign'],
          ParamType.String,
          false,
        ),
        speakerphoto: deserializeParam(
          data['speakerphoto'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'Day2speakerStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is Day2speakerStruct &&
        speakername == other.speakername &&
        speakerdesign == other.speakerdesign &&
        speakerphoto == other.speakerphoto;
  }

  @override
  int get hashCode =>
      const ListEquality().hash([speakername, speakerdesign, speakerphoto]);
}

Day2speakerStruct createDay2speakerStruct({
  String? speakername,
  String? speakerdesign,
  String? speakerphoto,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    Day2speakerStruct(
      speakername: speakername,
      speakerdesign: speakerdesign,
      speakerphoto: speakerphoto,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

Day2speakerStruct? updateDay2speakerStruct(
  Day2speakerStruct? day2speaker, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    day2speaker
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addDay2speakerStructData(
  Map<String, dynamic> firestoreData,
  Day2speakerStruct? day2speaker,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (day2speaker == null) {
    return;
  }
  if (day2speaker.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && day2speaker.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final day2speakerData =
      getDay2speakerFirestoreData(day2speaker, forFieldValue);
  final nestedData =
      day2speakerData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = day2speaker.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getDay2speakerFirestoreData(
  Day2speakerStruct? day2speaker, [
  bool forFieldValue = false,
]) {
  if (day2speaker == null) {
    return {};
  }
  final firestoreData = mapToFirestore(day2speaker.toMap());

  // Add any Firestore field values
  day2speaker.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getDay2speakerListFirestoreData(
  List<Day2speakerStruct>? day2speakers,
) =>
    day2speakers?.map((e) => getDay2speakerFirestoreData(e, true)).toList() ??
    [];
