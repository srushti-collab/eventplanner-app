// ignore_for_file: unnecessary_getters_setters

import 'package:cloud_firestore/cloud_firestore.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class SponDownloadsStruct extends FFFirebaseStruct {
  SponDownloadsStruct({
    String? fileName,
    String? fileLink,
    FirestoreUtilData firestoreUtilData = const FirestoreUtilData(),
  })  : _fileName = fileName,
        _fileLink = fileLink,
        super(firestoreUtilData);

  // "FileName" field.
  String? _fileName;
  String get fileName => _fileName ?? '';
  set fileName(String? val) => _fileName = val;

  bool hasFileName() => _fileName != null;

  // "FileLink" field.
  String? _fileLink;
  String get fileLink => _fileLink ?? '';
  set fileLink(String? val) => _fileLink = val;

  bool hasFileLink() => _fileLink != null;

  static SponDownloadsStruct fromMap(Map<String, dynamic> data) =>
      SponDownloadsStruct(
        fileName: data['FileName'] as String?,
        fileLink: data['FileLink'] as String?,
      );

  static SponDownloadsStruct? maybeFromMap(dynamic data) => data is Map
      ? SponDownloadsStruct.fromMap(data.cast<String, dynamic>())
      : null;

  Map<String, dynamic> toMap() => {
        'FileName': _fileName,
        'FileLink': _fileLink,
      }.withoutNulls;

  @override
  Map<String, dynamic> toSerializableMap() => {
        'FileName': serializeParam(
          _fileName,
          ParamType.String,
        ),
        'FileLink': serializeParam(
          _fileLink,
          ParamType.String,
        ),
      }.withoutNulls;

  static SponDownloadsStruct fromSerializableMap(Map<String, dynamic> data) =>
      SponDownloadsStruct(
        fileName: deserializeParam(
          data['FileName'],
          ParamType.String,
          false,
        ),
        fileLink: deserializeParam(
          data['FileLink'],
          ParamType.String,
          false,
        ),
      );

  @override
  String toString() => 'SponDownloadsStruct(${toMap()})';

  @override
  bool operator ==(Object other) {
    return other is SponDownloadsStruct &&
        fileName == other.fileName &&
        fileLink == other.fileLink;
  }

  @override
  int get hashCode => const ListEquality().hash([fileName, fileLink]);
}

SponDownloadsStruct createSponDownloadsStruct({
  String? fileName,
  String? fileLink,
  Map<String, dynamic> fieldValues = const {},
  bool clearUnsetFields = true,
  bool create = false,
  bool delete = false,
}) =>
    SponDownloadsStruct(
      fileName: fileName,
      fileLink: fileLink,
      firestoreUtilData: FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
        delete: delete,
        fieldValues: fieldValues,
      ),
    );

SponDownloadsStruct? updateSponDownloadsStruct(
  SponDownloadsStruct? sponDownloads, {
  bool clearUnsetFields = true,
  bool create = false,
}) =>
    sponDownloads
      ?..firestoreUtilData = FirestoreUtilData(
        clearUnsetFields: clearUnsetFields,
        create: create,
      );

void addSponDownloadsStructData(
  Map<String, dynamic> firestoreData,
  SponDownloadsStruct? sponDownloads,
  String fieldName, [
  bool forFieldValue = false,
]) {
  firestoreData.remove(fieldName);
  if (sponDownloads == null) {
    return;
  }
  if (sponDownloads.firestoreUtilData.delete) {
    firestoreData[fieldName] = FieldValue.delete();
    return;
  }
  final clearFields =
      !forFieldValue && sponDownloads.firestoreUtilData.clearUnsetFields;
  if (clearFields) {
    firestoreData[fieldName] = <String, dynamic>{};
  }
  final sponDownloadsData =
      getSponDownloadsFirestoreData(sponDownloads, forFieldValue);
  final nestedData =
      sponDownloadsData.map((k, v) => MapEntry('$fieldName.$k', v));

  final mergeFields = sponDownloads.firestoreUtilData.create || clearFields;
  firestoreData
      .addAll(mergeFields ? mergeNestedFields(nestedData) : nestedData);
}

Map<String, dynamic> getSponDownloadsFirestoreData(
  SponDownloadsStruct? sponDownloads, [
  bool forFieldValue = false,
]) {
  if (sponDownloads == null) {
    return {};
  }
  final firestoreData = mapToFirestore(sponDownloads.toMap());

  // Add any Firestore field values
  sponDownloads.firestoreUtilData.fieldValues
      .forEach((k, v) => firestoreData[k] = v);

  return forFieldValue ? mergeNestedFields(firestoreData) : firestoreData;
}

List<Map<String, dynamic>> getSponDownloadsListFirestoreData(
  List<SponDownloadsStruct>? sponDownloadss,
) =>
    sponDownloadss
        ?.map((e) => getSponDownloadsFirestoreData(e, true))
        .toList() ??
    [];
