import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class Day2schedulesRecord extends FirestoreRecord {
  Day2schedulesRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "time" field.
  String? _time;
  String get time => _time ?? '';
  bool hasTime() => _time != null;

  // "sessionNo" field.
  String? _sessionNo;
  String get sessionNo => _sessionNo ?? '';
  bool hasSessionNo() => _sessionNo != null;

  // "chair" field.
  String? _chair;
  String get chair => _chair ?? '';
  bool hasChair() => _chair != null;

  // "panelists" field.
  String? _panelists;
  String get panelists => _panelists ?? '';
  bool hasPanelists() => _panelists != null;

  // "sessionTitle" field.
  String? _sessionTitle;
  String get sessionTitle => _sessionTitle ?? '';
  bool hasSessionTitle() => _sessionTitle != null;

  // "imageday1" field.
  String? _imageday1;
  String get imageday1 => _imageday1 ?? '';
  bool hasImageday1() => _imageday1 != null;

  // "StartTime" field.
  DateTime? _startTime;
  DateTime? get startTime => _startTime;
  bool hasStartTime() => _startTime != null;

  // "EndTime" field.
  DateTime? _endTime;
  DateTime? get endTime => _endTime;
  bool hasEndTime() => _endTime != null;

  // "Speakers" field.
  List<Day2speakerStruct>? _speakers;
  List<Day2speakerStruct> get speakers => _speakers ?? const [];
  bool hasSpeakers() => _speakers != null;

  // "Moderators" field.
  List<Day2moderatorStruct>? _moderators;
  List<Day2moderatorStruct> get moderators => _moderators ?? const [];
  bool hasModerators() => _moderators != null;

  // "Chairs" field.
  List<Day2chairStruct>? _chairs;
  List<Day2chairStruct> get chairs => _chairs ?? const [];
  bool hasChairs() => _chairs != null;

  // "location" field.
  String? _location;
  String get location => _location ?? '';
  bool hasLocation() => _location != null;

  void _initializeFields() {
    _time = snapshotData['time'] as String?;
    _sessionNo = snapshotData['sessionNo'] as String?;
    _chair = snapshotData['chair'] as String?;
    _panelists = snapshotData['panelists'] as String?;
    _sessionTitle = snapshotData['sessionTitle'] as String?;
    _imageday1 = snapshotData['imageday1'] as String?;
    _startTime = snapshotData['StartTime'] as DateTime?;
    _endTime = snapshotData['EndTime'] as DateTime?;
    _speakers = getStructList(
      snapshotData['Speakers'],
      Day2speakerStruct.fromMap,
    );
    _moderators = getStructList(
      snapshotData['Moderators'],
      Day2moderatorStruct.fromMap,
    );
    _chairs = getStructList(
      snapshotData['Chairs'],
      Day2chairStruct.fromMap,
    );
    _location = snapshotData['location'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('day2schedules');

  static Stream<Day2schedulesRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => Day2schedulesRecord.fromSnapshot(s));

  static Future<Day2schedulesRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => Day2schedulesRecord.fromSnapshot(s));

  static Day2schedulesRecord fromSnapshot(DocumentSnapshot snapshot) =>
      Day2schedulesRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static Day2schedulesRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      Day2schedulesRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'Day2schedulesRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is Day2schedulesRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createDay2schedulesRecordData({
  String? time,
  String? sessionNo,
  String? chair,
  String? panelists,
  String? sessionTitle,
  String? imageday1,
  DateTime? startTime,
  DateTime? endTime,
  String? location,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'time': time,
      'sessionNo': sessionNo,
      'chair': chair,
      'panelists': panelists,
      'sessionTitle': sessionTitle,
      'imageday1': imageday1,
      'StartTime': startTime,
      'EndTime': endTime,
      'location': location,
    }.withoutNulls,
  );

  return firestoreData;
}

class Day2schedulesRecordDocumentEquality
    implements Equality<Day2schedulesRecord> {
  const Day2schedulesRecordDocumentEquality();

  @override
  bool equals(Day2schedulesRecord? e1, Day2schedulesRecord? e2) {
    const listEquality = ListEquality();
    return e1?.time == e2?.time &&
        e1?.sessionNo == e2?.sessionNo &&
        e1?.chair == e2?.chair &&
        e1?.panelists == e2?.panelists &&
        e1?.sessionTitle == e2?.sessionTitle &&
        e1?.imageday1 == e2?.imageday1 &&
        e1?.startTime == e2?.startTime &&
        e1?.endTime == e2?.endTime &&
        listEquality.equals(e1?.speakers, e2?.speakers) &&
        listEquality.equals(e1?.moderators, e2?.moderators) &&
        listEquality.equals(e1?.chairs, e2?.chairs) &&
        e1?.location == e2?.location;
  }

  @override
  int hash(Day2schedulesRecord? e) => const ListEquality().hash([
        e?.time,
        e?.sessionNo,
        e?.chair,
        e?.panelists,
        e?.sessionTitle,
        e?.imageday1,
        e?.startTime,
        e?.endTime,
        e?.speakers,
        e?.moderators,
        e?.chairs,
        e?.location
      ]);

  @override
  bool isValidKey(Object? o) => o is Day2schedulesRecord;
}
