import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBIJNdiJ0oPyS6M0BJYXPtA8QnlG1EdlmU",
            authDomain: "cashew-conference-nou3if.firebaseapp.com",
            projectId: "cashew-conference-nou3if",
            storageBucket: "cashew-conference-nou3if.firebasestorage.app",
            messagingSenderId: "221944984002",
            appId: "1:221944984002:web:9543ed1be18a237184a65b"));
  } else {
    await Firebase.initializeApp();
  }
}
