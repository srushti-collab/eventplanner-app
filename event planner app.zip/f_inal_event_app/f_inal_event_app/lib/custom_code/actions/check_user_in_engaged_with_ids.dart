// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

Future<bool> checkUserInEngagedWithIds(
  String authenticatedUserUid,
  String selectedUserUid,
) async {
  // Get the authenticated user's document from Firestore
  final authenticatedUserDoc = await FirebaseFirestore.instance
      .collection('users')
      .doc(authenticatedUserUid)
      .get();

  // Get the list of engaged user IDs from the authenticated user's document
  final engagedWithIds = authenticatedUserDoc.data()?['engaged_with_ids'] ?? [];

  // Check if the selected user's UID is in the engaged_with_ids list
  return engagedWithIds.contains(selectedUserUid);
}
// Set your action name, define your arguments and return parameter,
// and then add the boilerplate code using the green button on the right!
