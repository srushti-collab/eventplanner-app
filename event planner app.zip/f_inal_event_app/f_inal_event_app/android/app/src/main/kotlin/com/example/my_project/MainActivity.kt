package com.flutterflow.fluttermetMyE

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
